﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.SessionState;
using Microsoft.Practices.Unity;
using System.IO;

namespace DS.Web
{
    /// <summary>
    /// 验证码管理类
    /// Version:1.0
    /// Author:Dozer
    /// Date:2010/10/19
    /// </summary>
    public class AuthCodeManager : IRequiresSessionState
    {
        /// <summary>
        /// 验证码字典
        /// </summary>
        protected Dictionary<string, string> authcodes;
        /// <summary>
        /// 验证码生成类
        /// </summary>
        protected IAuthCodeBuilder _authCodeBuilder;
        /// <summary>
        /// 验证码生成类
        /// </summary>
        protected IAuthCodeBuilder authCodeBuilder
        {
            get
            {
                if (_authCodeBuilder == null) throw new ArgumentNullException("IAuthCodeBuilder未初始化");
                return this._authCodeBuilder;
            }
            set
            {
                this._authCodeBuilder = value;
            }
        }
        /// <summary>
        /// HttpContext
        /// </summary>
        protected HttpContext Context
        {
            get
            {
                return HttpContext.Current;
            }
        }
        /// <summary>
        /// Session
        /// </summary>
        protected HttpSessionState Session
        {
            get
            {
                if (Context.Session == null) throw new ArgumentNullException("请不要在构造函数中声明该类！");
                return Context.Session;
            }
        }
        /// <summary>
        /// 当前验证码
        /// </summary>
        protected string currentAuthCode;
        /// <summary>
        /// 当前验证码
        /// </summary>
        public string CurrentAuthCode
        {
            get
            {
                if (currentAuthCode == null) throw new ArgumentNullException("未创建验证码");
                    return currentAuthCode;
                }
        }
        /// <summary>
        /// 在Session中的默认名
        /// </summary>
        protected static readonly string SESSION_NAME = "AuthCode";


        #region 构造函数
        [InjectionConstructor]
        public AuthCodeManager()
            : this(SESSION_NAME)
        { }
        public AuthCodeManager(IAuthCodeBuilder authCodeBuilder)
            : this(SESSION_NAME)
        {
            Initialize(authCodeBuilder);
        }
        public AuthCodeManager(string name, IAuthCodeBuilder authCodeBuilder)
            : this(name)
        {
            Initialize(authCodeBuilder);
        }
        public AuthCodeManager(string name)
        {
            if (string.IsNullOrEmpty(name)) throw new ArgumentNullException("名字不能为空！");
            if (Session[name] == null) Session[name] = new Dictionary<string, string>();
            if (!(Session[name] is Dictionary<string, string>)) throw new ArgumentException("类型不符！");
            authcodes = Session[name] as Dictionary<string, string>;
        }
        #endregion

        /// <summary>
        /// 依赖注入初始化
        /// </summary>
        /// <param name="authCodeBuilder">验证码生成类</param>
        [InjectionMethod]
        public void Initialize(IAuthCodeBuilder authCodeBuilder)
        {
            this.authCodeBuilder = authCodeBuilder;
        }

        /// <summary>
        /// 得到请求ID
        /// </summary>
        /// <returns></returns>
        protected virtual string GetSessionID()
        {
            throw new NotImplementedException("请重写该方法后再调用！");
        }

        /// <summary>
        /// 自动获取当前请求ID的验证，请重写GetSessionID()方法后再调用！
        /// </summary>
        /// <param name="authcode">验证码</param>
        /// <returns>是否通过</returns>
        public virtual bool Authorize(string authcode)
        {
            return Authorize(GetSessionID(), authcode);
        }

        /// <summary>
        /// 验证
        /// </summary>
        /// <param name="sessionID">请求ID</param>
        /// <param name="authcode">验证码</param>
        /// <returns>是否通过</returns>
        public bool Authorize(string sessionID, string authcode)
        {
            if (!authcodes.ContainsKey(sessionID)) return false;
            var authCode = authcodes[sessionID];
            authcodes.Remove(sessionID);
            if (authCode != authcode) return false;
            return true;
        }

        /// <summary>
        /// 设置并得到请求ID
        /// </summary>
        /// <returns></returns>
        protected virtual string SetSessionID()
        {
            throw new NotImplementedException("请重写该方法后再调用！");
        }

        /// <summary>
        /// 自动获得请求ID，并获得验证码，请重写SetSessionID()方法后再调用！
        /// </summary>
        /// <returns></returns>
        public virtual MemoryStream Create()
        {
            return Create(SetSessionID());
        }

        /// <summary>
        /// 如果数量过多的话则清理
        /// </summary>
        protected virtual void Clear()
        {
            if (authcodes.Count > 1000)
            {
                var e = authcodes.Keys.GetEnumerator();
                e.MoveNext();
                authcodes.Remove(e.Current);
            }
        }

        /// <summary>
        /// 获得验证码
        /// </summary>
        /// <param name="sessionID"></param>
        /// <returns></returns>
        public MemoryStream Create(string sessionID)
        {
            Clear();
            currentAuthCode = sessionID;
            if (authcodes.ContainsKey(sessionID)) authcodes.Remove(sessionID);
            authcodes.Add(sessionID, authCodeBuilder.CreateAuthCode());
            return authCodeBuilder.GetAuthCodeStream();
        }
    }
}