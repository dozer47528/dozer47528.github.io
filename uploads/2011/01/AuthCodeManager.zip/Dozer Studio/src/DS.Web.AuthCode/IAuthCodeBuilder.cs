﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace DS.Web
{
    public interface IAuthCodeBuilder
    {
        /// <summary>
        /// 创建验证码，并保存
        /// </summary>
        /// <returns></returns>
        string CreateAuthCode();
        /// <summary>
        /// 创建验证码，并保存
        /// </summary>
        /// <param name="codeStream">验证码</param>
        /// <returns></returns>
        string CreateAuthCode(string codeString);
        /// <summary>
        /// 根据保存的验证码，创建验证码图片
        /// </summary>
        /// <returns></returns>
        MemoryStream GetAuthCodeStream();
    }
}