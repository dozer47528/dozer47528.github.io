﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DS.Web.AuthCode;
using System.IO;

namespace DS.Web.AuthCode.Example
{
    public partial class _Default : System.Web.UI.Page
    {
        public string imageURL;
        public string sessionID;

        protected void Page_Load(object sender, EventArgs e)
        {
            var ticks = DateTime.Now.Ticks.ToString();
            imageURL = "AuthCode.ashx?id=" + ticks;
            sessionID = ticks;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            AuthCodeManager am = new AuthCodeManager(new AuthCodeBuilder());
            Response.Write("<script>alert('" + am.Authorize(Request["sessionID"], TextBox1.Text).ToString() + "');</script>");
            TextBox1.Text = "";
        }
    }
}
