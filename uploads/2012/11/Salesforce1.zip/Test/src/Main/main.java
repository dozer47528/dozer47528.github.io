package Main;

import java.rmi.RemoteException;

import javax.xml.rpc.ServiceException;

import com.sforce.soap.enterprise.LoginResult;
import com.sforce.soap.enterprise.QueryResult;
import com.sforce.soap.enterprise.SessionHeader;
import com.sforce.soap.enterprise.SforceServiceLocator;
import com.sforce.soap.enterprise.SoapBindingStub;
import com.sforce.soap.enterprise.fault.InvalidIdFault;
import com.sforce.soap.enterprise.fault.LoginFault;
import com.sforce.soap.enterprise.fault.UnexpectedErrorFault;
import com.sforce.soap.enterprise.sobject.SObject;

public class main {
	public static void main(String[] args) throws InvalidIdFault,
			UnexpectedErrorFault, LoginFault, RemoteException, ServiceException {
		
		//init binding
		SoapBindingStub binding = (SoapBindingStub) new SforceServiceLocator()
				.getSoap();
		
		//login
		LoginResult result = binding.login("xxxxxxxx",
				"xxxxxxxxxx");
		
		//set session
		SessionHeader session = new SessionHeader();
		session.setSessionId(result.getSessionId());
		binding.setHeader(new SforceServiceLocator().getServiceName()
				.getNamespaceURI(), "SessionHeader", session);

		//set server url
		binding._setProperty(SoapBindingStub.ENDPOINT_ADDRESS_PROPERTY,
				result.getServerUrl());

		//query test
		QueryResult q = binding.query("Select Id from Contract limit 1");
		SObject[] recordSObjects = q.getRecords();
	}
}
