/**
 * DealGroup__c.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.sforce.soap.enterprise.sobject;

public class DealGroup__c  extends com.sforce.soap.enterprise.sobject.SObject  implements java.io.Serializable {
    private java.lang.String accountName__c;

    private com.sforce.soap.enterprise.QueryResult activityHistories;

    private java.lang.Boolean allowanceFlag__c;

    private java.lang.String approvalMgr1__c;

    private com.sforce.soap.enterprise.sobject.User approvalMgr1__r;

    private java.lang.String approvalMgr2__c;

    private com.sforce.soap.enterprise.sobject.User approvalMgr2__r;

    private java.lang.String approvalMgr3__c;

    private com.sforce.soap.enterprise.sobject.User approvalMgr3__r;

    private com.sforce.soap.enterprise.QueryResult attachments;

    private java.util.Date beginDate__c;

    private java.lang.String blackDate__c;

    private java.lang.String bulkBuyFirstCategory__c;

    private java.lang.String bulkBuySecondCategory__c;

    private com.sforce.soap.enterprise.QueryResult childDealGroup__r;

    private java.lang.String cityID__c;

    private java.lang.String companyNumber__c;

    private java.lang.String contractStatus__c;

    private java.lang.String contract__c;

    private com.sforce.soap.enterprise.sobject.Contract contract__r;

    private com.sforce.soap.enterprise.sobject.User createdBy;

    private java.lang.String createdById;

    private java.util.Calendar createdDate;

    private java.lang.Double dealCount__c;

    private java.lang.String dealGroupAprStatus__c;

    private java.lang.String dealGroupUpdTrack__c;

    private com.sforce.soap.enterprise.QueryResult deal__r;

    private java.lang.String dealgroupStage__c;

    private com.sforce.soap.enterprise.QueryResult destinaion__r;

    private java.util.Date endDate__c;

    private com.sforce.soap.enterprise.QueryResult events;

    private com.sforce.soap.enterprise.QueryResult histories;

    private java.lang.String infoConfirmed__c;

    private java.lang.Boolean isAutoRefund__c;

    private java.lang.Boolean isCostChanged__c;

    private java.lang.Boolean isDPDeliver__c;

    private java.lang.Boolean isDeleted;

    private java.lang.String isECommerceDG__c;

    private java.lang.Boolean isNeedApprovalMgr1__c;

    private java.lang.Boolean isNeedApproval__c;

    private java.lang.Boolean isNeedProjectTeamApr__c;

    private java.lang.String isOnApprovaling__c;

    private java.lang.Boolean isTerminateDealGroup__c;

    private java.lang.Boolean isVip__c;

    private java.util.Date lastActivityDate;

    private com.sforce.soap.enterprise.sobject.User lastModifiedBy;

    private java.lang.String lastModifiedById;

    private java.util.Calendar lastModifiedDate;

    private java.lang.Double maxPerUser__c;

    private com.sforce.soap.enterprise.QueryResult monthlyPerformanceActual__r;

    private java.lang.String name;

    private java.lang.Double needAllowance__c;

    private com.sforce.soap.enterprise.QueryResult notes;

    private com.sforce.soap.enterprise.QueryResult notesAndAttachments;

    private java.util.Date onlineDate__c;

    private java.lang.Double onlineDayLength__c;

    private com.sforce.soap.enterprise.QueryResult openActivities;

    private com.sforce.soap.enterprise.sobject.Name owner;

    private java.lang.String ownerId;

    private java.lang.String passwdAccepterEmail__c;

    private java.lang.String passwdAccepterPhone__c;

    private java.lang.String passwdAccepter__c;

    private java.util.Date planBeginDate__c;

    private com.sforce.soap.enterprise.QueryResult processInstances;

    private com.sforce.soap.enterprise.QueryResult processSteps;

    private java.lang.Boolean provideInvoice__c;

    private java.lang.String publishCitys__c;

    private java.lang.String publishType__c;

    private java.lang.String receiptType__c;

    private java.lang.String sourceDealGroup__c;

    private com.sforce.soap.enterprise.sobject.DealGroup__c sourceDealGroup__r;

    private java.lang.String supportPoints__c;

    private java.lang.String sysDealGroupId__c;

    private java.lang.String sysDealGroupUrl__c;

    private java.util.Calendar systemModstamp;

    private com.sforce.soap.enterprise.QueryResult tasks;

    private com.sforce.soap.enterprise.QueryResult tgCategory__r;

    private java.lang.String varificationProvider__c;

    private java.lang.String verifyType__c;

    private java.lang.String isProduced__c;

    private java.util.Calendar offLineTime__c;

    private java.lang.String onlineStatus__c;

    public DealGroup__c() {
    }

    public DealGroup__c(
           java.lang.String[] fieldsToNull,
           java.lang.String id,
           java.lang.String accountName__c,
           com.sforce.soap.enterprise.QueryResult activityHistories,
           java.lang.Boolean allowanceFlag__c,
           java.lang.String approvalMgr1__c,
           com.sforce.soap.enterprise.sobject.User approvalMgr1__r,
           java.lang.String approvalMgr2__c,
           com.sforce.soap.enterprise.sobject.User approvalMgr2__r,
           java.lang.String approvalMgr3__c,
           com.sforce.soap.enterprise.sobject.User approvalMgr3__r,
           com.sforce.soap.enterprise.QueryResult attachments,
           java.util.Date beginDate__c,
           java.lang.String blackDate__c,
           java.lang.String bulkBuyFirstCategory__c,
           java.lang.String bulkBuySecondCategory__c,
           com.sforce.soap.enterprise.QueryResult childDealGroup__r,
           java.lang.String cityID__c,
           java.lang.String companyNumber__c,
           java.lang.String contractStatus__c,
           java.lang.String contract__c,
           com.sforce.soap.enterprise.sobject.Contract contract__r,
           com.sforce.soap.enterprise.sobject.User createdBy,
           java.lang.String createdById,
           java.util.Calendar createdDate,
           java.lang.Double dealCount__c,
           java.lang.String dealGroupAprStatus__c,
           java.lang.String dealGroupUpdTrack__c,
           com.sforce.soap.enterprise.QueryResult deal__r,
           java.lang.String dealgroupStage__c,
           com.sforce.soap.enterprise.QueryResult destinaion__r,
           java.util.Date endDate__c,
           com.sforce.soap.enterprise.QueryResult events,
           com.sforce.soap.enterprise.QueryResult histories,
           java.lang.String infoConfirmed__c,
           java.lang.Boolean isAutoRefund__c,
           java.lang.Boolean isCostChanged__c,
           java.lang.Boolean isDPDeliver__c,
           java.lang.Boolean isDeleted,
           java.lang.String isECommerceDG__c,
           java.lang.Boolean isNeedApprovalMgr1__c,
           java.lang.Boolean isNeedApproval__c,
           java.lang.Boolean isNeedProjectTeamApr__c,
           java.lang.String isOnApprovaling__c,
           java.lang.Boolean isTerminateDealGroup__c,
           java.lang.Boolean isVip__c,
           java.util.Date lastActivityDate,
           com.sforce.soap.enterprise.sobject.User lastModifiedBy,
           java.lang.String lastModifiedById,
           java.util.Calendar lastModifiedDate,
           java.lang.Double maxPerUser__c,
           com.sforce.soap.enterprise.QueryResult monthlyPerformanceActual__r,
           java.lang.String name,
           java.lang.Double needAllowance__c,
           com.sforce.soap.enterprise.QueryResult notes,
           com.sforce.soap.enterprise.QueryResult notesAndAttachments,
           java.util.Date onlineDate__c,
           java.lang.Double onlineDayLength__c,
           com.sforce.soap.enterprise.QueryResult openActivities,
           com.sforce.soap.enterprise.sobject.Name owner,
           java.lang.String ownerId,
           java.lang.String passwdAccepterEmail__c,
           java.lang.String passwdAccepterPhone__c,
           java.lang.String passwdAccepter__c,
           java.util.Date planBeginDate__c,
           com.sforce.soap.enterprise.QueryResult processInstances,
           com.sforce.soap.enterprise.QueryResult processSteps,
           java.lang.Boolean provideInvoice__c,
           java.lang.String publishCitys__c,
           java.lang.String publishType__c,
           java.lang.String receiptType__c,
           java.lang.String sourceDealGroup__c,
           com.sforce.soap.enterprise.sobject.DealGroup__c sourceDealGroup__r,
           java.lang.String supportPoints__c,
           java.lang.String sysDealGroupId__c,
           java.lang.String sysDealGroupUrl__c,
           java.util.Calendar systemModstamp,
           com.sforce.soap.enterprise.QueryResult tasks,
           com.sforce.soap.enterprise.QueryResult tgCategory__r,
           java.lang.String varificationProvider__c,
           java.lang.String verifyType__c,
           java.lang.String isProduced__c,
           java.util.Calendar offLineTime__c,
           java.lang.String onlineStatus__c) {
        super(
            fieldsToNull,
            id);
        this.accountName__c = accountName__c;
        this.activityHistories = activityHistories;
        this.allowanceFlag__c = allowanceFlag__c;
        this.approvalMgr1__c = approvalMgr1__c;
        this.approvalMgr1__r = approvalMgr1__r;
        this.approvalMgr2__c = approvalMgr2__c;
        this.approvalMgr2__r = approvalMgr2__r;
        this.approvalMgr3__c = approvalMgr3__c;
        this.approvalMgr3__r = approvalMgr3__r;
        this.attachments = attachments;
        this.beginDate__c = beginDate__c;
        this.blackDate__c = blackDate__c;
        this.bulkBuyFirstCategory__c = bulkBuyFirstCategory__c;
        this.bulkBuySecondCategory__c = bulkBuySecondCategory__c;
        this.childDealGroup__r = childDealGroup__r;
        this.cityID__c = cityID__c;
        this.companyNumber__c = companyNumber__c;
        this.contractStatus__c = contractStatus__c;
        this.contract__c = contract__c;
        this.contract__r = contract__r;
        this.createdBy = createdBy;
        this.createdById = createdById;
        this.createdDate = createdDate;
        this.dealCount__c = dealCount__c;
        this.dealGroupAprStatus__c = dealGroupAprStatus__c;
        this.dealGroupUpdTrack__c = dealGroupUpdTrack__c;
        this.deal__r = deal__r;
        this.dealgroupStage__c = dealgroupStage__c;
        this.destinaion__r = destinaion__r;
        this.endDate__c = endDate__c;
        this.events = events;
        this.histories = histories;
        this.infoConfirmed__c = infoConfirmed__c;
        this.isAutoRefund__c = isAutoRefund__c;
        this.isCostChanged__c = isCostChanged__c;
        this.isDPDeliver__c = isDPDeliver__c;
        this.isDeleted = isDeleted;
        this.isECommerceDG__c = isECommerceDG__c;
        this.isNeedApprovalMgr1__c = isNeedApprovalMgr1__c;
        this.isNeedApproval__c = isNeedApproval__c;
        this.isNeedProjectTeamApr__c = isNeedProjectTeamApr__c;
        this.isOnApprovaling__c = isOnApprovaling__c;
        this.isTerminateDealGroup__c = isTerminateDealGroup__c;
        this.isVip__c = isVip__c;
        this.lastActivityDate = lastActivityDate;
        this.lastModifiedBy = lastModifiedBy;
        this.lastModifiedById = lastModifiedById;
        this.lastModifiedDate = lastModifiedDate;
        this.maxPerUser__c = maxPerUser__c;
        this.monthlyPerformanceActual__r = monthlyPerformanceActual__r;
        this.name = name;
        this.needAllowance__c = needAllowance__c;
        this.notes = notes;
        this.notesAndAttachments = notesAndAttachments;
        this.onlineDate__c = onlineDate__c;
        this.onlineDayLength__c = onlineDayLength__c;
        this.openActivities = openActivities;
        this.owner = owner;
        this.ownerId = ownerId;
        this.passwdAccepterEmail__c = passwdAccepterEmail__c;
        this.passwdAccepterPhone__c = passwdAccepterPhone__c;
        this.passwdAccepter__c = passwdAccepter__c;
        this.planBeginDate__c = planBeginDate__c;
        this.processInstances = processInstances;
        this.processSteps = processSteps;
        this.provideInvoice__c = provideInvoice__c;
        this.publishCitys__c = publishCitys__c;
        this.publishType__c = publishType__c;
        this.receiptType__c = receiptType__c;
        this.sourceDealGroup__c = sourceDealGroup__c;
        this.sourceDealGroup__r = sourceDealGroup__r;
        this.supportPoints__c = supportPoints__c;
        this.sysDealGroupId__c = sysDealGroupId__c;
        this.sysDealGroupUrl__c = sysDealGroupUrl__c;
        this.systemModstamp = systemModstamp;
        this.tasks = tasks;
        this.tgCategory__r = tgCategory__r;
        this.varificationProvider__c = varificationProvider__c;
        this.verifyType__c = verifyType__c;
        this.isProduced__c = isProduced__c;
        this.offLineTime__c = offLineTime__c;
        this.onlineStatus__c = onlineStatus__c;
    }


    /**
     * Gets the accountName__c value for this DealGroup__c.
     * 
     * @return accountName__c
     */
    public java.lang.String getAccountName__c() {
        return accountName__c;
    }


    /**
     * Sets the accountName__c value for this DealGroup__c.
     * 
     * @param accountName__c
     */
    public void setAccountName__c(java.lang.String accountName__c) {
        this.accountName__c = accountName__c;
    }


    /**
     * Gets the activityHistories value for this DealGroup__c.
     * 
     * @return activityHistories
     */
    public com.sforce.soap.enterprise.QueryResult getActivityHistories() {
        return activityHistories;
    }


    /**
     * Sets the activityHistories value for this DealGroup__c.
     * 
     * @param activityHistories
     */
    public void setActivityHistories(com.sforce.soap.enterprise.QueryResult activityHistories) {
        this.activityHistories = activityHistories;
    }


    /**
     * Gets the allowanceFlag__c value for this DealGroup__c.
     * 
     * @return allowanceFlag__c
     */
    public java.lang.Boolean getAllowanceFlag__c() {
        return allowanceFlag__c;
    }


    /**
     * Sets the allowanceFlag__c value for this DealGroup__c.
     * 
     * @param allowanceFlag__c
     */
    public void setAllowanceFlag__c(java.lang.Boolean allowanceFlag__c) {
        this.allowanceFlag__c = allowanceFlag__c;
    }


    /**
     * Gets the approvalMgr1__c value for this DealGroup__c.
     * 
     * @return approvalMgr1__c
     */
    public java.lang.String getApprovalMgr1__c() {
        return approvalMgr1__c;
    }


    /**
     * Sets the approvalMgr1__c value for this DealGroup__c.
     * 
     * @param approvalMgr1__c
     */
    public void setApprovalMgr1__c(java.lang.String approvalMgr1__c) {
        this.approvalMgr1__c = approvalMgr1__c;
    }


    /**
     * Gets the approvalMgr1__r value for this DealGroup__c.
     * 
     * @return approvalMgr1__r
     */
    public com.sforce.soap.enterprise.sobject.User getApprovalMgr1__r() {
        return approvalMgr1__r;
    }


    /**
     * Sets the approvalMgr1__r value for this DealGroup__c.
     * 
     * @param approvalMgr1__r
     */
    public void setApprovalMgr1__r(com.sforce.soap.enterprise.sobject.User approvalMgr1__r) {
        this.approvalMgr1__r = approvalMgr1__r;
    }


    /**
     * Gets the approvalMgr2__c value for this DealGroup__c.
     * 
     * @return approvalMgr2__c
     */
    public java.lang.String getApprovalMgr2__c() {
        return approvalMgr2__c;
    }


    /**
     * Sets the approvalMgr2__c value for this DealGroup__c.
     * 
     * @param approvalMgr2__c
     */
    public void setApprovalMgr2__c(java.lang.String approvalMgr2__c) {
        this.approvalMgr2__c = approvalMgr2__c;
    }


    /**
     * Gets the approvalMgr2__r value for this DealGroup__c.
     * 
     * @return approvalMgr2__r
     */
    public com.sforce.soap.enterprise.sobject.User getApprovalMgr2__r() {
        return approvalMgr2__r;
    }


    /**
     * Sets the approvalMgr2__r value for this DealGroup__c.
     * 
     * @param approvalMgr2__r
     */
    public void setApprovalMgr2__r(com.sforce.soap.enterprise.sobject.User approvalMgr2__r) {
        this.approvalMgr2__r = approvalMgr2__r;
    }


    /**
     * Gets the approvalMgr3__c value for this DealGroup__c.
     * 
     * @return approvalMgr3__c
     */
    public java.lang.String getApprovalMgr3__c() {
        return approvalMgr3__c;
    }


    /**
     * Sets the approvalMgr3__c value for this DealGroup__c.
     * 
     * @param approvalMgr3__c
     */
    public void setApprovalMgr3__c(java.lang.String approvalMgr3__c) {
        this.approvalMgr3__c = approvalMgr3__c;
    }


    /**
     * Gets the approvalMgr3__r value for this DealGroup__c.
     * 
     * @return approvalMgr3__r
     */
    public com.sforce.soap.enterprise.sobject.User getApprovalMgr3__r() {
        return approvalMgr3__r;
    }


    /**
     * Sets the approvalMgr3__r value for this DealGroup__c.
     * 
     * @param approvalMgr3__r
     */
    public void setApprovalMgr3__r(com.sforce.soap.enterprise.sobject.User approvalMgr3__r) {
        this.approvalMgr3__r = approvalMgr3__r;
    }


    /**
     * Gets the attachments value for this DealGroup__c.
     * 
     * @return attachments
     */
    public com.sforce.soap.enterprise.QueryResult getAttachments() {
        return attachments;
    }


    /**
     * Sets the attachments value for this DealGroup__c.
     * 
     * @param attachments
     */
    public void setAttachments(com.sforce.soap.enterprise.QueryResult attachments) {
        this.attachments = attachments;
    }


    /**
     * Gets the beginDate__c value for this DealGroup__c.
     * 
     * @return beginDate__c
     */
    public java.util.Date getBeginDate__c() {
        return beginDate__c;
    }


    /**
     * Sets the beginDate__c value for this DealGroup__c.
     * 
     * @param beginDate__c
     */
    public void setBeginDate__c(java.util.Date beginDate__c) {
        this.beginDate__c = beginDate__c;
    }


    /**
     * Gets the blackDate__c value for this DealGroup__c.
     * 
     * @return blackDate__c
     */
    public java.lang.String getBlackDate__c() {
        return blackDate__c;
    }


    /**
     * Sets the blackDate__c value for this DealGroup__c.
     * 
     * @param blackDate__c
     */
    public void setBlackDate__c(java.lang.String blackDate__c) {
        this.blackDate__c = blackDate__c;
    }


    /**
     * Gets the bulkBuyFirstCategory__c value for this DealGroup__c.
     * 
     * @return bulkBuyFirstCategory__c
     */
    public java.lang.String getBulkBuyFirstCategory__c() {
        return bulkBuyFirstCategory__c;
    }


    /**
     * Sets the bulkBuyFirstCategory__c value for this DealGroup__c.
     * 
     * @param bulkBuyFirstCategory__c
     */
    public void setBulkBuyFirstCategory__c(java.lang.String bulkBuyFirstCategory__c) {
        this.bulkBuyFirstCategory__c = bulkBuyFirstCategory__c;
    }


    /**
     * Gets the bulkBuySecondCategory__c value for this DealGroup__c.
     * 
     * @return bulkBuySecondCategory__c
     */
    public java.lang.String getBulkBuySecondCategory__c() {
        return bulkBuySecondCategory__c;
    }


    /**
     * Sets the bulkBuySecondCategory__c value for this DealGroup__c.
     * 
     * @param bulkBuySecondCategory__c
     */
    public void setBulkBuySecondCategory__c(java.lang.String bulkBuySecondCategory__c) {
        this.bulkBuySecondCategory__c = bulkBuySecondCategory__c;
    }


    /**
     * Gets the childDealGroup__r value for this DealGroup__c.
     * 
     * @return childDealGroup__r
     */
    public com.sforce.soap.enterprise.QueryResult getChildDealGroup__r() {
        return childDealGroup__r;
    }


    /**
     * Sets the childDealGroup__r value for this DealGroup__c.
     * 
     * @param childDealGroup__r
     */
    public void setChildDealGroup__r(com.sforce.soap.enterprise.QueryResult childDealGroup__r) {
        this.childDealGroup__r = childDealGroup__r;
    }


    /**
     * Gets the cityID__c value for this DealGroup__c.
     * 
     * @return cityID__c
     */
    public java.lang.String getCityID__c() {
        return cityID__c;
    }


    /**
     * Sets the cityID__c value for this DealGroup__c.
     * 
     * @param cityID__c
     */
    public void setCityID__c(java.lang.String cityID__c) {
        this.cityID__c = cityID__c;
    }


    /**
     * Gets the companyNumber__c value for this DealGroup__c.
     * 
     * @return companyNumber__c
     */
    public java.lang.String getCompanyNumber__c() {
        return companyNumber__c;
    }


    /**
     * Sets the companyNumber__c value for this DealGroup__c.
     * 
     * @param companyNumber__c
     */
    public void setCompanyNumber__c(java.lang.String companyNumber__c) {
        this.companyNumber__c = companyNumber__c;
    }


    /**
     * Gets the contractStatus__c value for this DealGroup__c.
     * 
     * @return contractStatus__c
     */
    public java.lang.String getContractStatus__c() {
        return contractStatus__c;
    }


    /**
     * Sets the contractStatus__c value for this DealGroup__c.
     * 
     * @param contractStatus__c
     */
    public void setContractStatus__c(java.lang.String contractStatus__c) {
        this.contractStatus__c = contractStatus__c;
    }


    /**
     * Gets the contract__c value for this DealGroup__c.
     * 
     * @return contract__c
     */
    public java.lang.String getContract__c() {
        return contract__c;
    }


    /**
     * Sets the contract__c value for this DealGroup__c.
     * 
     * @param contract__c
     */
    public void setContract__c(java.lang.String contract__c) {
        this.contract__c = contract__c;
    }


    /**
     * Gets the contract__r value for this DealGroup__c.
     * 
     * @return contract__r
     */
    public com.sforce.soap.enterprise.sobject.Contract getContract__r() {
        return contract__r;
    }


    /**
     * Sets the contract__r value for this DealGroup__c.
     * 
     * @param contract__r
     */
    public void setContract__r(com.sforce.soap.enterprise.sobject.Contract contract__r) {
        this.contract__r = contract__r;
    }


    /**
     * Gets the createdBy value for this DealGroup__c.
     * 
     * @return createdBy
     */
    public com.sforce.soap.enterprise.sobject.User getCreatedBy() {
        return createdBy;
    }


    /**
     * Sets the createdBy value for this DealGroup__c.
     * 
     * @param createdBy
     */
    public void setCreatedBy(com.sforce.soap.enterprise.sobject.User createdBy) {
        this.createdBy = createdBy;
    }


    /**
     * Gets the createdById value for this DealGroup__c.
     * 
     * @return createdById
     */
    public java.lang.String getCreatedById() {
        return createdById;
    }


    /**
     * Sets the createdById value for this DealGroup__c.
     * 
     * @param createdById
     */
    public void setCreatedById(java.lang.String createdById) {
        this.createdById = createdById;
    }


    /**
     * Gets the createdDate value for this DealGroup__c.
     * 
     * @return createdDate
     */
    public java.util.Calendar getCreatedDate() {
        return createdDate;
    }


    /**
     * Sets the createdDate value for this DealGroup__c.
     * 
     * @param createdDate
     */
    public void setCreatedDate(java.util.Calendar createdDate) {
        this.createdDate = createdDate;
    }


    /**
     * Gets the dealCount__c value for this DealGroup__c.
     * 
     * @return dealCount__c
     */
    public java.lang.Double getDealCount__c() {
        return dealCount__c;
    }


    /**
     * Sets the dealCount__c value for this DealGroup__c.
     * 
     * @param dealCount__c
     */
    public void setDealCount__c(java.lang.Double dealCount__c) {
        this.dealCount__c = dealCount__c;
    }


    /**
     * Gets the dealGroupAprStatus__c value for this DealGroup__c.
     * 
     * @return dealGroupAprStatus__c
     */
    public java.lang.String getDealGroupAprStatus__c() {
        return dealGroupAprStatus__c;
    }


    /**
     * Sets the dealGroupAprStatus__c value for this DealGroup__c.
     * 
     * @param dealGroupAprStatus__c
     */
    public void setDealGroupAprStatus__c(java.lang.String dealGroupAprStatus__c) {
        this.dealGroupAprStatus__c = dealGroupAprStatus__c;
    }


    /**
     * Gets the dealGroupUpdTrack__c value for this DealGroup__c.
     * 
     * @return dealGroupUpdTrack__c
     */
    public java.lang.String getDealGroupUpdTrack__c() {
        return dealGroupUpdTrack__c;
    }


    /**
     * Sets the dealGroupUpdTrack__c value for this DealGroup__c.
     * 
     * @param dealGroupUpdTrack__c
     */
    public void setDealGroupUpdTrack__c(java.lang.String dealGroupUpdTrack__c) {
        this.dealGroupUpdTrack__c = dealGroupUpdTrack__c;
    }


    /**
     * Gets the deal__r value for this DealGroup__c.
     * 
     * @return deal__r
     */
    public com.sforce.soap.enterprise.QueryResult getDeal__r() {
        return deal__r;
    }


    /**
     * Sets the deal__r value for this DealGroup__c.
     * 
     * @param deal__r
     */
    public void setDeal__r(com.sforce.soap.enterprise.QueryResult deal__r) {
        this.deal__r = deal__r;
    }


    /**
     * Gets the dealgroupStage__c value for this DealGroup__c.
     * 
     * @return dealgroupStage__c
     */
    public java.lang.String getDealgroupStage__c() {
        return dealgroupStage__c;
    }


    /**
     * Sets the dealgroupStage__c value for this DealGroup__c.
     * 
     * @param dealgroupStage__c
     */
    public void setDealgroupStage__c(java.lang.String dealgroupStage__c) {
        this.dealgroupStage__c = dealgroupStage__c;
    }


    /**
     * Gets the destinaion__r value for this DealGroup__c.
     * 
     * @return destinaion__r
     */
    public com.sforce.soap.enterprise.QueryResult getDestinaion__r() {
        return destinaion__r;
    }


    /**
     * Sets the destinaion__r value for this DealGroup__c.
     * 
     * @param destinaion__r
     */
    public void setDestinaion__r(com.sforce.soap.enterprise.QueryResult destinaion__r) {
        this.destinaion__r = destinaion__r;
    }


    /**
     * Gets the endDate__c value for this DealGroup__c.
     * 
     * @return endDate__c
     */
    public java.util.Date getEndDate__c() {
        return endDate__c;
    }


    /**
     * Sets the endDate__c value for this DealGroup__c.
     * 
     * @param endDate__c
     */
    public void setEndDate__c(java.util.Date endDate__c) {
        this.endDate__c = endDate__c;
    }


    /**
     * Gets the events value for this DealGroup__c.
     * 
     * @return events
     */
    public com.sforce.soap.enterprise.QueryResult getEvents() {
        return events;
    }


    /**
     * Sets the events value for this DealGroup__c.
     * 
     * @param events
     */
    public void setEvents(com.sforce.soap.enterprise.QueryResult events) {
        this.events = events;
    }


    /**
     * Gets the histories value for this DealGroup__c.
     * 
     * @return histories
     */
    public com.sforce.soap.enterprise.QueryResult getHistories() {
        return histories;
    }


    /**
     * Sets the histories value for this DealGroup__c.
     * 
     * @param histories
     */
    public void setHistories(com.sforce.soap.enterprise.QueryResult histories) {
        this.histories = histories;
    }


    /**
     * Gets the infoConfirmed__c value for this DealGroup__c.
     * 
     * @return infoConfirmed__c
     */
    public java.lang.String getInfoConfirmed__c() {
        return infoConfirmed__c;
    }


    /**
     * Sets the infoConfirmed__c value for this DealGroup__c.
     * 
     * @param infoConfirmed__c
     */
    public void setInfoConfirmed__c(java.lang.String infoConfirmed__c) {
        this.infoConfirmed__c = infoConfirmed__c;
    }


    /**
     * Gets the isAutoRefund__c value for this DealGroup__c.
     * 
     * @return isAutoRefund__c
     */
    public java.lang.Boolean getIsAutoRefund__c() {
        return isAutoRefund__c;
    }


    /**
     * Sets the isAutoRefund__c value for this DealGroup__c.
     * 
     * @param isAutoRefund__c
     */
    public void setIsAutoRefund__c(java.lang.Boolean isAutoRefund__c) {
        this.isAutoRefund__c = isAutoRefund__c;
    }


    /**
     * Gets the isCostChanged__c value for this DealGroup__c.
     * 
     * @return isCostChanged__c
     */
    public java.lang.Boolean getIsCostChanged__c() {
        return isCostChanged__c;
    }


    /**
     * Sets the isCostChanged__c value for this DealGroup__c.
     * 
     * @param isCostChanged__c
     */
    public void setIsCostChanged__c(java.lang.Boolean isCostChanged__c) {
        this.isCostChanged__c = isCostChanged__c;
    }


    /**
     * Gets the isDPDeliver__c value for this DealGroup__c.
     * 
     * @return isDPDeliver__c
     */
    public java.lang.Boolean getIsDPDeliver__c() {
        return isDPDeliver__c;
    }


    /**
     * Sets the isDPDeliver__c value for this DealGroup__c.
     * 
     * @param isDPDeliver__c
     */
    public void setIsDPDeliver__c(java.lang.Boolean isDPDeliver__c) {
        this.isDPDeliver__c = isDPDeliver__c;
    }


    /**
     * Gets the isDeleted value for this DealGroup__c.
     * 
     * @return isDeleted
     */
    public java.lang.Boolean getIsDeleted() {
        return isDeleted;
    }


    /**
     * Sets the isDeleted value for this DealGroup__c.
     * 
     * @param isDeleted
     */
    public void setIsDeleted(java.lang.Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }


    /**
     * Gets the isECommerceDG__c value for this DealGroup__c.
     * 
     * @return isECommerceDG__c
     */
    public java.lang.String getIsECommerceDG__c() {
        return isECommerceDG__c;
    }


    /**
     * Sets the isECommerceDG__c value for this DealGroup__c.
     * 
     * @param isECommerceDG__c
     */
    public void setIsECommerceDG__c(java.lang.String isECommerceDG__c) {
        this.isECommerceDG__c = isECommerceDG__c;
    }


    /**
     * Gets the isNeedApprovalMgr1__c value for this DealGroup__c.
     * 
     * @return isNeedApprovalMgr1__c
     */
    public java.lang.Boolean getIsNeedApprovalMgr1__c() {
        return isNeedApprovalMgr1__c;
    }


    /**
     * Sets the isNeedApprovalMgr1__c value for this DealGroup__c.
     * 
     * @param isNeedApprovalMgr1__c
     */
    public void setIsNeedApprovalMgr1__c(java.lang.Boolean isNeedApprovalMgr1__c) {
        this.isNeedApprovalMgr1__c = isNeedApprovalMgr1__c;
    }


    /**
     * Gets the isNeedApproval__c value for this DealGroup__c.
     * 
     * @return isNeedApproval__c
     */
    public java.lang.Boolean getIsNeedApproval__c() {
        return isNeedApproval__c;
    }


    /**
     * Sets the isNeedApproval__c value for this DealGroup__c.
     * 
     * @param isNeedApproval__c
     */
    public void setIsNeedApproval__c(java.lang.Boolean isNeedApproval__c) {
        this.isNeedApproval__c = isNeedApproval__c;
    }


    /**
     * Gets the isNeedProjectTeamApr__c value for this DealGroup__c.
     * 
     * @return isNeedProjectTeamApr__c
     */
    public java.lang.Boolean getIsNeedProjectTeamApr__c() {
        return isNeedProjectTeamApr__c;
    }


    /**
     * Sets the isNeedProjectTeamApr__c value for this DealGroup__c.
     * 
     * @param isNeedProjectTeamApr__c
     */
    public void setIsNeedProjectTeamApr__c(java.lang.Boolean isNeedProjectTeamApr__c) {
        this.isNeedProjectTeamApr__c = isNeedProjectTeamApr__c;
    }


    /**
     * Gets the isOnApprovaling__c value for this DealGroup__c.
     * 
     * @return isOnApprovaling__c
     */
    public java.lang.String getIsOnApprovaling__c() {
        return isOnApprovaling__c;
    }


    /**
     * Sets the isOnApprovaling__c value for this DealGroup__c.
     * 
     * @param isOnApprovaling__c
     */
    public void setIsOnApprovaling__c(java.lang.String isOnApprovaling__c) {
        this.isOnApprovaling__c = isOnApprovaling__c;
    }


    /**
     * Gets the isTerminateDealGroup__c value for this DealGroup__c.
     * 
     * @return isTerminateDealGroup__c
     */
    public java.lang.Boolean getIsTerminateDealGroup__c() {
        return isTerminateDealGroup__c;
    }


    /**
     * Sets the isTerminateDealGroup__c value for this DealGroup__c.
     * 
     * @param isTerminateDealGroup__c
     */
    public void setIsTerminateDealGroup__c(java.lang.Boolean isTerminateDealGroup__c) {
        this.isTerminateDealGroup__c = isTerminateDealGroup__c;
    }


    /**
     * Gets the isVip__c value for this DealGroup__c.
     * 
     * @return isVip__c
     */
    public java.lang.Boolean getIsVip__c() {
        return isVip__c;
    }


    /**
     * Sets the isVip__c value for this DealGroup__c.
     * 
     * @param isVip__c
     */
    public void setIsVip__c(java.lang.Boolean isVip__c) {
        this.isVip__c = isVip__c;
    }


    /**
     * Gets the lastActivityDate value for this DealGroup__c.
     * 
     * @return lastActivityDate
     */
    public java.util.Date getLastActivityDate() {
        return lastActivityDate;
    }


    /**
     * Sets the lastActivityDate value for this DealGroup__c.
     * 
     * @param lastActivityDate
     */
    public void setLastActivityDate(java.util.Date lastActivityDate) {
        this.lastActivityDate = lastActivityDate;
    }


    /**
     * Gets the lastModifiedBy value for this DealGroup__c.
     * 
     * @return lastModifiedBy
     */
    public com.sforce.soap.enterprise.sobject.User getLastModifiedBy() {
        return lastModifiedBy;
    }


    /**
     * Sets the lastModifiedBy value for this DealGroup__c.
     * 
     * @param lastModifiedBy
     */
    public void setLastModifiedBy(com.sforce.soap.enterprise.sobject.User lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }


    /**
     * Gets the lastModifiedById value for this DealGroup__c.
     * 
     * @return lastModifiedById
     */
    public java.lang.String getLastModifiedById() {
        return lastModifiedById;
    }


    /**
     * Sets the lastModifiedById value for this DealGroup__c.
     * 
     * @param lastModifiedById
     */
    public void setLastModifiedById(java.lang.String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }


    /**
     * Gets the lastModifiedDate value for this DealGroup__c.
     * 
     * @return lastModifiedDate
     */
    public java.util.Calendar getLastModifiedDate() {
        return lastModifiedDate;
    }


    /**
     * Sets the lastModifiedDate value for this DealGroup__c.
     * 
     * @param lastModifiedDate
     */
    public void setLastModifiedDate(java.util.Calendar lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }


    /**
     * Gets the maxPerUser__c value for this DealGroup__c.
     * 
     * @return maxPerUser__c
     */
    public java.lang.Double getMaxPerUser__c() {
        return maxPerUser__c;
    }


    /**
     * Sets the maxPerUser__c value for this DealGroup__c.
     * 
     * @param maxPerUser__c
     */
    public void setMaxPerUser__c(java.lang.Double maxPerUser__c) {
        this.maxPerUser__c = maxPerUser__c;
    }


    /**
     * Gets the monthlyPerformanceActual__r value for this DealGroup__c.
     * 
     * @return monthlyPerformanceActual__r
     */
    public com.sforce.soap.enterprise.QueryResult getMonthlyPerformanceActual__r() {
        return monthlyPerformanceActual__r;
    }


    /**
     * Sets the monthlyPerformanceActual__r value for this DealGroup__c.
     * 
     * @param monthlyPerformanceActual__r
     */
    public void setMonthlyPerformanceActual__r(com.sforce.soap.enterprise.QueryResult monthlyPerformanceActual__r) {
        this.monthlyPerformanceActual__r = monthlyPerformanceActual__r;
    }


    /**
     * Gets the name value for this DealGroup__c.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this DealGroup__c.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the needAllowance__c value for this DealGroup__c.
     * 
     * @return needAllowance__c
     */
    public java.lang.Double getNeedAllowance__c() {
        return needAllowance__c;
    }


    /**
     * Sets the needAllowance__c value for this DealGroup__c.
     * 
     * @param needAllowance__c
     */
    public void setNeedAllowance__c(java.lang.Double needAllowance__c) {
        this.needAllowance__c = needAllowance__c;
    }


    /**
     * Gets the notes value for this DealGroup__c.
     * 
     * @return notes
     */
    public com.sforce.soap.enterprise.QueryResult getNotes() {
        return notes;
    }


    /**
     * Sets the notes value for this DealGroup__c.
     * 
     * @param notes
     */
    public void setNotes(com.sforce.soap.enterprise.QueryResult notes) {
        this.notes = notes;
    }


    /**
     * Gets the notesAndAttachments value for this DealGroup__c.
     * 
     * @return notesAndAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getNotesAndAttachments() {
        return notesAndAttachments;
    }


    /**
     * Sets the notesAndAttachments value for this DealGroup__c.
     * 
     * @param notesAndAttachments
     */
    public void setNotesAndAttachments(com.sforce.soap.enterprise.QueryResult notesAndAttachments) {
        this.notesAndAttachments = notesAndAttachments;
    }


    /**
     * Gets the onlineDate__c value for this DealGroup__c.
     * 
     * @return onlineDate__c
     */
    public java.util.Date getOnlineDate__c() {
        return onlineDate__c;
    }


    /**
     * Sets the onlineDate__c value for this DealGroup__c.
     * 
     * @param onlineDate__c
     */
    public void setOnlineDate__c(java.util.Date onlineDate__c) {
        this.onlineDate__c = onlineDate__c;
    }


    /**
     * Gets the onlineDayLength__c value for this DealGroup__c.
     * 
     * @return onlineDayLength__c
     */
    public java.lang.Double getOnlineDayLength__c() {
        return onlineDayLength__c;
    }


    /**
     * Sets the onlineDayLength__c value for this DealGroup__c.
     * 
     * @param onlineDayLength__c
     */
    public void setOnlineDayLength__c(java.lang.Double onlineDayLength__c) {
        this.onlineDayLength__c = onlineDayLength__c;
    }


    /**
     * Gets the openActivities value for this DealGroup__c.
     * 
     * @return openActivities
     */
    public com.sforce.soap.enterprise.QueryResult getOpenActivities() {
        return openActivities;
    }


    /**
     * Sets the openActivities value for this DealGroup__c.
     * 
     * @param openActivities
     */
    public void setOpenActivities(com.sforce.soap.enterprise.QueryResult openActivities) {
        this.openActivities = openActivities;
    }


    /**
     * Gets the owner value for this DealGroup__c.
     * 
     * @return owner
     */
    public com.sforce.soap.enterprise.sobject.Name getOwner() {
        return owner;
    }


    /**
     * Sets the owner value for this DealGroup__c.
     * 
     * @param owner
     */
    public void setOwner(com.sforce.soap.enterprise.sobject.Name owner) {
        this.owner = owner;
    }


    /**
     * Gets the ownerId value for this DealGroup__c.
     * 
     * @return ownerId
     */
    public java.lang.String getOwnerId() {
        return ownerId;
    }


    /**
     * Sets the ownerId value for this DealGroup__c.
     * 
     * @param ownerId
     */
    public void setOwnerId(java.lang.String ownerId) {
        this.ownerId = ownerId;
    }


    /**
     * Gets the passwdAccepterEmail__c value for this DealGroup__c.
     * 
     * @return passwdAccepterEmail__c
     */
    public java.lang.String getPasswdAccepterEmail__c() {
        return passwdAccepterEmail__c;
    }


    /**
     * Sets the passwdAccepterEmail__c value for this DealGroup__c.
     * 
     * @param passwdAccepterEmail__c
     */
    public void setPasswdAccepterEmail__c(java.lang.String passwdAccepterEmail__c) {
        this.passwdAccepterEmail__c = passwdAccepterEmail__c;
    }


    /**
     * Gets the passwdAccepterPhone__c value for this DealGroup__c.
     * 
     * @return passwdAccepterPhone__c
     */
    public java.lang.String getPasswdAccepterPhone__c() {
        return passwdAccepterPhone__c;
    }


    /**
     * Sets the passwdAccepterPhone__c value for this DealGroup__c.
     * 
     * @param passwdAccepterPhone__c
     */
    public void setPasswdAccepterPhone__c(java.lang.String passwdAccepterPhone__c) {
        this.passwdAccepterPhone__c = passwdAccepterPhone__c;
    }


    /**
     * Gets the passwdAccepter__c value for this DealGroup__c.
     * 
     * @return passwdAccepter__c
     */
    public java.lang.String getPasswdAccepter__c() {
        return passwdAccepter__c;
    }


    /**
     * Sets the passwdAccepter__c value for this DealGroup__c.
     * 
     * @param passwdAccepter__c
     */
    public void setPasswdAccepter__c(java.lang.String passwdAccepter__c) {
        this.passwdAccepter__c = passwdAccepter__c;
    }


    /**
     * Gets the planBeginDate__c value for this DealGroup__c.
     * 
     * @return planBeginDate__c
     */
    public java.util.Date getPlanBeginDate__c() {
        return planBeginDate__c;
    }


    /**
     * Sets the planBeginDate__c value for this DealGroup__c.
     * 
     * @param planBeginDate__c
     */
    public void setPlanBeginDate__c(java.util.Date planBeginDate__c) {
        this.planBeginDate__c = planBeginDate__c;
    }


    /**
     * Gets the processInstances value for this DealGroup__c.
     * 
     * @return processInstances
     */
    public com.sforce.soap.enterprise.QueryResult getProcessInstances() {
        return processInstances;
    }


    /**
     * Sets the processInstances value for this DealGroup__c.
     * 
     * @param processInstances
     */
    public void setProcessInstances(com.sforce.soap.enterprise.QueryResult processInstances) {
        this.processInstances = processInstances;
    }


    /**
     * Gets the processSteps value for this DealGroup__c.
     * 
     * @return processSteps
     */
    public com.sforce.soap.enterprise.QueryResult getProcessSteps() {
        return processSteps;
    }


    /**
     * Sets the processSteps value for this DealGroup__c.
     * 
     * @param processSteps
     */
    public void setProcessSteps(com.sforce.soap.enterprise.QueryResult processSteps) {
        this.processSteps = processSteps;
    }


    /**
     * Gets the provideInvoice__c value for this DealGroup__c.
     * 
     * @return provideInvoice__c
     */
    public java.lang.Boolean getProvideInvoice__c() {
        return provideInvoice__c;
    }


    /**
     * Sets the provideInvoice__c value for this DealGroup__c.
     * 
     * @param provideInvoice__c
     */
    public void setProvideInvoice__c(java.lang.Boolean provideInvoice__c) {
        this.provideInvoice__c = provideInvoice__c;
    }


    /**
     * Gets the publishCitys__c value for this DealGroup__c.
     * 
     * @return publishCitys__c
     */
    public java.lang.String getPublishCitys__c() {
        return publishCitys__c;
    }


    /**
     * Sets the publishCitys__c value for this DealGroup__c.
     * 
     * @param publishCitys__c
     */
    public void setPublishCitys__c(java.lang.String publishCitys__c) {
        this.publishCitys__c = publishCitys__c;
    }


    /**
     * Gets the publishType__c value for this DealGroup__c.
     * 
     * @return publishType__c
     */
    public java.lang.String getPublishType__c() {
        return publishType__c;
    }


    /**
     * Sets the publishType__c value for this DealGroup__c.
     * 
     * @param publishType__c
     */
    public void setPublishType__c(java.lang.String publishType__c) {
        this.publishType__c = publishType__c;
    }


    /**
     * Gets the receiptType__c value for this DealGroup__c.
     * 
     * @return receiptType__c
     */
    public java.lang.String getReceiptType__c() {
        return receiptType__c;
    }


    /**
     * Sets the receiptType__c value for this DealGroup__c.
     * 
     * @param receiptType__c
     */
    public void setReceiptType__c(java.lang.String receiptType__c) {
        this.receiptType__c = receiptType__c;
    }


    /**
     * Gets the sourceDealGroup__c value for this DealGroup__c.
     * 
     * @return sourceDealGroup__c
     */
    public java.lang.String getSourceDealGroup__c() {
        return sourceDealGroup__c;
    }


    /**
     * Sets the sourceDealGroup__c value for this DealGroup__c.
     * 
     * @param sourceDealGroup__c
     */
    public void setSourceDealGroup__c(java.lang.String sourceDealGroup__c) {
        this.sourceDealGroup__c = sourceDealGroup__c;
    }


    /**
     * Gets the sourceDealGroup__r value for this DealGroup__c.
     * 
     * @return sourceDealGroup__r
     */
    public com.sforce.soap.enterprise.sobject.DealGroup__c getSourceDealGroup__r() {
        return sourceDealGroup__r;
    }


    /**
     * Sets the sourceDealGroup__r value for this DealGroup__c.
     * 
     * @param sourceDealGroup__r
     */
    public void setSourceDealGroup__r(com.sforce.soap.enterprise.sobject.DealGroup__c sourceDealGroup__r) {
        this.sourceDealGroup__r = sourceDealGroup__r;
    }


    /**
     * Gets the supportPoints__c value for this DealGroup__c.
     * 
     * @return supportPoints__c
     */
    public java.lang.String getSupportPoints__c() {
        return supportPoints__c;
    }


    /**
     * Sets the supportPoints__c value for this DealGroup__c.
     * 
     * @param supportPoints__c
     */
    public void setSupportPoints__c(java.lang.String supportPoints__c) {
        this.supportPoints__c = supportPoints__c;
    }


    /**
     * Gets the sysDealGroupId__c value for this DealGroup__c.
     * 
     * @return sysDealGroupId__c
     */
    public java.lang.String getSysDealGroupId__c() {
        return sysDealGroupId__c;
    }


    /**
     * Sets the sysDealGroupId__c value for this DealGroup__c.
     * 
     * @param sysDealGroupId__c
     */
    public void setSysDealGroupId__c(java.lang.String sysDealGroupId__c) {
        this.sysDealGroupId__c = sysDealGroupId__c;
    }


    /**
     * Gets the sysDealGroupUrl__c value for this DealGroup__c.
     * 
     * @return sysDealGroupUrl__c
     */
    public java.lang.String getSysDealGroupUrl__c() {
        return sysDealGroupUrl__c;
    }


    /**
     * Sets the sysDealGroupUrl__c value for this DealGroup__c.
     * 
     * @param sysDealGroupUrl__c
     */
    public void setSysDealGroupUrl__c(java.lang.String sysDealGroupUrl__c) {
        this.sysDealGroupUrl__c = sysDealGroupUrl__c;
    }


    /**
     * Gets the systemModstamp value for this DealGroup__c.
     * 
     * @return systemModstamp
     */
    public java.util.Calendar getSystemModstamp() {
        return systemModstamp;
    }


    /**
     * Sets the systemModstamp value for this DealGroup__c.
     * 
     * @param systemModstamp
     */
    public void setSystemModstamp(java.util.Calendar systemModstamp) {
        this.systemModstamp = systemModstamp;
    }


    /**
     * Gets the tasks value for this DealGroup__c.
     * 
     * @return tasks
     */
    public com.sforce.soap.enterprise.QueryResult getTasks() {
        return tasks;
    }


    /**
     * Sets the tasks value for this DealGroup__c.
     * 
     * @param tasks
     */
    public void setTasks(com.sforce.soap.enterprise.QueryResult tasks) {
        this.tasks = tasks;
    }


    /**
     * Gets the tgCategory__r value for this DealGroup__c.
     * 
     * @return tgCategory__r
     */
    public com.sforce.soap.enterprise.QueryResult getTgCategory__r() {
        return tgCategory__r;
    }


    /**
     * Sets the tgCategory__r value for this DealGroup__c.
     * 
     * @param tgCategory__r
     */
    public void setTgCategory__r(com.sforce.soap.enterprise.QueryResult tgCategory__r) {
        this.tgCategory__r = tgCategory__r;
    }


    /**
     * Gets the varificationProvider__c value for this DealGroup__c.
     * 
     * @return varificationProvider__c
     */
    public java.lang.String getVarificationProvider__c() {
        return varificationProvider__c;
    }


    /**
     * Sets the varificationProvider__c value for this DealGroup__c.
     * 
     * @param varificationProvider__c
     */
    public void setVarificationProvider__c(java.lang.String varificationProvider__c) {
        this.varificationProvider__c = varificationProvider__c;
    }


    /**
     * Gets the verifyType__c value for this DealGroup__c.
     * 
     * @return verifyType__c
     */
    public java.lang.String getVerifyType__c() {
        return verifyType__c;
    }


    /**
     * Sets the verifyType__c value for this DealGroup__c.
     * 
     * @param verifyType__c
     */
    public void setVerifyType__c(java.lang.String verifyType__c) {
        this.verifyType__c = verifyType__c;
    }


    /**
     * Gets the isProduced__c value for this DealGroup__c.
     * 
     * @return isProduced__c
     */
    public java.lang.String getIsProduced__c() {
        return isProduced__c;
    }


    /**
     * Sets the isProduced__c value for this DealGroup__c.
     * 
     * @param isProduced__c
     */
    public void setIsProduced__c(java.lang.String isProduced__c) {
        this.isProduced__c = isProduced__c;
    }


    /**
     * Gets the offLineTime__c value for this DealGroup__c.
     * 
     * @return offLineTime__c
     */
    public java.util.Calendar getOffLineTime__c() {
        return offLineTime__c;
    }


    /**
     * Sets the offLineTime__c value for this DealGroup__c.
     * 
     * @param offLineTime__c
     */
    public void setOffLineTime__c(java.util.Calendar offLineTime__c) {
        this.offLineTime__c = offLineTime__c;
    }


    /**
     * Gets the onlineStatus__c value for this DealGroup__c.
     * 
     * @return onlineStatus__c
     */
    public java.lang.String getOnlineStatus__c() {
        return onlineStatus__c;
    }


    /**
     * Sets the onlineStatus__c value for this DealGroup__c.
     * 
     * @param onlineStatus__c
     */
    public void setOnlineStatus__c(java.lang.String onlineStatus__c) {
        this.onlineStatus__c = onlineStatus__c;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DealGroup__c)) return false;
        DealGroup__c other = (DealGroup__c) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.accountName__c==null && other.getAccountName__c()==null) || 
             (this.accountName__c!=null &&
              this.accountName__c.equals(other.getAccountName__c()))) &&
            ((this.activityHistories==null && other.getActivityHistories()==null) || 
             (this.activityHistories!=null &&
              this.activityHistories.equals(other.getActivityHistories()))) &&
            ((this.allowanceFlag__c==null && other.getAllowanceFlag__c()==null) || 
             (this.allowanceFlag__c!=null &&
              this.allowanceFlag__c.equals(other.getAllowanceFlag__c()))) &&
            ((this.approvalMgr1__c==null && other.getApprovalMgr1__c()==null) || 
             (this.approvalMgr1__c!=null &&
              this.approvalMgr1__c.equals(other.getApprovalMgr1__c()))) &&
            ((this.approvalMgr1__r==null && other.getApprovalMgr1__r()==null) || 
             (this.approvalMgr1__r!=null &&
              this.approvalMgr1__r.equals(other.getApprovalMgr1__r()))) &&
            ((this.approvalMgr2__c==null && other.getApprovalMgr2__c()==null) || 
             (this.approvalMgr2__c!=null &&
              this.approvalMgr2__c.equals(other.getApprovalMgr2__c()))) &&
            ((this.approvalMgr2__r==null && other.getApprovalMgr2__r()==null) || 
             (this.approvalMgr2__r!=null &&
              this.approvalMgr2__r.equals(other.getApprovalMgr2__r()))) &&
            ((this.approvalMgr3__c==null && other.getApprovalMgr3__c()==null) || 
             (this.approvalMgr3__c!=null &&
              this.approvalMgr3__c.equals(other.getApprovalMgr3__c()))) &&
            ((this.approvalMgr3__r==null && other.getApprovalMgr3__r()==null) || 
             (this.approvalMgr3__r!=null &&
              this.approvalMgr3__r.equals(other.getApprovalMgr3__r()))) &&
            ((this.attachments==null && other.getAttachments()==null) || 
             (this.attachments!=null &&
              this.attachments.equals(other.getAttachments()))) &&
            ((this.beginDate__c==null && other.getBeginDate__c()==null) || 
             (this.beginDate__c!=null &&
              this.beginDate__c.equals(other.getBeginDate__c()))) &&
            ((this.blackDate__c==null && other.getBlackDate__c()==null) || 
             (this.blackDate__c!=null &&
              this.blackDate__c.equals(other.getBlackDate__c()))) &&
            ((this.bulkBuyFirstCategory__c==null && other.getBulkBuyFirstCategory__c()==null) || 
             (this.bulkBuyFirstCategory__c!=null &&
              this.bulkBuyFirstCategory__c.equals(other.getBulkBuyFirstCategory__c()))) &&
            ((this.bulkBuySecondCategory__c==null && other.getBulkBuySecondCategory__c()==null) || 
             (this.bulkBuySecondCategory__c!=null &&
              this.bulkBuySecondCategory__c.equals(other.getBulkBuySecondCategory__c()))) &&
            ((this.childDealGroup__r==null && other.getChildDealGroup__r()==null) || 
             (this.childDealGroup__r!=null &&
              this.childDealGroup__r.equals(other.getChildDealGroup__r()))) &&
            ((this.cityID__c==null && other.getCityID__c()==null) || 
             (this.cityID__c!=null &&
              this.cityID__c.equals(other.getCityID__c()))) &&
            ((this.companyNumber__c==null && other.getCompanyNumber__c()==null) || 
             (this.companyNumber__c!=null &&
              this.companyNumber__c.equals(other.getCompanyNumber__c()))) &&
            ((this.contractStatus__c==null && other.getContractStatus__c()==null) || 
             (this.contractStatus__c!=null &&
              this.contractStatus__c.equals(other.getContractStatus__c()))) &&
            ((this.contract__c==null && other.getContract__c()==null) || 
             (this.contract__c!=null &&
              this.contract__c.equals(other.getContract__c()))) &&
            ((this.contract__r==null && other.getContract__r()==null) || 
             (this.contract__r!=null &&
              this.contract__r.equals(other.getContract__r()))) &&
            ((this.createdBy==null && other.getCreatedBy()==null) || 
             (this.createdBy!=null &&
              this.createdBy.equals(other.getCreatedBy()))) &&
            ((this.createdById==null && other.getCreatedById()==null) || 
             (this.createdById!=null &&
              this.createdById.equals(other.getCreatedById()))) &&
            ((this.createdDate==null && other.getCreatedDate()==null) || 
             (this.createdDate!=null &&
              this.createdDate.equals(other.getCreatedDate()))) &&
            ((this.dealCount__c==null && other.getDealCount__c()==null) || 
             (this.dealCount__c!=null &&
              this.dealCount__c.equals(other.getDealCount__c()))) &&
            ((this.dealGroupAprStatus__c==null && other.getDealGroupAprStatus__c()==null) || 
             (this.dealGroupAprStatus__c!=null &&
              this.dealGroupAprStatus__c.equals(other.getDealGroupAprStatus__c()))) &&
            ((this.dealGroupUpdTrack__c==null && other.getDealGroupUpdTrack__c()==null) || 
             (this.dealGroupUpdTrack__c!=null &&
              this.dealGroupUpdTrack__c.equals(other.getDealGroupUpdTrack__c()))) &&
            ((this.deal__r==null && other.getDeal__r()==null) || 
             (this.deal__r!=null &&
              this.deal__r.equals(other.getDeal__r()))) &&
            ((this.dealgroupStage__c==null && other.getDealgroupStage__c()==null) || 
             (this.dealgroupStage__c!=null &&
              this.dealgroupStage__c.equals(other.getDealgroupStage__c()))) &&
            ((this.destinaion__r==null && other.getDestinaion__r()==null) || 
             (this.destinaion__r!=null &&
              this.destinaion__r.equals(other.getDestinaion__r()))) &&
            ((this.endDate__c==null && other.getEndDate__c()==null) || 
             (this.endDate__c!=null &&
              this.endDate__c.equals(other.getEndDate__c()))) &&
            ((this.events==null && other.getEvents()==null) || 
             (this.events!=null &&
              this.events.equals(other.getEvents()))) &&
            ((this.histories==null && other.getHistories()==null) || 
             (this.histories!=null &&
              this.histories.equals(other.getHistories()))) &&
            ((this.infoConfirmed__c==null && other.getInfoConfirmed__c()==null) || 
             (this.infoConfirmed__c!=null &&
              this.infoConfirmed__c.equals(other.getInfoConfirmed__c()))) &&
            ((this.isAutoRefund__c==null && other.getIsAutoRefund__c()==null) || 
             (this.isAutoRefund__c!=null &&
              this.isAutoRefund__c.equals(other.getIsAutoRefund__c()))) &&
            ((this.isCostChanged__c==null && other.getIsCostChanged__c()==null) || 
             (this.isCostChanged__c!=null &&
              this.isCostChanged__c.equals(other.getIsCostChanged__c()))) &&
            ((this.isDPDeliver__c==null && other.getIsDPDeliver__c()==null) || 
             (this.isDPDeliver__c!=null &&
              this.isDPDeliver__c.equals(other.getIsDPDeliver__c()))) &&
            ((this.isDeleted==null && other.getIsDeleted()==null) || 
             (this.isDeleted!=null &&
              this.isDeleted.equals(other.getIsDeleted()))) &&
            ((this.isECommerceDG__c==null && other.getIsECommerceDG__c()==null) || 
             (this.isECommerceDG__c!=null &&
              this.isECommerceDG__c.equals(other.getIsECommerceDG__c()))) &&
            ((this.isNeedApprovalMgr1__c==null && other.getIsNeedApprovalMgr1__c()==null) || 
             (this.isNeedApprovalMgr1__c!=null &&
              this.isNeedApprovalMgr1__c.equals(other.getIsNeedApprovalMgr1__c()))) &&
            ((this.isNeedApproval__c==null && other.getIsNeedApproval__c()==null) || 
             (this.isNeedApproval__c!=null &&
              this.isNeedApproval__c.equals(other.getIsNeedApproval__c()))) &&
            ((this.isNeedProjectTeamApr__c==null && other.getIsNeedProjectTeamApr__c()==null) || 
             (this.isNeedProjectTeamApr__c!=null &&
              this.isNeedProjectTeamApr__c.equals(other.getIsNeedProjectTeamApr__c()))) &&
            ((this.isOnApprovaling__c==null && other.getIsOnApprovaling__c()==null) || 
             (this.isOnApprovaling__c!=null &&
              this.isOnApprovaling__c.equals(other.getIsOnApprovaling__c()))) &&
            ((this.isTerminateDealGroup__c==null && other.getIsTerminateDealGroup__c()==null) || 
             (this.isTerminateDealGroup__c!=null &&
              this.isTerminateDealGroup__c.equals(other.getIsTerminateDealGroup__c()))) &&
            ((this.isVip__c==null && other.getIsVip__c()==null) || 
             (this.isVip__c!=null &&
              this.isVip__c.equals(other.getIsVip__c()))) &&
            ((this.lastActivityDate==null && other.getLastActivityDate()==null) || 
             (this.lastActivityDate!=null &&
              this.lastActivityDate.equals(other.getLastActivityDate()))) &&
            ((this.lastModifiedBy==null && other.getLastModifiedBy()==null) || 
             (this.lastModifiedBy!=null &&
              this.lastModifiedBy.equals(other.getLastModifiedBy()))) &&
            ((this.lastModifiedById==null && other.getLastModifiedById()==null) || 
             (this.lastModifiedById!=null &&
              this.lastModifiedById.equals(other.getLastModifiedById()))) &&
            ((this.lastModifiedDate==null && other.getLastModifiedDate()==null) || 
             (this.lastModifiedDate!=null &&
              this.lastModifiedDate.equals(other.getLastModifiedDate()))) &&
            ((this.maxPerUser__c==null && other.getMaxPerUser__c()==null) || 
             (this.maxPerUser__c!=null &&
              this.maxPerUser__c.equals(other.getMaxPerUser__c()))) &&
            ((this.monthlyPerformanceActual__r==null && other.getMonthlyPerformanceActual__r()==null) || 
             (this.monthlyPerformanceActual__r!=null &&
              this.monthlyPerformanceActual__r.equals(other.getMonthlyPerformanceActual__r()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.needAllowance__c==null && other.getNeedAllowance__c()==null) || 
             (this.needAllowance__c!=null &&
              this.needAllowance__c.equals(other.getNeedAllowance__c()))) &&
            ((this.notes==null && other.getNotes()==null) || 
             (this.notes!=null &&
              this.notes.equals(other.getNotes()))) &&
            ((this.notesAndAttachments==null && other.getNotesAndAttachments()==null) || 
             (this.notesAndAttachments!=null &&
              this.notesAndAttachments.equals(other.getNotesAndAttachments()))) &&
            ((this.onlineDate__c==null && other.getOnlineDate__c()==null) || 
             (this.onlineDate__c!=null &&
              this.onlineDate__c.equals(other.getOnlineDate__c()))) &&
            ((this.onlineDayLength__c==null && other.getOnlineDayLength__c()==null) || 
             (this.onlineDayLength__c!=null &&
              this.onlineDayLength__c.equals(other.getOnlineDayLength__c()))) &&
            ((this.openActivities==null && other.getOpenActivities()==null) || 
             (this.openActivities!=null &&
              this.openActivities.equals(other.getOpenActivities()))) &&
            ((this.owner==null && other.getOwner()==null) || 
             (this.owner!=null &&
              this.owner.equals(other.getOwner()))) &&
            ((this.ownerId==null && other.getOwnerId()==null) || 
             (this.ownerId!=null &&
              this.ownerId.equals(other.getOwnerId()))) &&
            ((this.passwdAccepterEmail__c==null && other.getPasswdAccepterEmail__c()==null) || 
             (this.passwdAccepterEmail__c!=null &&
              this.passwdAccepterEmail__c.equals(other.getPasswdAccepterEmail__c()))) &&
            ((this.passwdAccepterPhone__c==null && other.getPasswdAccepterPhone__c()==null) || 
             (this.passwdAccepterPhone__c!=null &&
              this.passwdAccepterPhone__c.equals(other.getPasswdAccepterPhone__c()))) &&
            ((this.passwdAccepter__c==null && other.getPasswdAccepter__c()==null) || 
             (this.passwdAccepter__c!=null &&
              this.passwdAccepter__c.equals(other.getPasswdAccepter__c()))) &&
            ((this.planBeginDate__c==null && other.getPlanBeginDate__c()==null) || 
             (this.planBeginDate__c!=null &&
              this.planBeginDate__c.equals(other.getPlanBeginDate__c()))) &&
            ((this.processInstances==null && other.getProcessInstances()==null) || 
             (this.processInstances!=null &&
              this.processInstances.equals(other.getProcessInstances()))) &&
            ((this.processSteps==null && other.getProcessSteps()==null) || 
             (this.processSteps!=null &&
              this.processSteps.equals(other.getProcessSteps()))) &&
            ((this.provideInvoice__c==null && other.getProvideInvoice__c()==null) || 
             (this.provideInvoice__c!=null &&
              this.provideInvoice__c.equals(other.getProvideInvoice__c()))) &&
            ((this.publishCitys__c==null && other.getPublishCitys__c()==null) || 
             (this.publishCitys__c!=null &&
              this.publishCitys__c.equals(other.getPublishCitys__c()))) &&
            ((this.publishType__c==null && other.getPublishType__c()==null) || 
             (this.publishType__c!=null &&
              this.publishType__c.equals(other.getPublishType__c()))) &&
            ((this.receiptType__c==null && other.getReceiptType__c()==null) || 
             (this.receiptType__c!=null &&
              this.receiptType__c.equals(other.getReceiptType__c()))) &&
            ((this.sourceDealGroup__c==null && other.getSourceDealGroup__c()==null) || 
             (this.sourceDealGroup__c!=null &&
              this.sourceDealGroup__c.equals(other.getSourceDealGroup__c()))) &&
            ((this.sourceDealGroup__r==null && other.getSourceDealGroup__r()==null) || 
             (this.sourceDealGroup__r!=null &&
              this.sourceDealGroup__r.equals(other.getSourceDealGroup__r()))) &&
            ((this.supportPoints__c==null && other.getSupportPoints__c()==null) || 
             (this.supportPoints__c!=null &&
              this.supportPoints__c.equals(other.getSupportPoints__c()))) &&
            ((this.sysDealGroupId__c==null && other.getSysDealGroupId__c()==null) || 
             (this.sysDealGroupId__c!=null &&
              this.sysDealGroupId__c.equals(other.getSysDealGroupId__c()))) &&
            ((this.sysDealGroupUrl__c==null && other.getSysDealGroupUrl__c()==null) || 
             (this.sysDealGroupUrl__c!=null &&
              this.sysDealGroupUrl__c.equals(other.getSysDealGroupUrl__c()))) &&
            ((this.systemModstamp==null && other.getSystemModstamp()==null) || 
             (this.systemModstamp!=null &&
              this.systemModstamp.equals(other.getSystemModstamp()))) &&
            ((this.tasks==null && other.getTasks()==null) || 
             (this.tasks!=null &&
              this.tasks.equals(other.getTasks()))) &&
            ((this.tgCategory__r==null && other.getTgCategory__r()==null) || 
             (this.tgCategory__r!=null &&
              this.tgCategory__r.equals(other.getTgCategory__r()))) &&
            ((this.varificationProvider__c==null && other.getVarificationProvider__c()==null) || 
             (this.varificationProvider__c!=null &&
              this.varificationProvider__c.equals(other.getVarificationProvider__c()))) &&
            ((this.verifyType__c==null && other.getVerifyType__c()==null) || 
             (this.verifyType__c!=null &&
              this.verifyType__c.equals(other.getVerifyType__c()))) &&
            ((this.isProduced__c==null && other.getIsProduced__c()==null) || 
             (this.isProduced__c!=null &&
              this.isProduced__c.equals(other.getIsProduced__c()))) &&
            ((this.offLineTime__c==null && other.getOffLineTime__c()==null) || 
             (this.offLineTime__c!=null &&
              this.offLineTime__c.equals(other.getOffLineTime__c()))) &&
            ((this.onlineStatus__c==null && other.getOnlineStatus__c()==null) || 
             (this.onlineStatus__c!=null &&
              this.onlineStatus__c.equals(other.getOnlineStatus__c())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAccountName__c() != null) {
            _hashCode += getAccountName__c().hashCode();
        }
        if (getActivityHistories() != null) {
            _hashCode += getActivityHistories().hashCode();
        }
        if (getAllowanceFlag__c() != null) {
            _hashCode += getAllowanceFlag__c().hashCode();
        }
        if (getApprovalMgr1__c() != null) {
            _hashCode += getApprovalMgr1__c().hashCode();
        }
        if (getApprovalMgr1__r() != null) {
            _hashCode += getApprovalMgr1__r().hashCode();
        }
        if (getApprovalMgr2__c() != null) {
            _hashCode += getApprovalMgr2__c().hashCode();
        }
        if (getApprovalMgr2__r() != null) {
            _hashCode += getApprovalMgr2__r().hashCode();
        }
        if (getApprovalMgr3__c() != null) {
            _hashCode += getApprovalMgr3__c().hashCode();
        }
        if (getApprovalMgr3__r() != null) {
            _hashCode += getApprovalMgr3__r().hashCode();
        }
        if (getAttachments() != null) {
            _hashCode += getAttachments().hashCode();
        }
        if (getBeginDate__c() != null) {
            _hashCode += getBeginDate__c().hashCode();
        }
        if (getBlackDate__c() != null) {
            _hashCode += getBlackDate__c().hashCode();
        }
        if (getBulkBuyFirstCategory__c() != null) {
            _hashCode += getBulkBuyFirstCategory__c().hashCode();
        }
        if (getBulkBuySecondCategory__c() != null) {
            _hashCode += getBulkBuySecondCategory__c().hashCode();
        }
        if (getChildDealGroup__r() != null) {
            _hashCode += getChildDealGroup__r().hashCode();
        }
        if (getCityID__c() != null) {
            _hashCode += getCityID__c().hashCode();
        }
        if (getCompanyNumber__c() != null) {
            _hashCode += getCompanyNumber__c().hashCode();
        }
        if (getContractStatus__c() != null) {
            _hashCode += getContractStatus__c().hashCode();
        }
        if (getContract__c() != null) {
            _hashCode += getContract__c().hashCode();
        }
        if (getContract__r() != null) {
            _hashCode += getContract__r().hashCode();
        }
        if (getCreatedBy() != null) {
            _hashCode += getCreatedBy().hashCode();
        }
        if (getCreatedById() != null) {
            _hashCode += getCreatedById().hashCode();
        }
        if (getCreatedDate() != null) {
            _hashCode += getCreatedDate().hashCode();
        }
        if (getDealCount__c() != null) {
            _hashCode += getDealCount__c().hashCode();
        }
        if (getDealGroupAprStatus__c() != null) {
            _hashCode += getDealGroupAprStatus__c().hashCode();
        }
        if (getDealGroupUpdTrack__c() != null) {
            _hashCode += getDealGroupUpdTrack__c().hashCode();
        }
        if (getDeal__r() != null) {
            _hashCode += getDeal__r().hashCode();
        }
        if (getDealgroupStage__c() != null) {
            _hashCode += getDealgroupStage__c().hashCode();
        }
        if (getDestinaion__r() != null) {
            _hashCode += getDestinaion__r().hashCode();
        }
        if (getEndDate__c() != null) {
            _hashCode += getEndDate__c().hashCode();
        }
        if (getEvents() != null) {
            _hashCode += getEvents().hashCode();
        }
        if (getHistories() != null) {
            _hashCode += getHistories().hashCode();
        }
        if (getInfoConfirmed__c() != null) {
            _hashCode += getInfoConfirmed__c().hashCode();
        }
        if (getIsAutoRefund__c() != null) {
            _hashCode += getIsAutoRefund__c().hashCode();
        }
        if (getIsCostChanged__c() != null) {
            _hashCode += getIsCostChanged__c().hashCode();
        }
        if (getIsDPDeliver__c() != null) {
            _hashCode += getIsDPDeliver__c().hashCode();
        }
        if (getIsDeleted() != null) {
            _hashCode += getIsDeleted().hashCode();
        }
        if (getIsECommerceDG__c() != null) {
            _hashCode += getIsECommerceDG__c().hashCode();
        }
        if (getIsNeedApprovalMgr1__c() != null) {
            _hashCode += getIsNeedApprovalMgr1__c().hashCode();
        }
        if (getIsNeedApproval__c() != null) {
            _hashCode += getIsNeedApproval__c().hashCode();
        }
        if (getIsNeedProjectTeamApr__c() != null) {
            _hashCode += getIsNeedProjectTeamApr__c().hashCode();
        }
        if (getIsOnApprovaling__c() != null) {
            _hashCode += getIsOnApprovaling__c().hashCode();
        }
        if (getIsTerminateDealGroup__c() != null) {
            _hashCode += getIsTerminateDealGroup__c().hashCode();
        }
        if (getIsVip__c() != null) {
            _hashCode += getIsVip__c().hashCode();
        }
        if (getLastActivityDate() != null) {
            _hashCode += getLastActivityDate().hashCode();
        }
        if (getLastModifiedBy() != null) {
            _hashCode += getLastModifiedBy().hashCode();
        }
        if (getLastModifiedById() != null) {
            _hashCode += getLastModifiedById().hashCode();
        }
        if (getLastModifiedDate() != null) {
            _hashCode += getLastModifiedDate().hashCode();
        }
        if (getMaxPerUser__c() != null) {
            _hashCode += getMaxPerUser__c().hashCode();
        }
        if (getMonthlyPerformanceActual__r() != null) {
            _hashCode += getMonthlyPerformanceActual__r().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getNeedAllowance__c() != null) {
            _hashCode += getNeedAllowance__c().hashCode();
        }
        if (getNotes() != null) {
            _hashCode += getNotes().hashCode();
        }
        if (getNotesAndAttachments() != null) {
            _hashCode += getNotesAndAttachments().hashCode();
        }
        if (getOnlineDate__c() != null) {
            _hashCode += getOnlineDate__c().hashCode();
        }
        if (getOnlineDayLength__c() != null) {
            _hashCode += getOnlineDayLength__c().hashCode();
        }
        if (getOpenActivities() != null) {
            _hashCode += getOpenActivities().hashCode();
        }
        if (getOwner() != null) {
            _hashCode += getOwner().hashCode();
        }
        if (getOwnerId() != null) {
            _hashCode += getOwnerId().hashCode();
        }
        if (getPasswdAccepterEmail__c() != null) {
            _hashCode += getPasswdAccepterEmail__c().hashCode();
        }
        if (getPasswdAccepterPhone__c() != null) {
            _hashCode += getPasswdAccepterPhone__c().hashCode();
        }
        if (getPasswdAccepter__c() != null) {
            _hashCode += getPasswdAccepter__c().hashCode();
        }
        if (getPlanBeginDate__c() != null) {
            _hashCode += getPlanBeginDate__c().hashCode();
        }
        if (getProcessInstances() != null) {
            _hashCode += getProcessInstances().hashCode();
        }
        if (getProcessSteps() != null) {
            _hashCode += getProcessSteps().hashCode();
        }
        if (getProvideInvoice__c() != null) {
            _hashCode += getProvideInvoice__c().hashCode();
        }
        if (getPublishCitys__c() != null) {
            _hashCode += getPublishCitys__c().hashCode();
        }
        if (getPublishType__c() != null) {
            _hashCode += getPublishType__c().hashCode();
        }
        if (getReceiptType__c() != null) {
            _hashCode += getReceiptType__c().hashCode();
        }
        if (getSourceDealGroup__c() != null) {
            _hashCode += getSourceDealGroup__c().hashCode();
        }
        if (getSourceDealGroup__r() != null) {
            _hashCode += getSourceDealGroup__r().hashCode();
        }
        if (getSupportPoints__c() != null) {
            _hashCode += getSupportPoints__c().hashCode();
        }
        if (getSysDealGroupId__c() != null) {
            _hashCode += getSysDealGroupId__c().hashCode();
        }
        if (getSysDealGroupUrl__c() != null) {
            _hashCode += getSysDealGroupUrl__c().hashCode();
        }
        if (getSystemModstamp() != null) {
            _hashCode += getSystemModstamp().hashCode();
        }
        if (getTasks() != null) {
            _hashCode += getTasks().hashCode();
        }
        if (getTgCategory__r() != null) {
            _hashCode += getTgCategory__r().hashCode();
        }
        if (getVarificationProvider__c() != null) {
            _hashCode += getVarificationProvider__c().hashCode();
        }
        if (getVerifyType__c() != null) {
            _hashCode += getVerifyType__c().hashCode();
        }
        if (getIsProduced__c() != null) {
            _hashCode += getIsProduced__c().hashCode();
        }
        if (getOffLineTime__c() != null) {
            _hashCode += getOffLineTime__c().hashCode();
        }
        if (getOnlineStatus__c() != null) {
            _hashCode += getOnlineStatus__c().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DealGroup__c.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DealGroup__c"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accountName__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AccountName__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("activityHistories");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ActivityHistories"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("allowanceFlag__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AllowanceFlag__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("approvalMgr1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ApprovalMgr1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("approvalMgr1__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ApprovalMgr1__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("approvalMgr2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ApprovalMgr2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("approvalMgr2__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ApprovalMgr2__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("approvalMgr3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ApprovalMgr3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("approvalMgr3__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ApprovalMgr3__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Attachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("beginDate__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BeginDate__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("blackDate__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BlackDate__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bulkBuyFirstCategory__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BulkBuyFirstCategory__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bulkBuySecondCategory__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BulkBuySecondCategory__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("childDealGroup__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ChildDealGroup__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cityID__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CityID__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("companyNumber__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CompanyNumber__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contractStatus__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ContractStatus__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contract__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Contract__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contract__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Contract__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Contract"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dealCount__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DealCount__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dealGroupAprStatus__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DealGroupAprStatus__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dealGroupUpdTrack__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DealGroupUpdTrack__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("deal__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Deal__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dealgroupStage__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DealgroupStage__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("destinaion__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Destinaion__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("endDate__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "EndDate__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("events");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Events"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("histories");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Histories"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("infoConfirmed__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "InfoConfirmed__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isAutoRefund__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsAutoRefund__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isCostChanged__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsCostChanged__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isDPDeliver__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsDPDeliver__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isDeleted");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsDeleted"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isECommerceDG__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsECommerceDG__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isNeedApprovalMgr1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsNeedApprovalMgr1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isNeedApproval__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsNeedApproval__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isNeedProjectTeamApr__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsNeedProjectTeamApr__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isOnApprovaling__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsOnApprovaling__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isTerminateDealGroup__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsTerminateDealGroup__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isVip__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsVip__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastActivityDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastActivityDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maxPerUser__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "MaxPerUser__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("monthlyPerformanceActual__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "MonthlyPerformanceActual__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("needAllowance__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NeedAllowance__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notes");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Notes"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notesAndAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NotesAndAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("onlineDate__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OnlineDate__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("onlineDayLength__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OnlineDayLength__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("openActivities");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OpenActivities"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("owner");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Owner"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ownerId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OwnerId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("passwdAccepterEmail__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PasswdAccepterEmail__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("passwdAccepterPhone__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PasswdAccepterPhone__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("passwdAccepter__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PasswdAccepter__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("planBeginDate__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PlanBeginDate__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processInstances");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessInstances"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processSteps");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessSteps"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("provideInvoice__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProvideInvoice__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("publishCitys__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PublishCitys__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("publishType__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PublishType__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("receiptType__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ReceiptType__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sourceDealGroup__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SourceDealGroup__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sourceDealGroup__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SourceDealGroup__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DealGroup__c"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("supportPoints__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SupportPoints__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sysDealGroupId__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SysDealGroupId__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sysDealGroupUrl__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SysDealGroupUrl__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("systemModstamp");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SystemModstamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tasks");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Tasks"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tgCategory__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TgCategory__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("varificationProvider__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "VarificationProvider__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("verifyType__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "VerifyType__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isProduced__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "isProduced__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("offLineTime__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "offLineTime__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("onlineStatus__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "onlineStatus__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
