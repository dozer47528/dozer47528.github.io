/**
 * Deal__c.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.sforce.soap.enterprise.sobject;

public class Deal__c  extends com.sforce.soap.enterprise.sobject.SObject  implements java.io.Serializable {
    private com.sforce.soap.enterprise.QueryResult attachments;

    private java.lang.String branchName__c;

    private java.lang.String city__c;

    private java.lang.String contractBankAccountNo__c;

    private java.lang.String contractBankAccount__c;

    private com.sforce.soap.enterprise.sobject.ContractBankAccount__c contractBankAccount__r;

    private java.lang.String contractBranch__c;

    private java.lang.String contractStatus__c;

    private java.lang.String contract__c;

    private com.sforce.soap.enterprise.sobject.Contract contract__r;

    private java.lang.Double cost__c;

    private com.sforce.soap.enterprise.sobject.User createdBy;

    private java.lang.String createdById;

    private java.util.Calendar createdDate;

    private java.lang.String dateType__c;

    private com.sforce.soap.enterprise.QueryResult dealAccount__r;

    private java.lang.String dealGroup__c;

    private com.sforce.soap.enterprise.sobject.DealGroup__c dealGroup__r;

    private java.lang.Double dealOrder__c;

    private java.lang.Double dealPrice__c;

    private java.lang.String description__c;

    private java.lang.String durationUnit__c;

    private java.lang.Double duration__c;

    private java.util.Date effectiveReceiptEndDate__c;

    private java.lang.Double gapStart__c;

    private com.sforce.soap.enterprise.QueryResult histories;

    private java.lang.Boolean isDeleted;

    private java.lang.Boolean isFromCopy__c;

    private com.sforce.soap.enterprise.sobject.User lastModifiedBy;

    private java.lang.String lastModifiedById;

    private java.util.Calendar lastModifiedDate;

    private java.lang.Double marketPrice__c;

    private java.lang.Double maxJoin__c;

    private java.lang.String name;

    private java.lang.Double needAllowance__c;

    private com.sforce.soap.enterprise.QueryResult notes;

    private com.sforce.soap.enterprise.QueryResult notesAndAttachments;

    private com.sforce.soap.enterprise.QueryResult processInstances;

    private com.sforce.soap.enterprise.QueryResult processSteps;

    private java.lang.String productNumber__c;

    private java.lang.Double profitMargin__c;

    private java.lang.String province__c;

    private java.util.Date receiptEndDate__c;

    private java.lang.Double suggestPrice__c;

    private java.util.Calendar systemModstamp;

    private java.lang.Double timesOfUsage__c;

    private java.lang.String validity__c;

    private java.lang.String isVarifiedByThirdParty__c;

    public Deal__c() {
    }

    public Deal__c(
           java.lang.String[] fieldsToNull,
           java.lang.String id,
           com.sforce.soap.enterprise.QueryResult attachments,
           java.lang.String branchName__c,
           java.lang.String city__c,
           java.lang.String contractBankAccountNo__c,
           java.lang.String contractBankAccount__c,
           com.sforce.soap.enterprise.sobject.ContractBankAccount__c contractBankAccount__r,
           java.lang.String contractBranch__c,
           java.lang.String contractStatus__c,
           java.lang.String contract__c,
           com.sforce.soap.enterprise.sobject.Contract contract__r,
           java.lang.Double cost__c,
           com.sforce.soap.enterprise.sobject.User createdBy,
           java.lang.String createdById,
           java.util.Calendar createdDate,
           java.lang.String dateType__c,
           com.sforce.soap.enterprise.QueryResult dealAccount__r,
           java.lang.String dealGroup__c,
           com.sforce.soap.enterprise.sobject.DealGroup__c dealGroup__r,
           java.lang.Double dealOrder__c,
           java.lang.Double dealPrice__c,
           java.lang.String description__c,
           java.lang.String durationUnit__c,
           java.lang.Double duration__c,
           java.util.Date effectiveReceiptEndDate__c,
           java.lang.Double gapStart__c,
           com.sforce.soap.enterprise.QueryResult histories,
           java.lang.Boolean isDeleted,
           java.lang.Boolean isFromCopy__c,
           com.sforce.soap.enterprise.sobject.User lastModifiedBy,
           java.lang.String lastModifiedById,
           java.util.Calendar lastModifiedDate,
           java.lang.Double marketPrice__c,
           java.lang.Double maxJoin__c,
           java.lang.String name,
           java.lang.Double needAllowance__c,
           com.sforce.soap.enterprise.QueryResult notes,
           com.sforce.soap.enterprise.QueryResult notesAndAttachments,
           com.sforce.soap.enterprise.QueryResult processInstances,
           com.sforce.soap.enterprise.QueryResult processSteps,
           java.lang.String productNumber__c,
           java.lang.Double profitMargin__c,
           java.lang.String province__c,
           java.util.Date receiptEndDate__c,
           java.lang.Double suggestPrice__c,
           java.util.Calendar systemModstamp,
           java.lang.Double timesOfUsage__c,
           java.lang.String validity__c,
           java.lang.String isVarifiedByThirdParty__c) {
        super(
            fieldsToNull,
            id);
        this.attachments = attachments;
        this.branchName__c = branchName__c;
        this.city__c = city__c;
        this.contractBankAccountNo__c = contractBankAccountNo__c;
        this.contractBankAccount__c = contractBankAccount__c;
        this.contractBankAccount__r = contractBankAccount__r;
        this.contractBranch__c = contractBranch__c;
        this.contractStatus__c = contractStatus__c;
        this.contract__c = contract__c;
        this.contract__r = contract__r;
        this.cost__c = cost__c;
        this.createdBy = createdBy;
        this.createdById = createdById;
        this.createdDate = createdDate;
        this.dateType__c = dateType__c;
        this.dealAccount__r = dealAccount__r;
        this.dealGroup__c = dealGroup__c;
        this.dealGroup__r = dealGroup__r;
        this.dealOrder__c = dealOrder__c;
        this.dealPrice__c = dealPrice__c;
        this.description__c = description__c;
        this.durationUnit__c = durationUnit__c;
        this.duration__c = duration__c;
        this.effectiveReceiptEndDate__c = effectiveReceiptEndDate__c;
        this.gapStart__c = gapStart__c;
        this.histories = histories;
        this.isDeleted = isDeleted;
        this.isFromCopy__c = isFromCopy__c;
        this.lastModifiedBy = lastModifiedBy;
        this.lastModifiedById = lastModifiedById;
        this.lastModifiedDate = lastModifiedDate;
        this.marketPrice__c = marketPrice__c;
        this.maxJoin__c = maxJoin__c;
        this.name = name;
        this.needAllowance__c = needAllowance__c;
        this.notes = notes;
        this.notesAndAttachments = notesAndAttachments;
        this.processInstances = processInstances;
        this.processSteps = processSteps;
        this.productNumber__c = productNumber__c;
        this.profitMargin__c = profitMargin__c;
        this.province__c = province__c;
        this.receiptEndDate__c = receiptEndDate__c;
        this.suggestPrice__c = suggestPrice__c;
        this.systemModstamp = systemModstamp;
        this.timesOfUsage__c = timesOfUsage__c;
        this.validity__c = validity__c;
        this.isVarifiedByThirdParty__c = isVarifiedByThirdParty__c;
    }


    /**
     * Gets the attachments value for this Deal__c.
     * 
     * @return attachments
     */
    public com.sforce.soap.enterprise.QueryResult getAttachments() {
        return attachments;
    }


    /**
     * Sets the attachments value for this Deal__c.
     * 
     * @param attachments
     */
    public void setAttachments(com.sforce.soap.enterprise.QueryResult attachments) {
        this.attachments = attachments;
    }


    /**
     * Gets the branchName__c value for this Deal__c.
     * 
     * @return branchName__c
     */
    public java.lang.String getBranchName__c() {
        return branchName__c;
    }


    /**
     * Sets the branchName__c value for this Deal__c.
     * 
     * @param branchName__c
     */
    public void setBranchName__c(java.lang.String branchName__c) {
        this.branchName__c = branchName__c;
    }


    /**
     * Gets the city__c value for this Deal__c.
     * 
     * @return city__c
     */
    public java.lang.String getCity__c() {
        return city__c;
    }


    /**
     * Sets the city__c value for this Deal__c.
     * 
     * @param city__c
     */
    public void setCity__c(java.lang.String city__c) {
        this.city__c = city__c;
    }


    /**
     * Gets the contractBankAccountNo__c value for this Deal__c.
     * 
     * @return contractBankAccountNo__c
     */
    public java.lang.String getContractBankAccountNo__c() {
        return contractBankAccountNo__c;
    }


    /**
     * Sets the contractBankAccountNo__c value for this Deal__c.
     * 
     * @param contractBankAccountNo__c
     */
    public void setContractBankAccountNo__c(java.lang.String contractBankAccountNo__c) {
        this.contractBankAccountNo__c = contractBankAccountNo__c;
    }


    /**
     * Gets the contractBankAccount__c value for this Deal__c.
     * 
     * @return contractBankAccount__c
     */
    public java.lang.String getContractBankAccount__c() {
        return contractBankAccount__c;
    }


    /**
     * Sets the contractBankAccount__c value for this Deal__c.
     * 
     * @param contractBankAccount__c
     */
    public void setContractBankAccount__c(java.lang.String contractBankAccount__c) {
        this.contractBankAccount__c = contractBankAccount__c;
    }


    /**
     * Gets the contractBankAccount__r value for this Deal__c.
     * 
     * @return contractBankAccount__r
     */
    public com.sforce.soap.enterprise.sobject.ContractBankAccount__c getContractBankAccount__r() {
        return contractBankAccount__r;
    }


    /**
     * Sets the contractBankAccount__r value for this Deal__c.
     * 
     * @param contractBankAccount__r
     */
    public void setContractBankAccount__r(com.sforce.soap.enterprise.sobject.ContractBankAccount__c contractBankAccount__r) {
        this.contractBankAccount__r = contractBankAccount__r;
    }


    /**
     * Gets the contractBranch__c value for this Deal__c.
     * 
     * @return contractBranch__c
     */
    public java.lang.String getContractBranch__c() {
        return contractBranch__c;
    }


    /**
     * Sets the contractBranch__c value for this Deal__c.
     * 
     * @param contractBranch__c
     */
    public void setContractBranch__c(java.lang.String contractBranch__c) {
        this.contractBranch__c = contractBranch__c;
    }


    /**
     * Gets the contractStatus__c value for this Deal__c.
     * 
     * @return contractStatus__c
     */
    public java.lang.String getContractStatus__c() {
        return contractStatus__c;
    }


    /**
     * Sets the contractStatus__c value for this Deal__c.
     * 
     * @param contractStatus__c
     */
    public void setContractStatus__c(java.lang.String contractStatus__c) {
        this.contractStatus__c = contractStatus__c;
    }


    /**
     * Gets the contract__c value for this Deal__c.
     * 
     * @return contract__c
     */
    public java.lang.String getContract__c() {
        return contract__c;
    }


    /**
     * Sets the contract__c value for this Deal__c.
     * 
     * @param contract__c
     */
    public void setContract__c(java.lang.String contract__c) {
        this.contract__c = contract__c;
    }


    /**
     * Gets the contract__r value for this Deal__c.
     * 
     * @return contract__r
     */
    public com.sforce.soap.enterprise.sobject.Contract getContract__r() {
        return contract__r;
    }


    /**
     * Sets the contract__r value for this Deal__c.
     * 
     * @param contract__r
     */
    public void setContract__r(com.sforce.soap.enterprise.sobject.Contract contract__r) {
        this.contract__r = contract__r;
    }


    /**
     * Gets the cost__c value for this Deal__c.
     * 
     * @return cost__c
     */
    public java.lang.Double getCost__c() {
        return cost__c;
    }


    /**
     * Sets the cost__c value for this Deal__c.
     * 
     * @param cost__c
     */
    public void setCost__c(java.lang.Double cost__c) {
        this.cost__c = cost__c;
    }


    /**
     * Gets the createdBy value for this Deal__c.
     * 
     * @return createdBy
     */
    public com.sforce.soap.enterprise.sobject.User getCreatedBy() {
        return createdBy;
    }


    /**
     * Sets the createdBy value for this Deal__c.
     * 
     * @param createdBy
     */
    public void setCreatedBy(com.sforce.soap.enterprise.sobject.User createdBy) {
        this.createdBy = createdBy;
    }


    /**
     * Gets the createdById value for this Deal__c.
     * 
     * @return createdById
     */
    public java.lang.String getCreatedById() {
        return createdById;
    }


    /**
     * Sets the createdById value for this Deal__c.
     * 
     * @param createdById
     */
    public void setCreatedById(java.lang.String createdById) {
        this.createdById = createdById;
    }


    /**
     * Gets the createdDate value for this Deal__c.
     * 
     * @return createdDate
     */
    public java.util.Calendar getCreatedDate() {
        return createdDate;
    }


    /**
     * Sets the createdDate value for this Deal__c.
     * 
     * @param createdDate
     */
    public void setCreatedDate(java.util.Calendar createdDate) {
        this.createdDate = createdDate;
    }


    /**
     * Gets the dateType__c value for this Deal__c.
     * 
     * @return dateType__c
     */
    public java.lang.String getDateType__c() {
        return dateType__c;
    }


    /**
     * Sets the dateType__c value for this Deal__c.
     * 
     * @param dateType__c
     */
    public void setDateType__c(java.lang.String dateType__c) {
        this.dateType__c = dateType__c;
    }


    /**
     * Gets the dealAccount__r value for this Deal__c.
     * 
     * @return dealAccount__r
     */
    public com.sforce.soap.enterprise.QueryResult getDealAccount__r() {
        return dealAccount__r;
    }


    /**
     * Sets the dealAccount__r value for this Deal__c.
     * 
     * @param dealAccount__r
     */
    public void setDealAccount__r(com.sforce.soap.enterprise.QueryResult dealAccount__r) {
        this.dealAccount__r = dealAccount__r;
    }


    /**
     * Gets the dealGroup__c value for this Deal__c.
     * 
     * @return dealGroup__c
     */
    public java.lang.String getDealGroup__c() {
        return dealGroup__c;
    }


    /**
     * Sets the dealGroup__c value for this Deal__c.
     * 
     * @param dealGroup__c
     */
    public void setDealGroup__c(java.lang.String dealGroup__c) {
        this.dealGroup__c = dealGroup__c;
    }


    /**
     * Gets the dealGroup__r value for this Deal__c.
     * 
     * @return dealGroup__r
     */
    public com.sforce.soap.enterprise.sobject.DealGroup__c getDealGroup__r() {
        return dealGroup__r;
    }


    /**
     * Sets the dealGroup__r value for this Deal__c.
     * 
     * @param dealGroup__r
     */
    public void setDealGroup__r(com.sforce.soap.enterprise.sobject.DealGroup__c dealGroup__r) {
        this.dealGroup__r = dealGroup__r;
    }


    /**
     * Gets the dealOrder__c value for this Deal__c.
     * 
     * @return dealOrder__c
     */
    public java.lang.Double getDealOrder__c() {
        return dealOrder__c;
    }


    /**
     * Sets the dealOrder__c value for this Deal__c.
     * 
     * @param dealOrder__c
     */
    public void setDealOrder__c(java.lang.Double dealOrder__c) {
        this.dealOrder__c = dealOrder__c;
    }


    /**
     * Gets the dealPrice__c value for this Deal__c.
     * 
     * @return dealPrice__c
     */
    public java.lang.Double getDealPrice__c() {
        return dealPrice__c;
    }


    /**
     * Sets the dealPrice__c value for this Deal__c.
     * 
     * @param dealPrice__c
     */
    public void setDealPrice__c(java.lang.Double dealPrice__c) {
        this.dealPrice__c = dealPrice__c;
    }


    /**
     * Gets the description__c value for this Deal__c.
     * 
     * @return description__c
     */
    public java.lang.String getDescription__c() {
        return description__c;
    }


    /**
     * Sets the description__c value for this Deal__c.
     * 
     * @param description__c
     */
    public void setDescription__c(java.lang.String description__c) {
        this.description__c = description__c;
    }


    /**
     * Gets the durationUnit__c value for this Deal__c.
     * 
     * @return durationUnit__c
     */
    public java.lang.String getDurationUnit__c() {
        return durationUnit__c;
    }


    /**
     * Sets the durationUnit__c value for this Deal__c.
     * 
     * @param durationUnit__c
     */
    public void setDurationUnit__c(java.lang.String durationUnit__c) {
        this.durationUnit__c = durationUnit__c;
    }


    /**
     * Gets the duration__c value for this Deal__c.
     * 
     * @return duration__c
     */
    public java.lang.Double getDuration__c() {
        return duration__c;
    }


    /**
     * Sets the duration__c value for this Deal__c.
     * 
     * @param duration__c
     */
    public void setDuration__c(java.lang.Double duration__c) {
        this.duration__c = duration__c;
    }


    /**
     * Gets the effectiveReceiptEndDate__c value for this Deal__c.
     * 
     * @return effectiveReceiptEndDate__c
     */
    public java.util.Date getEffectiveReceiptEndDate__c() {
        return effectiveReceiptEndDate__c;
    }


    /**
     * Sets the effectiveReceiptEndDate__c value for this Deal__c.
     * 
     * @param effectiveReceiptEndDate__c
     */
    public void setEffectiveReceiptEndDate__c(java.util.Date effectiveReceiptEndDate__c) {
        this.effectiveReceiptEndDate__c = effectiveReceiptEndDate__c;
    }


    /**
     * Gets the gapStart__c value for this Deal__c.
     * 
     * @return gapStart__c
     */
    public java.lang.Double getGapStart__c() {
        return gapStart__c;
    }


    /**
     * Sets the gapStart__c value for this Deal__c.
     * 
     * @param gapStart__c
     */
    public void setGapStart__c(java.lang.Double gapStart__c) {
        this.gapStart__c = gapStart__c;
    }


    /**
     * Gets the histories value for this Deal__c.
     * 
     * @return histories
     */
    public com.sforce.soap.enterprise.QueryResult getHistories() {
        return histories;
    }


    /**
     * Sets the histories value for this Deal__c.
     * 
     * @param histories
     */
    public void setHistories(com.sforce.soap.enterprise.QueryResult histories) {
        this.histories = histories;
    }


    /**
     * Gets the isDeleted value for this Deal__c.
     * 
     * @return isDeleted
     */
    public java.lang.Boolean getIsDeleted() {
        return isDeleted;
    }


    /**
     * Sets the isDeleted value for this Deal__c.
     * 
     * @param isDeleted
     */
    public void setIsDeleted(java.lang.Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }


    /**
     * Gets the isFromCopy__c value for this Deal__c.
     * 
     * @return isFromCopy__c
     */
    public java.lang.Boolean getIsFromCopy__c() {
        return isFromCopy__c;
    }


    /**
     * Sets the isFromCopy__c value for this Deal__c.
     * 
     * @param isFromCopy__c
     */
    public void setIsFromCopy__c(java.lang.Boolean isFromCopy__c) {
        this.isFromCopy__c = isFromCopy__c;
    }


    /**
     * Gets the lastModifiedBy value for this Deal__c.
     * 
     * @return lastModifiedBy
     */
    public com.sforce.soap.enterprise.sobject.User getLastModifiedBy() {
        return lastModifiedBy;
    }


    /**
     * Sets the lastModifiedBy value for this Deal__c.
     * 
     * @param lastModifiedBy
     */
    public void setLastModifiedBy(com.sforce.soap.enterprise.sobject.User lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }


    /**
     * Gets the lastModifiedById value for this Deal__c.
     * 
     * @return lastModifiedById
     */
    public java.lang.String getLastModifiedById() {
        return lastModifiedById;
    }


    /**
     * Sets the lastModifiedById value for this Deal__c.
     * 
     * @param lastModifiedById
     */
    public void setLastModifiedById(java.lang.String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }


    /**
     * Gets the lastModifiedDate value for this Deal__c.
     * 
     * @return lastModifiedDate
     */
    public java.util.Calendar getLastModifiedDate() {
        return lastModifiedDate;
    }


    /**
     * Sets the lastModifiedDate value for this Deal__c.
     * 
     * @param lastModifiedDate
     */
    public void setLastModifiedDate(java.util.Calendar lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }


    /**
     * Gets the marketPrice__c value for this Deal__c.
     * 
     * @return marketPrice__c
     */
    public java.lang.Double getMarketPrice__c() {
        return marketPrice__c;
    }


    /**
     * Sets the marketPrice__c value for this Deal__c.
     * 
     * @param marketPrice__c
     */
    public void setMarketPrice__c(java.lang.Double marketPrice__c) {
        this.marketPrice__c = marketPrice__c;
    }


    /**
     * Gets the maxJoin__c value for this Deal__c.
     * 
     * @return maxJoin__c
     */
    public java.lang.Double getMaxJoin__c() {
        return maxJoin__c;
    }


    /**
     * Sets the maxJoin__c value for this Deal__c.
     * 
     * @param maxJoin__c
     */
    public void setMaxJoin__c(java.lang.Double maxJoin__c) {
        this.maxJoin__c = maxJoin__c;
    }


    /**
     * Gets the name value for this Deal__c.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this Deal__c.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the needAllowance__c value for this Deal__c.
     * 
     * @return needAllowance__c
     */
    public java.lang.Double getNeedAllowance__c() {
        return needAllowance__c;
    }


    /**
     * Sets the needAllowance__c value for this Deal__c.
     * 
     * @param needAllowance__c
     */
    public void setNeedAllowance__c(java.lang.Double needAllowance__c) {
        this.needAllowance__c = needAllowance__c;
    }


    /**
     * Gets the notes value for this Deal__c.
     * 
     * @return notes
     */
    public com.sforce.soap.enterprise.QueryResult getNotes() {
        return notes;
    }


    /**
     * Sets the notes value for this Deal__c.
     * 
     * @param notes
     */
    public void setNotes(com.sforce.soap.enterprise.QueryResult notes) {
        this.notes = notes;
    }


    /**
     * Gets the notesAndAttachments value for this Deal__c.
     * 
     * @return notesAndAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getNotesAndAttachments() {
        return notesAndAttachments;
    }


    /**
     * Sets the notesAndAttachments value for this Deal__c.
     * 
     * @param notesAndAttachments
     */
    public void setNotesAndAttachments(com.sforce.soap.enterprise.QueryResult notesAndAttachments) {
        this.notesAndAttachments = notesAndAttachments;
    }


    /**
     * Gets the processInstances value for this Deal__c.
     * 
     * @return processInstances
     */
    public com.sforce.soap.enterprise.QueryResult getProcessInstances() {
        return processInstances;
    }


    /**
     * Sets the processInstances value for this Deal__c.
     * 
     * @param processInstances
     */
    public void setProcessInstances(com.sforce.soap.enterprise.QueryResult processInstances) {
        this.processInstances = processInstances;
    }


    /**
     * Gets the processSteps value for this Deal__c.
     * 
     * @return processSteps
     */
    public com.sforce.soap.enterprise.QueryResult getProcessSteps() {
        return processSteps;
    }


    /**
     * Sets the processSteps value for this Deal__c.
     * 
     * @param processSteps
     */
    public void setProcessSteps(com.sforce.soap.enterprise.QueryResult processSteps) {
        this.processSteps = processSteps;
    }


    /**
     * Gets the productNumber__c value for this Deal__c.
     * 
     * @return productNumber__c
     */
    public java.lang.String getProductNumber__c() {
        return productNumber__c;
    }


    /**
     * Sets the productNumber__c value for this Deal__c.
     * 
     * @param productNumber__c
     */
    public void setProductNumber__c(java.lang.String productNumber__c) {
        this.productNumber__c = productNumber__c;
    }


    /**
     * Gets the profitMargin__c value for this Deal__c.
     * 
     * @return profitMargin__c
     */
    public java.lang.Double getProfitMargin__c() {
        return profitMargin__c;
    }


    /**
     * Sets the profitMargin__c value for this Deal__c.
     * 
     * @param profitMargin__c
     */
    public void setProfitMargin__c(java.lang.Double profitMargin__c) {
        this.profitMargin__c = profitMargin__c;
    }


    /**
     * Gets the province__c value for this Deal__c.
     * 
     * @return province__c
     */
    public java.lang.String getProvince__c() {
        return province__c;
    }


    /**
     * Sets the province__c value for this Deal__c.
     * 
     * @param province__c
     */
    public void setProvince__c(java.lang.String province__c) {
        this.province__c = province__c;
    }


    /**
     * Gets the receiptEndDate__c value for this Deal__c.
     * 
     * @return receiptEndDate__c
     */
    public java.util.Date getReceiptEndDate__c() {
        return receiptEndDate__c;
    }


    /**
     * Sets the receiptEndDate__c value for this Deal__c.
     * 
     * @param receiptEndDate__c
     */
    public void setReceiptEndDate__c(java.util.Date receiptEndDate__c) {
        this.receiptEndDate__c = receiptEndDate__c;
    }


    /**
     * Gets the suggestPrice__c value for this Deal__c.
     * 
     * @return suggestPrice__c
     */
    public java.lang.Double getSuggestPrice__c() {
        return suggestPrice__c;
    }


    /**
     * Sets the suggestPrice__c value for this Deal__c.
     * 
     * @param suggestPrice__c
     */
    public void setSuggestPrice__c(java.lang.Double suggestPrice__c) {
        this.suggestPrice__c = suggestPrice__c;
    }


    /**
     * Gets the systemModstamp value for this Deal__c.
     * 
     * @return systemModstamp
     */
    public java.util.Calendar getSystemModstamp() {
        return systemModstamp;
    }


    /**
     * Sets the systemModstamp value for this Deal__c.
     * 
     * @param systemModstamp
     */
    public void setSystemModstamp(java.util.Calendar systemModstamp) {
        this.systemModstamp = systemModstamp;
    }


    /**
     * Gets the timesOfUsage__c value for this Deal__c.
     * 
     * @return timesOfUsage__c
     */
    public java.lang.Double getTimesOfUsage__c() {
        return timesOfUsage__c;
    }


    /**
     * Sets the timesOfUsage__c value for this Deal__c.
     * 
     * @param timesOfUsage__c
     */
    public void setTimesOfUsage__c(java.lang.Double timesOfUsage__c) {
        this.timesOfUsage__c = timesOfUsage__c;
    }


    /**
     * Gets the validity__c value for this Deal__c.
     * 
     * @return validity__c
     */
    public java.lang.String getValidity__c() {
        return validity__c;
    }


    /**
     * Sets the validity__c value for this Deal__c.
     * 
     * @param validity__c
     */
    public void setValidity__c(java.lang.String validity__c) {
        this.validity__c = validity__c;
    }


    /**
     * Gets the isVarifiedByThirdParty__c value for this Deal__c.
     * 
     * @return isVarifiedByThirdParty__c
     */
    public java.lang.String getIsVarifiedByThirdParty__c() {
        return isVarifiedByThirdParty__c;
    }


    /**
     * Sets the isVarifiedByThirdParty__c value for this Deal__c.
     * 
     * @param isVarifiedByThirdParty__c
     */
    public void setIsVarifiedByThirdParty__c(java.lang.String isVarifiedByThirdParty__c) {
        this.isVarifiedByThirdParty__c = isVarifiedByThirdParty__c;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Deal__c)) return false;
        Deal__c other = (Deal__c) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.attachments==null && other.getAttachments()==null) || 
             (this.attachments!=null &&
              this.attachments.equals(other.getAttachments()))) &&
            ((this.branchName__c==null && other.getBranchName__c()==null) || 
             (this.branchName__c!=null &&
              this.branchName__c.equals(other.getBranchName__c()))) &&
            ((this.city__c==null && other.getCity__c()==null) || 
             (this.city__c!=null &&
              this.city__c.equals(other.getCity__c()))) &&
            ((this.contractBankAccountNo__c==null && other.getContractBankAccountNo__c()==null) || 
             (this.contractBankAccountNo__c!=null &&
              this.contractBankAccountNo__c.equals(other.getContractBankAccountNo__c()))) &&
            ((this.contractBankAccount__c==null && other.getContractBankAccount__c()==null) || 
             (this.contractBankAccount__c!=null &&
              this.contractBankAccount__c.equals(other.getContractBankAccount__c()))) &&
            ((this.contractBankAccount__r==null && other.getContractBankAccount__r()==null) || 
             (this.contractBankAccount__r!=null &&
              this.contractBankAccount__r.equals(other.getContractBankAccount__r()))) &&
            ((this.contractBranch__c==null && other.getContractBranch__c()==null) || 
             (this.contractBranch__c!=null &&
              this.contractBranch__c.equals(other.getContractBranch__c()))) &&
            ((this.contractStatus__c==null && other.getContractStatus__c()==null) || 
             (this.contractStatus__c!=null &&
              this.contractStatus__c.equals(other.getContractStatus__c()))) &&
            ((this.contract__c==null && other.getContract__c()==null) || 
             (this.contract__c!=null &&
              this.contract__c.equals(other.getContract__c()))) &&
            ((this.contract__r==null && other.getContract__r()==null) || 
             (this.contract__r!=null &&
              this.contract__r.equals(other.getContract__r()))) &&
            ((this.cost__c==null && other.getCost__c()==null) || 
             (this.cost__c!=null &&
              this.cost__c.equals(other.getCost__c()))) &&
            ((this.createdBy==null && other.getCreatedBy()==null) || 
             (this.createdBy!=null &&
              this.createdBy.equals(other.getCreatedBy()))) &&
            ((this.createdById==null && other.getCreatedById()==null) || 
             (this.createdById!=null &&
              this.createdById.equals(other.getCreatedById()))) &&
            ((this.createdDate==null && other.getCreatedDate()==null) || 
             (this.createdDate!=null &&
              this.createdDate.equals(other.getCreatedDate()))) &&
            ((this.dateType__c==null && other.getDateType__c()==null) || 
             (this.dateType__c!=null &&
              this.dateType__c.equals(other.getDateType__c()))) &&
            ((this.dealAccount__r==null && other.getDealAccount__r()==null) || 
             (this.dealAccount__r!=null &&
              this.dealAccount__r.equals(other.getDealAccount__r()))) &&
            ((this.dealGroup__c==null && other.getDealGroup__c()==null) || 
             (this.dealGroup__c!=null &&
              this.dealGroup__c.equals(other.getDealGroup__c()))) &&
            ((this.dealGroup__r==null && other.getDealGroup__r()==null) || 
             (this.dealGroup__r!=null &&
              this.dealGroup__r.equals(other.getDealGroup__r()))) &&
            ((this.dealOrder__c==null && other.getDealOrder__c()==null) || 
             (this.dealOrder__c!=null &&
              this.dealOrder__c.equals(other.getDealOrder__c()))) &&
            ((this.dealPrice__c==null && other.getDealPrice__c()==null) || 
             (this.dealPrice__c!=null &&
              this.dealPrice__c.equals(other.getDealPrice__c()))) &&
            ((this.description__c==null && other.getDescription__c()==null) || 
             (this.description__c!=null &&
              this.description__c.equals(other.getDescription__c()))) &&
            ((this.durationUnit__c==null && other.getDurationUnit__c()==null) || 
             (this.durationUnit__c!=null &&
              this.durationUnit__c.equals(other.getDurationUnit__c()))) &&
            ((this.duration__c==null && other.getDuration__c()==null) || 
             (this.duration__c!=null &&
              this.duration__c.equals(other.getDuration__c()))) &&
            ((this.effectiveReceiptEndDate__c==null && other.getEffectiveReceiptEndDate__c()==null) || 
             (this.effectiveReceiptEndDate__c!=null &&
              this.effectiveReceiptEndDate__c.equals(other.getEffectiveReceiptEndDate__c()))) &&
            ((this.gapStart__c==null && other.getGapStart__c()==null) || 
             (this.gapStart__c!=null &&
              this.gapStart__c.equals(other.getGapStart__c()))) &&
            ((this.histories==null && other.getHistories()==null) || 
             (this.histories!=null &&
              this.histories.equals(other.getHistories()))) &&
            ((this.isDeleted==null && other.getIsDeleted()==null) || 
             (this.isDeleted!=null &&
              this.isDeleted.equals(other.getIsDeleted()))) &&
            ((this.isFromCopy__c==null && other.getIsFromCopy__c()==null) || 
             (this.isFromCopy__c!=null &&
              this.isFromCopy__c.equals(other.getIsFromCopy__c()))) &&
            ((this.lastModifiedBy==null && other.getLastModifiedBy()==null) || 
             (this.lastModifiedBy!=null &&
              this.lastModifiedBy.equals(other.getLastModifiedBy()))) &&
            ((this.lastModifiedById==null && other.getLastModifiedById()==null) || 
             (this.lastModifiedById!=null &&
              this.lastModifiedById.equals(other.getLastModifiedById()))) &&
            ((this.lastModifiedDate==null && other.getLastModifiedDate()==null) || 
             (this.lastModifiedDate!=null &&
              this.lastModifiedDate.equals(other.getLastModifiedDate()))) &&
            ((this.marketPrice__c==null && other.getMarketPrice__c()==null) || 
             (this.marketPrice__c!=null &&
              this.marketPrice__c.equals(other.getMarketPrice__c()))) &&
            ((this.maxJoin__c==null && other.getMaxJoin__c()==null) || 
             (this.maxJoin__c!=null &&
              this.maxJoin__c.equals(other.getMaxJoin__c()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.needAllowance__c==null && other.getNeedAllowance__c()==null) || 
             (this.needAllowance__c!=null &&
              this.needAllowance__c.equals(other.getNeedAllowance__c()))) &&
            ((this.notes==null && other.getNotes()==null) || 
             (this.notes!=null &&
              this.notes.equals(other.getNotes()))) &&
            ((this.notesAndAttachments==null && other.getNotesAndAttachments()==null) || 
             (this.notesAndAttachments!=null &&
              this.notesAndAttachments.equals(other.getNotesAndAttachments()))) &&
            ((this.processInstances==null && other.getProcessInstances()==null) || 
             (this.processInstances!=null &&
              this.processInstances.equals(other.getProcessInstances()))) &&
            ((this.processSteps==null && other.getProcessSteps()==null) || 
             (this.processSteps!=null &&
              this.processSteps.equals(other.getProcessSteps()))) &&
            ((this.productNumber__c==null && other.getProductNumber__c()==null) || 
             (this.productNumber__c!=null &&
              this.productNumber__c.equals(other.getProductNumber__c()))) &&
            ((this.profitMargin__c==null && other.getProfitMargin__c()==null) || 
             (this.profitMargin__c!=null &&
              this.profitMargin__c.equals(other.getProfitMargin__c()))) &&
            ((this.province__c==null && other.getProvince__c()==null) || 
             (this.province__c!=null &&
              this.province__c.equals(other.getProvince__c()))) &&
            ((this.receiptEndDate__c==null && other.getReceiptEndDate__c()==null) || 
             (this.receiptEndDate__c!=null &&
              this.receiptEndDate__c.equals(other.getReceiptEndDate__c()))) &&
            ((this.suggestPrice__c==null && other.getSuggestPrice__c()==null) || 
             (this.suggestPrice__c!=null &&
              this.suggestPrice__c.equals(other.getSuggestPrice__c()))) &&
            ((this.systemModstamp==null && other.getSystemModstamp()==null) || 
             (this.systemModstamp!=null &&
              this.systemModstamp.equals(other.getSystemModstamp()))) &&
            ((this.timesOfUsage__c==null && other.getTimesOfUsage__c()==null) || 
             (this.timesOfUsage__c!=null &&
              this.timesOfUsage__c.equals(other.getTimesOfUsage__c()))) &&
            ((this.validity__c==null && other.getValidity__c()==null) || 
             (this.validity__c!=null &&
              this.validity__c.equals(other.getValidity__c()))) &&
            ((this.isVarifiedByThirdParty__c==null && other.getIsVarifiedByThirdParty__c()==null) || 
             (this.isVarifiedByThirdParty__c!=null &&
              this.isVarifiedByThirdParty__c.equals(other.getIsVarifiedByThirdParty__c())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAttachments() != null) {
            _hashCode += getAttachments().hashCode();
        }
        if (getBranchName__c() != null) {
            _hashCode += getBranchName__c().hashCode();
        }
        if (getCity__c() != null) {
            _hashCode += getCity__c().hashCode();
        }
        if (getContractBankAccountNo__c() != null) {
            _hashCode += getContractBankAccountNo__c().hashCode();
        }
        if (getContractBankAccount__c() != null) {
            _hashCode += getContractBankAccount__c().hashCode();
        }
        if (getContractBankAccount__r() != null) {
            _hashCode += getContractBankAccount__r().hashCode();
        }
        if (getContractBranch__c() != null) {
            _hashCode += getContractBranch__c().hashCode();
        }
        if (getContractStatus__c() != null) {
            _hashCode += getContractStatus__c().hashCode();
        }
        if (getContract__c() != null) {
            _hashCode += getContract__c().hashCode();
        }
        if (getContract__r() != null) {
            _hashCode += getContract__r().hashCode();
        }
        if (getCost__c() != null) {
            _hashCode += getCost__c().hashCode();
        }
        if (getCreatedBy() != null) {
            _hashCode += getCreatedBy().hashCode();
        }
        if (getCreatedById() != null) {
            _hashCode += getCreatedById().hashCode();
        }
        if (getCreatedDate() != null) {
            _hashCode += getCreatedDate().hashCode();
        }
        if (getDateType__c() != null) {
            _hashCode += getDateType__c().hashCode();
        }
        if (getDealAccount__r() != null) {
            _hashCode += getDealAccount__r().hashCode();
        }
        if (getDealGroup__c() != null) {
            _hashCode += getDealGroup__c().hashCode();
        }
        if (getDealGroup__r() != null) {
            _hashCode += getDealGroup__r().hashCode();
        }
        if (getDealOrder__c() != null) {
            _hashCode += getDealOrder__c().hashCode();
        }
        if (getDealPrice__c() != null) {
            _hashCode += getDealPrice__c().hashCode();
        }
        if (getDescription__c() != null) {
            _hashCode += getDescription__c().hashCode();
        }
        if (getDurationUnit__c() != null) {
            _hashCode += getDurationUnit__c().hashCode();
        }
        if (getDuration__c() != null) {
            _hashCode += getDuration__c().hashCode();
        }
        if (getEffectiveReceiptEndDate__c() != null) {
            _hashCode += getEffectiveReceiptEndDate__c().hashCode();
        }
        if (getGapStart__c() != null) {
            _hashCode += getGapStart__c().hashCode();
        }
        if (getHistories() != null) {
            _hashCode += getHistories().hashCode();
        }
        if (getIsDeleted() != null) {
            _hashCode += getIsDeleted().hashCode();
        }
        if (getIsFromCopy__c() != null) {
            _hashCode += getIsFromCopy__c().hashCode();
        }
        if (getLastModifiedBy() != null) {
            _hashCode += getLastModifiedBy().hashCode();
        }
        if (getLastModifiedById() != null) {
            _hashCode += getLastModifiedById().hashCode();
        }
        if (getLastModifiedDate() != null) {
            _hashCode += getLastModifiedDate().hashCode();
        }
        if (getMarketPrice__c() != null) {
            _hashCode += getMarketPrice__c().hashCode();
        }
        if (getMaxJoin__c() != null) {
            _hashCode += getMaxJoin__c().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getNeedAllowance__c() != null) {
            _hashCode += getNeedAllowance__c().hashCode();
        }
        if (getNotes() != null) {
            _hashCode += getNotes().hashCode();
        }
        if (getNotesAndAttachments() != null) {
            _hashCode += getNotesAndAttachments().hashCode();
        }
        if (getProcessInstances() != null) {
            _hashCode += getProcessInstances().hashCode();
        }
        if (getProcessSteps() != null) {
            _hashCode += getProcessSteps().hashCode();
        }
        if (getProductNumber__c() != null) {
            _hashCode += getProductNumber__c().hashCode();
        }
        if (getProfitMargin__c() != null) {
            _hashCode += getProfitMargin__c().hashCode();
        }
        if (getProvince__c() != null) {
            _hashCode += getProvince__c().hashCode();
        }
        if (getReceiptEndDate__c() != null) {
            _hashCode += getReceiptEndDate__c().hashCode();
        }
        if (getSuggestPrice__c() != null) {
            _hashCode += getSuggestPrice__c().hashCode();
        }
        if (getSystemModstamp() != null) {
            _hashCode += getSystemModstamp().hashCode();
        }
        if (getTimesOfUsage__c() != null) {
            _hashCode += getTimesOfUsage__c().hashCode();
        }
        if (getValidity__c() != null) {
            _hashCode += getValidity__c().hashCode();
        }
        if (getIsVarifiedByThirdParty__c() != null) {
            _hashCode += getIsVarifiedByThirdParty__c().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Deal__c.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Deal__c"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Attachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("branchName__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BranchName__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("city__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "City__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contractBankAccountNo__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ContractBankAccountNo__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contractBankAccount__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ContractBankAccount__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contractBankAccount__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ContractBankAccount__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ContractBankAccount__c"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contractBranch__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ContractBranch__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contractStatus__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ContractStatus__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contract__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Contract__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contract__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Contract__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Contract"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cost__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Cost__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dateType__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DateType__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dealAccount__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DealAccount__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dealGroup__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DealGroup__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dealGroup__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DealGroup__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DealGroup__c"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dealOrder__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DealOrder__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dealPrice__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DealPrice__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Description__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("durationUnit__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DurationUnit__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("duration__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Duration__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("effectiveReceiptEndDate__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "EffectiveReceiptEndDate__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("gapStart__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "GapStart__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("histories");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Histories"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isDeleted");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsDeleted"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isFromCopy__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsFromCopy__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("marketPrice__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "MarketPrice__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maxJoin__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "MaxJoin__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("needAllowance__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NeedAllowance__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notes");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Notes"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notesAndAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NotesAndAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processInstances");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessInstances"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processSteps");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessSteps"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("productNumber__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProductNumber__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("profitMargin__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProfitMargin__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("province__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Province__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("receiptEndDate__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ReceiptEndDate__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("suggestPrice__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SuggestPrice__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("systemModstamp");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SystemModstamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("timesOfUsage__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TimesOfUsage__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("validity__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Validity__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isVarifiedByThirdParty__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "isVarifiedByThirdParty__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
