/**
 * PayRule__c.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.sforce.soap.enterprise.sobject;

public class PayRule__c  extends com.sforce.soap.enterprise.sobject.SObject  implements java.io.Serializable {
    private com.sforce.soap.enterprise.QueryResult attachments;

    private java.lang.String contractStatus__c;

    private java.lang.String contract__c;

    private com.sforce.soap.enterprise.QueryResult contract__r;

    private com.sforce.soap.enterprise.sobject.User createdBy;

    private java.lang.String createdById;

    private java.util.Calendar createdDate;

    private java.lang.Double exImportedDay__c;

    private java.lang.Double FPSettleType__c;

    private java.lang.Double firstPaymentPercent__c;

    private com.sforce.soap.enterprise.QueryResult histories;

    private java.lang.Boolean isDeleted;

    private java.lang.Double isPrepayments__c;

    private java.lang.Double lastInterval__c;

    private com.sforce.soap.enterprise.sobject.User lastModifiedBy;

    private java.lang.String lastModifiedById;

    private java.util.Calendar lastModifiedDate;

    private java.lang.String name;

    private com.sforce.soap.enterprise.QueryResult notes;

    private com.sforce.soap.enterprise.QueryResult notesAndAttachments;

    private com.sforce.soap.enterprise.sobject.Name owner;

    private java.lang.String ownerId;

    private java.lang.String payRuleMemo__c;

    private java.lang.Double payRuleType__c;

    private com.sforce.soap.enterprise.QueryResult payRule_PayRuleDetail__r;

    private java.lang.Double paymentRollUpPercent__c;

    private java.lang.Double prepayCouponQuantity__c;

    private java.util.Calendar prepayDeadLine__c;

    private java.lang.Double prepaySettlePrice__c;

    private java.lang.Double prepayments__c;

    private com.sforce.soap.enterprise.QueryResult processInstances;

    private com.sforce.soap.enterprise.QueryResult processSteps;

    private java.lang.Double salesIsPrepayments__c;

    private java.lang.Double salesPrepayments__c;

    private java.lang.Double sequelPaymentPercent__c;

    private java.util.Calendar systemModstamp;

    public PayRule__c() {
    }

    public PayRule__c(
           java.lang.String[] fieldsToNull,
           java.lang.String id,
           com.sforce.soap.enterprise.QueryResult attachments,
           java.lang.String contractStatus__c,
           java.lang.String contract__c,
           com.sforce.soap.enterprise.QueryResult contract__r,
           com.sforce.soap.enterprise.sobject.User createdBy,
           java.lang.String createdById,
           java.util.Calendar createdDate,
           java.lang.Double exImportedDay__c,
           java.lang.Double FPSettleType__c,
           java.lang.Double firstPaymentPercent__c,
           com.sforce.soap.enterprise.QueryResult histories,
           java.lang.Boolean isDeleted,
           java.lang.Double isPrepayments__c,
           java.lang.Double lastInterval__c,
           com.sforce.soap.enterprise.sobject.User lastModifiedBy,
           java.lang.String lastModifiedById,
           java.util.Calendar lastModifiedDate,
           java.lang.String name,
           com.sforce.soap.enterprise.QueryResult notes,
           com.sforce.soap.enterprise.QueryResult notesAndAttachments,
           com.sforce.soap.enterprise.sobject.Name owner,
           java.lang.String ownerId,
           java.lang.String payRuleMemo__c,
           java.lang.Double payRuleType__c,
           com.sforce.soap.enterprise.QueryResult payRule_PayRuleDetail__r,
           java.lang.Double paymentRollUpPercent__c,
           java.lang.Double prepayCouponQuantity__c,
           java.util.Calendar prepayDeadLine__c,
           java.lang.Double prepaySettlePrice__c,
           java.lang.Double prepayments__c,
           com.sforce.soap.enterprise.QueryResult processInstances,
           com.sforce.soap.enterprise.QueryResult processSteps,
           java.lang.Double salesIsPrepayments__c,
           java.lang.Double salesPrepayments__c,
           java.lang.Double sequelPaymentPercent__c,
           java.util.Calendar systemModstamp) {
        super(
            fieldsToNull,
            id);
        this.attachments = attachments;
        this.contractStatus__c = contractStatus__c;
        this.contract__c = contract__c;
        this.contract__r = contract__r;
        this.createdBy = createdBy;
        this.createdById = createdById;
        this.createdDate = createdDate;
        this.exImportedDay__c = exImportedDay__c;
        this.FPSettleType__c = FPSettleType__c;
        this.firstPaymentPercent__c = firstPaymentPercent__c;
        this.histories = histories;
        this.isDeleted = isDeleted;
        this.isPrepayments__c = isPrepayments__c;
        this.lastInterval__c = lastInterval__c;
        this.lastModifiedBy = lastModifiedBy;
        this.lastModifiedById = lastModifiedById;
        this.lastModifiedDate = lastModifiedDate;
        this.name = name;
        this.notes = notes;
        this.notesAndAttachments = notesAndAttachments;
        this.owner = owner;
        this.ownerId = ownerId;
        this.payRuleMemo__c = payRuleMemo__c;
        this.payRuleType__c = payRuleType__c;
        this.payRule_PayRuleDetail__r = payRule_PayRuleDetail__r;
        this.paymentRollUpPercent__c = paymentRollUpPercent__c;
        this.prepayCouponQuantity__c = prepayCouponQuantity__c;
        this.prepayDeadLine__c = prepayDeadLine__c;
        this.prepaySettlePrice__c = prepaySettlePrice__c;
        this.prepayments__c = prepayments__c;
        this.processInstances = processInstances;
        this.processSteps = processSteps;
        this.salesIsPrepayments__c = salesIsPrepayments__c;
        this.salesPrepayments__c = salesPrepayments__c;
        this.sequelPaymentPercent__c = sequelPaymentPercent__c;
        this.systemModstamp = systemModstamp;
    }


    /**
     * Gets the attachments value for this PayRule__c.
     * 
     * @return attachments
     */
    public com.sforce.soap.enterprise.QueryResult getAttachments() {
        return attachments;
    }


    /**
     * Sets the attachments value for this PayRule__c.
     * 
     * @param attachments
     */
    public void setAttachments(com.sforce.soap.enterprise.QueryResult attachments) {
        this.attachments = attachments;
    }


    /**
     * Gets the contractStatus__c value for this PayRule__c.
     * 
     * @return contractStatus__c
     */
    public java.lang.String getContractStatus__c() {
        return contractStatus__c;
    }


    /**
     * Sets the contractStatus__c value for this PayRule__c.
     * 
     * @param contractStatus__c
     */
    public void setContractStatus__c(java.lang.String contractStatus__c) {
        this.contractStatus__c = contractStatus__c;
    }


    /**
     * Gets the contract__c value for this PayRule__c.
     * 
     * @return contract__c
     */
    public java.lang.String getContract__c() {
        return contract__c;
    }


    /**
     * Sets the contract__c value for this PayRule__c.
     * 
     * @param contract__c
     */
    public void setContract__c(java.lang.String contract__c) {
        this.contract__c = contract__c;
    }


    /**
     * Gets the contract__r value for this PayRule__c.
     * 
     * @return contract__r
     */
    public com.sforce.soap.enterprise.QueryResult getContract__r() {
        return contract__r;
    }


    /**
     * Sets the contract__r value for this PayRule__c.
     * 
     * @param contract__r
     */
    public void setContract__r(com.sforce.soap.enterprise.QueryResult contract__r) {
        this.contract__r = contract__r;
    }


    /**
     * Gets the createdBy value for this PayRule__c.
     * 
     * @return createdBy
     */
    public com.sforce.soap.enterprise.sobject.User getCreatedBy() {
        return createdBy;
    }


    /**
     * Sets the createdBy value for this PayRule__c.
     * 
     * @param createdBy
     */
    public void setCreatedBy(com.sforce.soap.enterprise.sobject.User createdBy) {
        this.createdBy = createdBy;
    }


    /**
     * Gets the createdById value for this PayRule__c.
     * 
     * @return createdById
     */
    public java.lang.String getCreatedById() {
        return createdById;
    }


    /**
     * Sets the createdById value for this PayRule__c.
     * 
     * @param createdById
     */
    public void setCreatedById(java.lang.String createdById) {
        this.createdById = createdById;
    }


    /**
     * Gets the createdDate value for this PayRule__c.
     * 
     * @return createdDate
     */
    public java.util.Calendar getCreatedDate() {
        return createdDate;
    }


    /**
     * Sets the createdDate value for this PayRule__c.
     * 
     * @param createdDate
     */
    public void setCreatedDate(java.util.Calendar createdDate) {
        this.createdDate = createdDate;
    }


    /**
     * Gets the exImportedDay__c value for this PayRule__c.
     * 
     * @return exImportedDay__c
     */
    public java.lang.Double getExImportedDay__c() {
        return exImportedDay__c;
    }


    /**
     * Sets the exImportedDay__c value for this PayRule__c.
     * 
     * @param exImportedDay__c
     */
    public void setExImportedDay__c(java.lang.Double exImportedDay__c) {
        this.exImportedDay__c = exImportedDay__c;
    }


    /**
     * Gets the FPSettleType__c value for this PayRule__c.
     * 
     * @return FPSettleType__c
     */
    public java.lang.Double getFPSettleType__c() {
        return FPSettleType__c;
    }


    /**
     * Sets the FPSettleType__c value for this PayRule__c.
     * 
     * @param FPSettleType__c
     */
    public void setFPSettleType__c(java.lang.Double FPSettleType__c) {
        this.FPSettleType__c = FPSettleType__c;
    }


    /**
     * Gets the firstPaymentPercent__c value for this PayRule__c.
     * 
     * @return firstPaymentPercent__c
     */
    public java.lang.Double getFirstPaymentPercent__c() {
        return firstPaymentPercent__c;
    }


    /**
     * Sets the firstPaymentPercent__c value for this PayRule__c.
     * 
     * @param firstPaymentPercent__c
     */
    public void setFirstPaymentPercent__c(java.lang.Double firstPaymentPercent__c) {
        this.firstPaymentPercent__c = firstPaymentPercent__c;
    }


    /**
     * Gets the histories value for this PayRule__c.
     * 
     * @return histories
     */
    public com.sforce.soap.enterprise.QueryResult getHistories() {
        return histories;
    }


    /**
     * Sets the histories value for this PayRule__c.
     * 
     * @param histories
     */
    public void setHistories(com.sforce.soap.enterprise.QueryResult histories) {
        this.histories = histories;
    }


    /**
     * Gets the isDeleted value for this PayRule__c.
     * 
     * @return isDeleted
     */
    public java.lang.Boolean getIsDeleted() {
        return isDeleted;
    }


    /**
     * Sets the isDeleted value for this PayRule__c.
     * 
     * @param isDeleted
     */
    public void setIsDeleted(java.lang.Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }


    /**
     * Gets the isPrepayments__c value for this PayRule__c.
     * 
     * @return isPrepayments__c
     */
    public java.lang.Double getIsPrepayments__c() {
        return isPrepayments__c;
    }


    /**
     * Sets the isPrepayments__c value for this PayRule__c.
     * 
     * @param isPrepayments__c
     */
    public void setIsPrepayments__c(java.lang.Double isPrepayments__c) {
        this.isPrepayments__c = isPrepayments__c;
    }


    /**
     * Gets the lastInterval__c value for this PayRule__c.
     * 
     * @return lastInterval__c
     */
    public java.lang.Double getLastInterval__c() {
        return lastInterval__c;
    }


    /**
     * Sets the lastInterval__c value for this PayRule__c.
     * 
     * @param lastInterval__c
     */
    public void setLastInterval__c(java.lang.Double lastInterval__c) {
        this.lastInterval__c = lastInterval__c;
    }


    /**
     * Gets the lastModifiedBy value for this PayRule__c.
     * 
     * @return lastModifiedBy
     */
    public com.sforce.soap.enterprise.sobject.User getLastModifiedBy() {
        return lastModifiedBy;
    }


    /**
     * Sets the lastModifiedBy value for this PayRule__c.
     * 
     * @param lastModifiedBy
     */
    public void setLastModifiedBy(com.sforce.soap.enterprise.sobject.User lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }


    /**
     * Gets the lastModifiedById value for this PayRule__c.
     * 
     * @return lastModifiedById
     */
    public java.lang.String getLastModifiedById() {
        return lastModifiedById;
    }


    /**
     * Sets the lastModifiedById value for this PayRule__c.
     * 
     * @param lastModifiedById
     */
    public void setLastModifiedById(java.lang.String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }


    /**
     * Gets the lastModifiedDate value for this PayRule__c.
     * 
     * @return lastModifiedDate
     */
    public java.util.Calendar getLastModifiedDate() {
        return lastModifiedDate;
    }


    /**
     * Sets the lastModifiedDate value for this PayRule__c.
     * 
     * @param lastModifiedDate
     */
    public void setLastModifiedDate(java.util.Calendar lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }


    /**
     * Gets the name value for this PayRule__c.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this PayRule__c.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the notes value for this PayRule__c.
     * 
     * @return notes
     */
    public com.sforce.soap.enterprise.QueryResult getNotes() {
        return notes;
    }


    /**
     * Sets the notes value for this PayRule__c.
     * 
     * @param notes
     */
    public void setNotes(com.sforce.soap.enterprise.QueryResult notes) {
        this.notes = notes;
    }


    /**
     * Gets the notesAndAttachments value for this PayRule__c.
     * 
     * @return notesAndAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getNotesAndAttachments() {
        return notesAndAttachments;
    }


    /**
     * Sets the notesAndAttachments value for this PayRule__c.
     * 
     * @param notesAndAttachments
     */
    public void setNotesAndAttachments(com.sforce.soap.enterprise.QueryResult notesAndAttachments) {
        this.notesAndAttachments = notesAndAttachments;
    }


    /**
     * Gets the owner value for this PayRule__c.
     * 
     * @return owner
     */
    public com.sforce.soap.enterprise.sobject.Name getOwner() {
        return owner;
    }


    /**
     * Sets the owner value for this PayRule__c.
     * 
     * @param owner
     */
    public void setOwner(com.sforce.soap.enterprise.sobject.Name owner) {
        this.owner = owner;
    }


    /**
     * Gets the ownerId value for this PayRule__c.
     * 
     * @return ownerId
     */
    public java.lang.String getOwnerId() {
        return ownerId;
    }


    /**
     * Sets the ownerId value for this PayRule__c.
     * 
     * @param ownerId
     */
    public void setOwnerId(java.lang.String ownerId) {
        this.ownerId = ownerId;
    }


    /**
     * Gets the payRuleMemo__c value for this PayRule__c.
     * 
     * @return payRuleMemo__c
     */
    public java.lang.String getPayRuleMemo__c() {
        return payRuleMemo__c;
    }


    /**
     * Sets the payRuleMemo__c value for this PayRule__c.
     * 
     * @param payRuleMemo__c
     */
    public void setPayRuleMemo__c(java.lang.String payRuleMemo__c) {
        this.payRuleMemo__c = payRuleMemo__c;
    }


    /**
     * Gets the payRuleType__c value for this PayRule__c.
     * 
     * @return payRuleType__c
     */
    public java.lang.Double getPayRuleType__c() {
        return payRuleType__c;
    }


    /**
     * Sets the payRuleType__c value for this PayRule__c.
     * 
     * @param payRuleType__c
     */
    public void setPayRuleType__c(java.lang.Double payRuleType__c) {
        this.payRuleType__c = payRuleType__c;
    }


    /**
     * Gets the payRule_PayRuleDetail__r value for this PayRule__c.
     * 
     * @return payRule_PayRuleDetail__r
     */
    public com.sforce.soap.enterprise.QueryResult getPayRule_PayRuleDetail__r() {
        return payRule_PayRuleDetail__r;
    }


    /**
     * Sets the payRule_PayRuleDetail__r value for this PayRule__c.
     * 
     * @param payRule_PayRuleDetail__r
     */
    public void setPayRule_PayRuleDetail__r(com.sforce.soap.enterprise.QueryResult payRule_PayRuleDetail__r) {
        this.payRule_PayRuleDetail__r = payRule_PayRuleDetail__r;
    }


    /**
     * Gets the paymentRollUpPercent__c value for this PayRule__c.
     * 
     * @return paymentRollUpPercent__c
     */
    public java.lang.Double getPaymentRollUpPercent__c() {
        return paymentRollUpPercent__c;
    }


    /**
     * Sets the paymentRollUpPercent__c value for this PayRule__c.
     * 
     * @param paymentRollUpPercent__c
     */
    public void setPaymentRollUpPercent__c(java.lang.Double paymentRollUpPercent__c) {
        this.paymentRollUpPercent__c = paymentRollUpPercent__c;
    }


    /**
     * Gets the prepayCouponQuantity__c value for this PayRule__c.
     * 
     * @return prepayCouponQuantity__c
     */
    public java.lang.Double getPrepayCouponQuantity__c() {
        return prepayCouponQuantity__c;
    }


    /**
     * Sets the prepayCouponQuantity__c value for this PayRule__c.
     * 
     * @param prepayCouponQuantity__c
     */
    public void setPrepayCouponQuantity__c(java.lang.Double prepayCouponQuantity__c) {
        this.prepayCouponQuantity__c = prepayCouponQuantity__c;
    }


    /**
     * Gets the prepayDeadLine__c value for this PayRule__c.
     * 
     * @return prepayDeadLine__c
     */
    public java.util.Calendar getPrepayDeadLine__c() {
        return prepayDeadLine__c;
    }


    /**
     * Sets the prepayDeadLine__c value for this PayRule__c.
     * 
     * @param prepayDeadLine__c
     */
    public void setPrepayDeadLine__c(java.util.Calendar prepayDeadLine__c) {
        this.prepayDeadLine__c = prepayDeadLine__c;
    }


    /**
     * Gets the prepaySettlePrice__c value for this PayRule__c.
     * 
     * @return prepaySettlePrice__c
     */
    public java.lang.Double getPrepaySettlePrice__c() {
        return prepaySettlePrice__c;
    }


    /**
     * Sets the prepaySettlePrice__c value for this PayRule__c.
     * 
     * @param prepaySettlePrice__c
     */
    public void setPrepaySettlePrice__c(java.lang.Double prepaySettlePrice__c) {
        this.prepaySettlePrice__c = prepaySettlePrice__c;
    }


    /**
     * Gets the prepayments__c value for this PayRule__c.
     * 
     * @return prepayments__c
     */
    public java.lang.Double getPrepayments__c() {
        return prepayments__c;
    }


    /**
     * Sets the prepayments__c value for this PayRule__c.
     * 
     * @param prepayments__c
     */
    public void setPrepayments__c(java.lang.Double prepayments__c) {
        this.prepayments__c = prepayments__c;
    }


    /**
     * Gets the processInstances value for this PayRule__c.
     * 
     * @return processInstances
     */
    public com.sforce.soap.enterprise.QueryResult getProcessInstances() {
        return processInstances;
    }


    /**
     * Sets the processInstances value for this PayRule__c.
     * 
     * @param processInstances
     */
    public void setProcessInstances(com.sforce.soap.enterprise.QueryResult processInstances) {
        this.processInstances = processInstances;
    }


    /**
     * Gets the processSteps value for this PayRule__c.
     * 
     * @return processSteps
     */
    public com.sforce.soap.enterprise.QueryResult getProcessSteps() {
        return processSteps;
    }


    /**
     * Sets the processSteps value for this PayRule__c.
     * 
     * @param processSteps
     */
    public void setProcessSteps(com.sforce.soap.enterprise.QueryResult processSteps) {
        this.processSteps = processSteps;
    }


    /**
     * Gets the salesIsPrepayments__c value for this PayRule__c.
     * 
     * @return salesIsPrepayments__c
     */
    public java.lang.Double getSalesIsPrepayments__c() {
        return salesIsPrepayments__c;
    }


    /**
     * Sets the salesIsPrepayments__c value for this PayRule__c.
     * 
     * @param salesIsPrepayments__c
     */
    public void setSalesIsPrepayments__c(java.lang.Double salesIsPrepayments__c) {
        this.salesIsPrepayments__c = salesIsPrepayments__c;
    }


    /**
     * Gets the salesPrepayments__c value for this PayRule__c.
     * 
     * @return salesPrepayments__c
     */
    public java.lang.Double getSalesPrepayments__c() {
        return salesPrepayments__c;
    }


    /**
     * Sets the salesPrepayments__c value for this PayRule__c.
     * 
     * @param salesPrepayments__c
     */
    public void setSalesPrepayments__c(java.lang.Double salesPrepayments__c) {
        this.salesPrepayments__c = salesPrepayments__c;
    }


    /**
     * Gets the sequelPaymentPercent__c value for this PayRule__c.
     * 
     * @return sequelPaymentPercent__c
     */
    public java.lang.Double getSequelPaymentPercent__c() {
        return sequelPaymentPercent__c;
    }


    /**
     * Sets the sequelPaymentPercent__c value for this PayRule__c.
     * 
     * @param sequelPaymentPercent__c
     */
    public void setSequelPaymentPercent__c(java.lang.Double sequelPaymentPercent__c) {
        this.sequelPaymentPercent__c = sequelPaymentPercent__c;
    }


    /**
     * Gets the systemModstamp value for this PayRule__c.
     * 
     * @return systemModstamp
     */
    public java.util.Calendar getSystemModstamp() {
        return systemModstamp;
    }


    /**
     * Sets the systemModstamp value for this PayRule__c.
     * 
     * @param systemModstamp
     */
    public void setSystemModstamp(java.util.Calendar systemModstamp) {
        this.systemModstamp = systemModstamp;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof PayRule__c)) return false;
        PayRule__c other = (PayRule__c) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.attachments==null && other.getAttachments()==null) || 
             (this.attachments!=null &&
              this.attachments.equals(other.getAttachments()))) &&
            ((this.contractStatus__c==null && other.getContractStatus__c()==null) || 
             (this.contractStatus__c!=null &&
              this.contractStatus__c.equals(other.getContractStatus__c()))) &&
            ((this.contract__c==null && other.getContract__c()==null) || 
             (this.contract__c!=null &&
              this.contract__c.equals(other.getContract__c()))) &&
            ((this.contract__r==null && other.getContract__r()==null) || 
             (this.contract__r!=null &&
              this.contract__r.equals(other.getContract__r()))) &&
            ((this.createdBy==null && other.getCreatedBy()==null) || 
             (this.createdBy!=null &&
              this.createdBy.equals(other.getCreatedBy()))) &&
            ((this.createdById==null && other.getCreatedById()==null) || 
             (this.createdById!=null &&
              this.createdById.equals(other.getCreatedById()))) &&
            ((this.createdDate==null && other.getCreatedDate()==null) || 
             (this.createdDate!=null &&
              this.createdDate.equals(other.getCreatedDate()))) &&
            ((this.exImportedDay__c==null && other.getExImportedDay__c()==null) || 
             (this.exImportedDay__c!=null &&
              this.exImportedDay__c.equals(other.getExImportedDay__c()))) &&
            ((this.FPSettleType__c==null && other.getFPSettleType__c()==null) || 
             (this.FPSettleType__c!=null &&
              this.FPSettleType__c.equals(other.getFPSettleType__c()))) &&
            ((this.firstPaymentPercent__c==null && other.getFirstPaymentPercent__c()==null) || 
             (this.firstPaymentPercent__c!=null &&
              this.firstPaymentPercent__c.equals(other.getFirstPaymentPercent__c()))) &&
            ((this.histories==null && other.getHistories()==null) || 
             (this.histories!=null &&
              this.histories.equals(other.getHistories()))) &&
            ((this.isDeleted==null && other.getIsDeleted()==null) || 
             (this.isDeleted!=null &&
              this.isDeleted.equals(other.getIsDeleted()))) &&
            ((this.isPrepayments__c==null && other.getIsPrepayments__c()==null) || 
             (this.isPrepayments__c!=null &&
              this.isPrepayments__c.equals(other.getIsPrepayments__c()))) &&
            ((this.lastInterval__c==null && other.getLastInterval__c()==null) || 
             (this.lastInterval__c!=null &&
              this.lastInterval__c.equals(other.getLastInterval__c()))) &&
            ((this.lastModifiedBy==null && other.getLastModifiedBy()==null) || 
             (this.lastModifiedBy!=null &&
              this.lastModifiedBy.equals(other.getLastModifiedBy()))) &&
            ((this.lastModifiedById==null && other.getLastModifiedById()==null) || 
             (this.lastModifiedById!=null &&
              this.lastModifiedById.equals(other.getLastModifiedById()))) &&
            ((this.lastModifiedDate==null && other.getLastModifiedDate()==null) || 
             (this.lastModifiedDate!=null &&
              this.lastModifiedDate.equals(other.getLastModifiedDate()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.notes==null && other.getNotes()==null) || 
             (this.notes!=null &&
              this.notes.equals(other.getNotes()))) &&
            ((this.notesAndAttachments==null && other.getNotesAndAttachments()==null) || 
             (this.notesAndAttachments!=null &&
              this.notesAndAttachments.equals(other.getNotesAndAttachments()))) &&
            ((this.owner==null && other.getOwner()==null) || 
             (this.owner!=null &&
              this.owner.equals(other.getOwner()))) &&
            ((this.ownerId==null && other.getOwnerId()==null) || 
             (this.ownerId!=null &&
              this.ownerId.equals(other.getOwnerId()))) &&
            ((this.payRuleMemo__c==null && other.getPayRuleMemo__c()==null) || 
             (this.payRuleMemo__c!=null &&
              this.payRuleMemo__c.equals(other.getPayRuleMemo__c()))) &&
            ((this.payRuleType__c==null && other.getPayRuleType__c()==null) || 
             (this.payRuleType__c!=null &&
              this.payRuleType__c.equals(other.getPayRuleType__c()))) &&
            ((this.payRule_PayRuleDetail__r==null && other.getPayRule_PayRuleDetail__r()==null) || 
             (this.payRule_PayRuleDetail__r!=null &&
              this.payRule_PayRuleDetail__r.equals(other.getPayRule_PayRuleDetail__r()))) &&
            ((this.paymentRollUpPercent__c==null && other.getPaymentRollUpPercent__c()==null) || 
             (this.paymentRollUpPercent__c!=null &&
              this.paymentRollUpPercent__c.equals(other.getPaymentRollUpPercent__c()))) &&
            ((this.prepayCouponQuantity__c==null && other.getPrepayCouponQuantity__c()==null) || 
             (this.prepayCouponQuantity__c!=null &&
              this.prepayCouponQuantity__c.equals(other.getPrepayCouponQuantity__c()))) &&
            ((this.prepayDeadLine__c==null && other.getPrepayDeadLine__c()==null) || 
             (this.prepayDeadLine__c!=null &&
              this.prepayDeadLine__c.equals(other.getPrepayDeadLine__c()))) &&
            ((this.prepaySettlePrice__c==null && other.getPrepaySettlePrice__c()==null) || 
             (this.prepaySettlePrice__c!=null &&
              this.prepaySettlePrice__c.equals(other.getPrepaySettlePrice__c()))) &&
            ((this.prepayments__c==null && other.getPrepayments__c()==null) || 
             (this.prepayments__c!=null &&
              this.prepayments__c.equals(other.getPrepayments__c()))) &&
            ((this.processInstances==null && other.getProcessInstances()==null) || 
             (this.processInstances!=null &&
              this.processInstances.equals(other.getProcessInstances()))) &&
            ((this.processSteps==null && other.getProcessSteps()==null) || 
             (this.processSteps!=null &&
              this.processSteps.equals(other.getProcessSteps()))) &&
            ((this.salesIsPrepayments__c==null && other.getSalesIsPrepayments__c()==null) || 
             (this.salesIsPrepayments__c!=null &&
              this.salesIsPrepayments__c.equals(other.getSalesIsPrepayments__c()))) &&
            ((this.salesPrepayments__c==null && other.getSalesPrepayments__c()==null) || 
             (this.salesPrepayments__c!=null &&
              this.salesPrepayments__c.equals(other.getSalesPrepayments__c()))) &&
            ((this.sequelPaymentPercent__c==null && other.getSequelPaymentPercent__c()==null) || 
             (this.sequelPaymentPercent__c!=null &&
              this.sequelPaymentPercent__c.equals(other.getSequelPaymentPercent__c()))) &&
            ((this.systemModstamp==null && other.getSystemModstamp()==null) || 
             (this.systemModstamp!=null &&
              this.systemModstamp.equals(other.getSystemModstamp())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAttachments() != null) {
            _hashCode += getAttachments().hashCode();
        }
        if (getContractStatus__c() != null) {
            _hashCode += getContractStatus__c().hashCode();
        }
        if (getContract__c() != null) {
            _hashCode += getContract__c().hashCode();
        }
        if (getContract__r() != null) {
            _hashCode += getContract__r().hashCode();
        }
        if (getCreatedBy() != null) {
            _hashCode += getCreatedBy().hashCode();
        }
        if (getCreatedById() != null) {
            _hashCode += getCreatedById().hashCode();
        }
        if (getCreatedDate() != null) {
            _hashCode += getCreatedDate().hashCode();
        }
        if (getExImportedDay__c() != null) {
            _hashCode += getExImportedDay__c().hashCode();
        }
        if (getFPSettleType__c() != null) {
            _hashCode += getFPSettleType__c().hashCode();
        }
        if (getFirstPaymentPercent__c() != null) {
            _hashCode += getFirstPaymentPercent__c().hashCode();
        }
        if (getHistories() != null) {
            _hashCode += getHistories().hashCode();
        }
        if (getIsDeleted() != null) {
            _hashCode += getIsDeleted().hashCode();
        }
        if (getIsPrepayments__c() != null) {
            _hashCode += getIsPrepayments__c().hashCode();
        }
        if (getLastInterval__c() != null) {
            _hashCode += getLastInterval__c().hashCode();
        }
        if (getLastModifiedBy() != null) {
            _hashCode += getLastModifiedBy().hashCode();
        }
        if (getLastModifiedById() != null) {
            _hashCode += getLastModifiedById().hashCode();
        }
        if (getLastModifiedDate() != null) {
            _hashCode += getLastModifiedDate().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getNotes() != null) {
            _hashCode += getNotes().hashCode();
        }
        if (getNotesAndAttachments() != null) {
            _hashCode += getNotesAndAttachments().hashCode();
        }
        if (getOwner() != null) {
            _hashCode += getOwner().hashCode();
        }
        if (getOwnerId() != null) {
            _hashCode += getOwnerId().hashCode();
        }
        if (getPayRuleMemo__c() != null) {
            _hashCode += getPayRuleMemo__c().hashCode();
        }
        if (getPayRuleType__c() != null) {
            _hashCode += getPayRuleType__c().hashCode();
        }
        if (getPayRule_PayRuleDetail__r() != null) {
            _hashCode += getPayRule_PayRuleDetail__r().hashCode();
        }
        if (getPaymentRollUpPercent__c() != null) {
            _hashCode += getPaymentRollUpPercent__c().hashCode();
        }
        if (getPrepayCouponQuantity__c() != null) {
            _hashCode += getPrepayCouponQuantity__c().hashCode();
        }
        if (getPrepayDeadLine__c() != null) {
            _hashCode += getPrepayDeadLine__c().hashCode();
        }
        if (getPrepaySettlePrice__c() != null) {
            _hashCode += getPrepaySettlePrice__c().hashCode();
        }
        if (getPrepayments__c() != null) {
            _hashCode += getPrepayments__c().hashCode();
        }
        if (getProcessInstances() != null) {
            _hashCode += getProcessInstances().hashCode();
        }
        if (getProcessSteps() != null) {
            _hashCode += getProcessSteps().hashCode();
        }
        if (getSalesIsPrepayments__c() != null) {
            _hashCode += getSalesIsPrepayments__c().hashCode();
        }
        if (getSalesPrepayments__c() != null) {
            _hashCode += getSalesPrepayments__c().hashCode();
        }
        if (getSequelPaymentPercent__c() != null) {
            _hashCode += getSequelPaymentPercent__c().hashCode();
        }
        if (getSystemModstamp() != null) {
            _hashCode += getSystemModstamp().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(PayRule__c.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PayRule__c"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Attachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contractStatus__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ContractStatus__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contract__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Contract__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contract__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Contract__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("exImportedDay__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ExImportedDay__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("FPSettleType__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "FPSettleType__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("firstPaymentPercent__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "FirstPaymentPercent__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("histories");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Histories"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isDeleted");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsDeleted"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isPrepayments__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsPrepayments__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastInterval__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastInterval__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notes");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Notes"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notesAndAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NotesAndAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("owner");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Owner"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ownerId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OwnerId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("payRuleMemo__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PayRuleMemo__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("payRuleType__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PayRuleType__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("payRule_PayRuleDetail__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PayRule_PayRuleDetail__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paymentRollUpPercent__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PaymentRollUpPercent__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("prepayCouponQuantity__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PrepayCouponQuantity__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("prepayDeadLine__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PrepayDeadLine__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("prepaySettlePrice__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PrepaySettlePrice__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("prepayments__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Prepayments__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processInstances");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessInstances"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processSteps");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessSteps"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("salesIsPrepayments__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SalesIsPrepayments__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("salesPrepayments__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SalesPrepayments__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sequelPaymentPercent__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SequelPaymentPercent__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("systemModstamp");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SystemModstamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
