/**
 * ForecastingItem.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.sforce.soap.enterprise.sobject;

public class ForecastingItem  extends com.sforce.soap.enterprise.sobject.SObject  implements java.io.Serializable {
    private java.lang.Double amountWithoutAdjustments;

    private java.lang.Double amountWithoutManagerAdjustment;

    private java.lang.Double forecastAmount;

    private java.lang.String forecastCategoryName;

    private java.lang.Boolean hasAdjustment;

    private java.lang.Boolean isUpToDate;

    private com.sforce.soap.enterprise.sobject.User owner;

    private java.lang.String ownerId;

    private java.lang.Double ownerOnlyAmount;

    private java.lang.String parentForecastingItemId;

    private java.lang.String periodId;

    private java.util.Calendar systemModstamp;

    public ForecastingItem() {
    }

    public ForecastingItem(
           java.lang.String[] fieldsToNull,
           java.lang.String id,
           java.lang.Double amountWithoutAdjustments,
           java.lang.Double amountWithoutManagerAdjustment,
           java.lang.Double forecastAmount,
           java.lang.String forecastCategoryName,
           java.lang.Boolean hasAdjustment,
           java.lang.Boolean isUpToDate,
           com.sforce.soap.enterprise.sobject.User owner,
           java.lang.String ownerId,
           java.lang.Double ownerOnlyAmount,
           java.lang.String parentForecastingItemId,
           java.lang.String periodId,
           java.util.Calendar systemModstamp) {
        super(
            fieldsToNull,
            id);
        this.amountWithoutAdjustments = amountWithoutAdjustments;
        this.amountWithoutManagerAdjustment = amountWithoutManagerAdjustment;
        this.forecastAmount = forecastAmount;
        this.forecastCategoryName = forecastCategoryName;
        this.hasAdjustment = hasAdjustment;
        this.isUpToDate = isUpToDate;
        this.owner = owner;
        this.ownerId = ownerId;
        this.ownerOnlyAmount = ownerOnlyAmount;
        this.parentForecastingItemId = parentForecastingItemId;
        this.periodId = periodId;
        this.systemModstamp = systemModstamp;
    }


    /**
     * Gets the amountWithoutAdjustments value for this ForecastingItem.
     * 
     * @return amountWithoutAdjustments
     */
    public java.lang.Double getAmountWithoutAdjustments() {
        return amountWithoutAdjustments;
    }


    /**
     * Sets the amountWithoutAdjustments value for this ForecastingItem.
     * 
     * @param amountWithoutAdjustments
     */
    public void setAmountWithoutAdjustments(java.lang.Double amountWithoutAdjustments) {
        this.amountWithoutAdjustments = amountWithoutAdjustments;
    }


    /**
     * Gets the amountWithoutManagerAdjustment value for this ForecastingItem.
     * 
     * @return amountWithoutManagerAdjustment
     */
    public java.lang.Double getAmountWithoutManagerAdjustment() {
        return amountWithoutManagerAdjustment;
    }


    /**
     * Sets the amountWithoutManagerAdjustment value for this ForecastingItem.
     * 
     * @param amountWithoutManagerAdjustment
     */
    public void setAmountWithoutManagerAdjustment(java.lang.Double amountWithoutManagerAdjustment) {
        this.amountWithoutManagerAdjustment = amountWithoutManagerAdjustment;
    }


    /**
     * Gets the forecastAmount value for this ForecastingItem.
     * 
     * @return forecastAmount
     */
    public java.lang.Double getForecastAmount() {
        return forecastAmount;
    }


    /**
     * Sets the forecastAmount value for this ForecastingItem.
     * 
     * @param forecastAmount
     */
    public void setForecastAmount(java.lang.Double forecastAmount) {
        this.forecastAmount = forecastAmount;
    }


    /**
     * Gets the forecastCategoryName value for this ForecastingItem.
     * 
     * @return forecastCategoryName
     */
    public java.lang.String getForecastCategoryName() {
        return forecastCategoryName;
    }


    /**
     * Sets the forecastCategoryName value for this ForecastingItem.
     * 
     * @param forecastCategoryName
     */
    public void setForecastCategoryName(java.lang.String forecastCategoryName) {
        this.forecastCategoryName = forecastCategoryName;
    }


    /**
     * Gets the hasAdjustment value for this ForecastingItem.
     * 
     * @return hasAdjustment
     */
    public java.lang.Boolean getHasAdjustment() {
        return hasAdjustment;
    }


    /**
     * Sets the hasAdjustment value for this ForecastingItem.
     * 
     * @param hasAdjustment
     */
    public void setHasAdjustment(java.lang.Boolean hasAdjustment) {
        this.hasAdjustment = hasAdjustment;
    }


    /**
     * Gets the isUpToDate value for this ForecastingItem.
     * 
     * @return isUpToDate
     */
    public java.lang.Boolean getIsUpToDate() {
        return isUpToDate;
    }


    /**
     * Sets the isUpToDate value for this ForecastingItem.
     * 
     * @param isUpToDate
     */
    public void setIsUpToDate(java.lang.Boolean isUpToDate) {
        this.isUpToDate = isUpToDate;
    }


    /**
     * Gets the owner value for this ForecastingItem.
     * 
     * @return owner
     */
    public com.sforce.soap.enterprise.sobject.User getOwner() {
        return owner;
    }


    /**
     * Sets the owner value for this ForecastingItem.
     * 
     * @param owner
     */
    public void setOwner(com.sforce.soap.enterprise.sobject.User owner) {
        this.owner = owner;
    }


    /**
     * Gets the ownerId value for this ForecastingItem.
     * 
     * @return ownerId
     */
    public java.lang.String getOwnerId() {
        return ownerId;
    }


    /**
     * Sets the ownerId value for this ForecastingItem.
     * 
     * @param ownerId
     */
    public void setOwnerId(java.lang.String ownerId) {
        this.ownerId = ownerId;
    }


    /**
     * Gets the ownerOnlyAmount value for this ForecastingItem.
     * 
     * @return ownerOnlyAmount
     */
    public java.lang.Double getOwnerOnlyAmount() {
        return ownerOnlyAmount;
    }


    /**
     * Sets the ownerOnlyAmount value for this ForecastingItem.
     * 
     * @param ownerOnlyAmount
     */
    public void setOwnerOnlyAmount(java.lang.Double ownerOnlyAmount) {
        this.ownerOnlyAmount = ownerOnlyAmount;
    }


    /**
     * Gets the parentForecastingItemId value for this ForecastingItem.
     * 
     * @return parentForecastingItemId
     */
    public java.lang.String getParentForecastingItemId() {
        return parentForecastingItemId;
    }


    /**
     * Sets the parentForecastingItemId value for this ForecastingItem.
     * 
     * @param parentForecastingItemId
     */
    public void setParentForecastingItemId(java.lang.String parentForecastingItemId) {
        this.parentForecastingItemId = parentForecastingItemId;
    }


    /**
     * Gets the periodId value for this ForecastingItem.
     * 
     * @return periodId
     */
    public java.lang.String getPeriodId() {
        return periodId;
    }


    /**
     * Sets the periodId value for this ForecastingItem.
     * 
     * @param periodId
     */
    public void setPeriodId(java.lang.String periodId) {
        this.periodId = periodId;
    }


    /**
     * Gets the systemModstamp value for this ForecastingItem.
     * 
     * @return systemModstamp
     */
    public java.util.Calendar getSystemModstamp() {
        return systemModstamp;
    }


    /**
     * Sets the systemModstamp value for this ForecastingItem.
     * 
     * @param systemModstamp
     */
    public void setSystemModstamp(java.util.Calendar systemModstamp) {
        this.systemModstamp = systemModstamp;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ForecastingItem)) return false;
        ForecastingItem other = (ForecastingItem) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.amountWithoutAdjustments==null && other.getAmountWithoutAdjustments()==null) || 
             (this.amountWithoutAdjustments!=null &&
              this.amountWithoutAdjustments.equals(other.getAmountWithoutAdjustments()))) &&
            ((this.amountWithoutManagerAdjustment==null && other.getAmountWithoutManagerAdjustment()==null) || 
             (this.amountWithoutManagerAdjustment!=null &&
              this.amountWithoutManagerAdjustment.equals(other.getAmountWithoutManagerAdjustment()))) &&
            ((this.forecastAmount==null && other.getForecastAmount()==null) || 
             (this.forecastAmount!=null &&
              this.forecastAmount.equals(other.getForecastAmount()))) &&
            ((this.forecastCategoryName==null && other.getForecastCategoryName()==null) || 
             (this.forecastCategoryName!=null &&
              this.forecastCategoryName.equals(other.getForecastCategoryName()))) &&
            ((this.hasAdjustment==null && other.getHasAdjustment()==null) || 
             (this.hasAdjustment!=null &&
              this.hasAdjustment.equals(other.getHasAdjustment()))) &&
            ((this.isUpToDate==null && other.getIsUpToDate()==null) || 
             (this.isUpToDate!=null &&
              this.isUpToDate.equals(other.getIsUpToDate()))) &&
            ((this.owner==null && other.getOwner()==null) || 
             (this.owner!=null &&
              this.owner.equals(other.getOwner()))) &&
            ((this.ownerId==null && other.getOwnerId()==null) || 
             (this.ownerId!=null &&
              this.ownerId.equals(other.getOwnerId()))) &&
            ((this.ownerOnlyAmount==null && other.getOwnerOnlyAmount()==null) || 
             (this.ownerOnlyAmount!=null &&
              this.ownerOnlyAmount.equals(other.getOwnerOnlyAmount()))) &&
            ((this.parentForecastingItemId==null && other.getParentForecastingItemId()==null) || 
             (this.parentForecastingItemId!=null &&
              this.parentForecastingItemId.equals(other.getParentForecastingItemId()))) &&
            ((this.periodId==null && other.getPeriodId()==null) || 
             (this.periodId!=null &&
              this.periodId.equals(other.getPeriodId()))) &&
            ((this.systemModstamp==null && other.getSystemModstamp()==null) || 
             (this.systemModstamp!=null &&
              this.systemModstamp.equals(other.getSystemModstamp())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAmountWithoutAdjustments() != null) {
            _hashCode += getAmountWithoutAdjustments().hashCode();
        }
        if (getAmountWithoutManagerAdjustment() != null) {
            _hashCode += getAmountWithoutManagerAdjustment().hashCode();
        }
        if (getForecastAmount() != null) {
            _hashCode += getForecastAmount().hashCode();
        }
        if (getForecastCategoryName() != null) {
            _hashCode += getForecastCategoryName().hashCode();
        }
        if (getHasAdjustment() != null) {
            _hashCode += getHasAdjustment().hashCode();
        }
        if (getIsUpToDate() != null) {
            _hashCode += getIsUpToDate().hashCode();
        }
        if (getOwner() != null) {
            _hashCode += getOwner().hashCode();
        }
        if (getOwnerId() != null) {
            _hashCode += getOwnerId().hashCode();
        }
        if (getOwnerOnlyAmount() != null) {
            _hashCode += getOwnerOnlyAmount().hashCode();
        }
        if (getParentForecastingItemId() != null) {
            _hashCode += getParentForecastingItemId().hashCode();
        }
        if (getPeriodId() != null) {
            _hashCode += getPeriodId().hashCode();
        }
        if (getSystemModstamp() != null) {
            _hashCode += getSystemModstamp().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ForecastingItem.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ForecastingItem"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("amountWithoutAdjustments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AmountWithoutAdjustments"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("amountWithoutManagerAdjustment");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AmountWithoutManagerAdjustment"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("forecastAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ForecastAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("forecastCategoryName");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ForecastCategoryName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hasAdjustment");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "HasAdjustment"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isUpToDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsUpToDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("owner");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Owner"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ownerId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OwnerId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ownerOnlyAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OwnerOnlyAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("parentForecastingItemId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ParentForecastingItemId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("periodId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PeriodId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("systemModstamp");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SystemModstamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
