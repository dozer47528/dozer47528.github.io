/**
 * CaseRefund__c.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.sforce.soap.enterprise.sobject;

public class CaseRefund__c  extends com.sforce.soap.enterprise.sobject.SObject  implements java.io.Serializable {
    private java.lang.String approvalStatus__c;

    private com.sforce.soap.enterprise.QueryResult attachments;

    private java.lang.String caseID__c;

    private com.sforce.soap.enterprise.sobject._case caseID__r;

    private com.sforce.soap.enterprise.sobject.User createdBy;

    private java.lang.String createdById;

    private java.util.Calendar createdDate;

    private java.lang.Boolean isDeleted;

    private com.sforce.soap.enterprise.sobject.User lastModifiedBy;

    private java.lang.String lastModifiedById;

    private java.util.Calendar lastModifiedDate;

    private java.lang.String name;

    private com.sforce.soap.enterprise.QueryResult notes;

    private com.sforce.soap.enterprise.QueryResult notesAndAttachments;

    private java.lang.String orderID__c;

    private com.sforce.soap.enterprise.QueryResult processInstances;

    private com.sforce.soap.enterprise.QueryResult processSteps;

    private java.lang.String refundAPIKEY__c;

    private java.lang.Double refundAmount__c;

    private java.lang.String refundLoginID__c;

    private java.lang.String refundMemo__c;

    private java.lang.String refundReason__c;

    private java.lang.String refundStatus__c;

    private java.lang.String refundTo__c;

    private java.lang.String refundType__c;

    private java.util.Calendar systemModstamp;

    private java.lang.String userID__c;

    public CaseRefund__c() {
    }

    public CaseRefund__c(
           java.lang.String[] fieldsToNull,
           java.lang.String id,
           java.lang.String approvalStatus__c,
           com.sforce.soap.enterprise.QueryResult attachments,
           java.lang.String caseID__c,
           com.sforce.soap.enterprise.sobject._case caseID__r,
           com.sforce.soap.enterprise.sobject.User createdBy,
           java.lang.String createdById,
           java.util.Calendar createdDate,
           java.lang.Boolean isDeleted,
           com.sforce.soap.enterprise.sobject.User lastModifiedBy,
           java.lang.String lastModifiedById,
           java.util.Calendar lastModifiedDate,
           java.lang.String name,
           com.sforce.soap.enterprise.QueryResult notes,
           com.sforce.soap.enterprise.QueryResult notesAndAttachments,
           java.lang.String orderID__c,
           com.sforce.soap.enterprise.QueryResult processInstances,
           com.sforce.soap.enterprise.QueryResult processSteps,
           java.lang.String refundAPIKEY__c,
           java.lang.Double refundAmount__c,
           java.lang.String refundLoginID__c,
           java.lang.String refundMemo__c,
           java.lang.String refundReason__c,
           java.lang.String refundStatus__c,
           java.lang.String refundTo__c,
           java.lang.String refundType__c,
           java.util.Calendar systemModstamp,
           java.lang.String userID__c) {
        super(
            fieldsToNull,
            id);
        this.approvalStatus__c = approvalStatus__c;
        this.attachments = attachments;
        this.caseID__c = caseID__c;
        this.caseID__r = caseID__r;
        this.createdBy = createdBy;
        this.createdById = createdById;
        this.createdDate = createdDate;
        this.isDeleted = isDeleted;
        this.lastModifiedBy = lastModifiedBy;
        this.lastModifiedById = lastModifiedById;
        this.lastModifiedDate = lastModifiedDate;
        this.name = name;
        this.notes = notes;
        this.notesAndAttachments = notesAndAttachments;
        this.orderID__c = orderID__c;
        this.processInstances = processInstances;
        this.processSteps = processSteps;
        this.refundAPIKEY__c = refundAPIKEY__c;
        this.refundAmount__c = refundAmount__c;
        this.refundLoginID__c = refundLoginID__c;
        this.refundMemo__c = refundMemo__c;
        this.refundReason__c = refundReason__c;
        this.refundStatus__c = refundStatus__c;
        this.refundTo__c = refundTo__c;
        this.refundType__c = refundType__c;
        this.systemModstamp = systemModstamp;
        this.userID__c = userID__c;
    }


    /**
     * Gets the approvalStatus__c value for this CaseRefund__c.
     * 
     * @return approvalStatus__c
     */
    public java.lang.String getApprovalStatus__c() {
        return approvalStatus__c;
    }


    /**
     * Sets the approvalStatus__c value for this CaseRefund__c.
     * 
     * @param approvalStatus__c
     */
    public void setApprovalStatus__c(java.lang.String approvalStatus__c) {
        this.approvalStatus__c = approvalStatus__c;
    }


    /**
     * Gets the attachments value for this CaseRefund__c.
     * 
     * @return attachments
     */
    public com.sforce.soap.enterprise.QueryResult getAttachments() {
        return attachments;
    }


    /**
     * Sets the attachments value for this CaseRefund__c.
     * 
     * @param attachments
     */
    public void setAttachments(com.sforce.soap.enterprise.QueryResult attachments) {
        this.attachments = attachments;
    }


    /**
     * Gets the caseID__c value for this CaseRefund__c.
     * 
     * @return caseID__c
     */
    public java.lang.String getCaseID__c() {
        return caseID__c;
    }


    /**
     * Sets the caseID__c value for this CaseRefund__c.
     * 
     * @param caseID__c
     */
    public void setCaseID__c(java.lang.String caseID__c) {
        this.caseID__c = caseID__c;
    }


    /**
     * Gets the caseID__r value for this CaseRefund__c.
     * 
     * @return caseID__r
     */
    public com.sforce.soap.enterprise.sobject._case getCaseID__r() {
        return caseID__r;
    }


    /**
     * Sets the caseID__r value for this CaseRefund__c.
     * 
     * @param caseID__r
     */
    public void setCaseID__r(com.sforce.soap.enterprise.sobject._case caseID__r) {
        this.caseID__r = caseID__r;
    }


    /**
     * Gets the createdBy value for this CaseRefund__c.
     * 
     * @return createdBy
     */
    public com.sforce.soap.enterprise.sobject.User getCreatedBy() {
        return createdBy;
    }


    /**
     * Sets the createdBy value for this CaseRefund__c.
     * 
     * @param createdBy
     */
    public void setCreatedBy(com.sforce.soap.enterprise.sobject.User createdBy) {
        this.createdBy = createdBy;
    }


    /**
     * Gets the createdById value for this CaseRefund__c.
     * 
     * @return createdById
     */
    public java.lang.String getCreatedById() {
        return createdById;
    }


    /**
     * Sets the createdById value for this CaseRefund__c.
     * 
     * @param createdById
     */
    public void setCreatedById(java.lang.String createdById) {
        this.createdById = createdById;
    }


    /**
     * Gets the createdDate value for this CaseRefund__c.
     * 
     * @return createdDate
     */
    public java.util.Calendar getCreatedDate() {
        return createdDate;
    }


    /**
     * Sets the createdDate value for this CaseRefund__c.
     * 
     * @param createdDate
     */
    public void setCreatedDate(java.util.Calendar createdDate) {
        this.createdDate = createdDate;
    }


    /**
     * Gets the isDeleted value for this CaseRefund__c.
     * 
     * @return isDeleted
     */
    public java.lang.Boolean getIsDeleted() {
        return isDeleted;
    }


    /**
     * Sets the isDeleted value for this CaseRefund__c.
     * 
     * @param isDeleted
     */
    public void setIsDeleted(java.lang.Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }


    /**
     * Gets the lastModifiedBy value for this CaseRefund__c.
     * 
     * @return lastModifiedBy
     */
    public com.sforce.soap.enterprise.sobject.User getLastModifiedBy() {
        return lastModifiedBy;
    }


    /**
     * Sets the lastModifiedBy value for this CaseRefund__c.
     * 
     * @param lastModifiedBy
     */
    public void setLastModifiedBy(com.sforce.soap.enterprise.sobject.User lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }


    /**
     * Gets the lastModifiedById value for this CaseRefund__c.
     * 
     * @return lastModifiedById
     */
    public java.lang.String getLastModifiedById() {
        return lastModifiedById;
    }


    /**
     * Sets the lastModifiedById value for this CaseRefund__c.
     * 
     * @param lastModifiedById
     */
    public void setLastModifiedById(java.lang.String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }


    /**
     * Gets the lastModifiedDate value for this CaseRefund__c.
     * 
     * @return lastModifiedDate
     */
    public java.util.Calendar getLastModifiedDate() {
        return lastModifiedDate;
    }


    /**
     * Sets the lastModifiedDate value for this CaseRefund__c.
     * 
     * @param lastModifiedDate
     */
    public void setLastModifiedDate(java.util.Calendar lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }


    /**
     * Gets the name value for this CaseRefund__c.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this CaseRefund__c.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the notes value for this CaseRefund__c.
     * 
     * @return notes
     */
    public com.sforce.soap.enterprise.QueryResult getNotes() {
        return notes;
    }


    /**
     * Sets the notes value for this CaseRefund__c.
     * 
     * @param notes
     */
    public void setNotes(com.sforce.soap.enterprise.QueryResult notes) {
        this.notes = notes;
    }


    /**
     * Gets the notesAndAttachments value for this CaseRefund__c.
     * 
     * @return notesAndAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getNotesAndAttachments() {
        return notesAndAttachments;
    }


    /**
     * Sets the notesAndAttachments value for this CaseRefund__c.
     * 
     * @param notesAndAttachments
     */
    public void setNotesAndAttachments(com.sforce.soap.enterprise.QueryResult notesAndAttachments) {
        this.notesAndAttachments = notesAndAttachments;
    }


    /**
     * Gets the orderID__c value for this CaseRefund__c.
     * 
     * @return orderID__c
     */
    public java.lang.String getOrderID__c() {
        return orderID__c;
    }


    /**
     * Sets the orderID__c value for this CaseRefund__c.
     * 
     * @param orderID__c
     */
    public void setOrderID__c(java.lang.String orderID__c) {
        this.orderID__c = orderID__c;
    }


    /**
     * Gets the processInstances value for this CaseRefund__c.
     * 
     * @return processInstances
     */
    public com.sforce.soap.enterprise.QueryResult getProcessInstances() {
        return processInstances;
    }


    /**
     * Sets the processInstances value for this CaseRefund__c.
     * 
     * @param processInstances
     */
    public void setProcessInstances(com.sforce.soap.enterprise.QueryResult processInstances) {
        this.processInstances = processInstances;
    }


    /**
     * Gets the processSteps value for this CaseRefund__c.
     * 
     * @return processSteps
     */
    public com.sforce.soap.enterprise.QueryResult getProcessSteps() {
        return processSteps;
    }


    /**
     * Sets the processSteps value for this CaseRefund__c.
     * 
     * @param processSteps
     */
    public void setProcessSteps(com.sforce.soap.enterprise.QueryResult processSteps) {
        this.processSteps = processSteps;
    }


    /**
     * Gets the refundAPIKEY__c value for this CaseRefund__c.
     * 
     * @return refundAPIKEY__c
     */
    public java.lang.String getRefundAPIKEY__c() {
        return refundAPIKEY__c;
    }


    /**
     * Sets the refundAPIKEY__c value for this CaseRefund__c.
     * 
     * @param refundAPIKEY__c
     */
    public void setRefundAPIKEY__c(java.lang.String refundAPIKEY__c) {
        this.refundAPIKEY__c = refundAPIKEY__c;
    }


    /**
     * Gets the refundAmount__c value for this CaseRefund__c.
     * 
     * @return refundAmount__c
     */
    public java.lang.Double getRefundAmount__c() {
        return refundAmount__c;
    }


    /**
     * Sets the refundAmount__c value for this CaseRefund__c.
     * 
     * @param refundAmount__c
     */
    public void setRefundAmount__c(java.lang.Double refundAmount__c) {
        this.refundAmount__c = refundAmount__c;
    }


    /**
     * Gets the refundLoginID__c value for this CaseRefund__c.
     * 
     * @return refundLoginID__c
     */
    public java.lang.String getRefundLoginID__c() {
        return refundLoginID__c;
    }


    /**
     * Sets the refundLoginID__c value for this CaseRefund__c.
     * 
     * @param refundLoginID__c
     */
    public void setRefundLoginID__c(java.lang.String refundLoginID__c) {
        this.refundLoginID__c = refundLoginID__c;
    }


    /**
     * Gets the refundMemo__c value for this CaseRefund__c.
     * 
     * @return refundMemo__c
     */
    public java.lang.String getRefundMemo__c() {
        return refundMemo__c;
    }


    /**
     * Sets the refundMemo__c value for this CaseRefund__c.
     * 
     * @param refundMemo__c
     */
    public void setRefundMemo__c(java.lang.String refundMemo__c) {
        this.refundMemo__c = refundMemo__c;
    }


    /**
     * Gets the refundReason__c value for this CaseRefund__c.
     * 
     * @return refundReason__c
     */
    public java.lang.String getRefundReason__c() {
        return refundReason__c;
    }


    /**
     * Sets the refundReason__c value for this CaseRefund__c.
     * 
     * @param refundReason__c
     */
    public void setRefundReason__c(java.lang.String refundReason__c) {
        this.refundReason__c = refundReason__c;
    }


    /**
     * Gets the refundStatus__c value for this CaseRefund__c.
     * 
     * @return refundStatus__c
     */
    public java.lang.String getRefundStatus__c() {
        return refundStatus__c;
    }


    /**
     * Sets the refundStatus__c value for this CaseRefund__c.
     * 
     * @param refundStatus__c
     */
    public void setRefundStatus__c(java.lang.String refundStatus__c) {
        this.refundStatus__c = refundStatus__c;
    }


    /**
     * Gets the refundTo__c value for this CaseRefund__c.
     * 
     * @return refundTo__c
     */
    public java.lang.String getRefundTo__c() {
        return refundTo__c;
    }


    /**
     * Sets the refundTo__c value for this CaseRefund__c.
     * 
     * @param refundTo__c
     */
    public void setRefundTo__c(java.lang.String refundTo__c) {
        this.refundTo__c = refundTo__c;
    }


    /**
     * Gets the refundType__c value for this CaseRefund__c.
     * 
     * @return refundType__c
     */
    public java.lang.String getRefundType__c() {
        return refundType__c;
    }


    /**
     * Sets the refundType__c value for this CaseRefund__c.
     * 
     * @param refundType__c
     */
    public void setRefundType__c(java.lang.String refundType__c) {
        this.refundType__c = refundType__c;
    }


    /**
     * Gets the systemModstamp value for this CaseRefund__c.
     * 
     * @return systemModstamp
     */
    public java.util.Calendar getSystemModstamp() {
        return systemModstamp;
    }


    /**
     * Sets the systemModstamp value for this CaseRefund__c.
     * 
     * @param systemModstamp
     */
    public void setSystemModstamp(java.util.Calendar systemModstamp) {
        this.systemModstamp = systemModstamp;
    }


    /**
     * Gets the userID__c value for this CaseRefund__c.
     * 
     * @return userID__c
     */
    public java.lang.String getUserID__c() {
        return userID__c;
    }


    /**
     * Sets the userID__c value for this CaseRefund__c.
     * 
     * @param userID__c
     */
    public void setUserID__c(java.lang.String userID__c) {
        this.userID__c = userID__c;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CaseRefund__c)) return false;
        CaseRefund__c other = (CaseRefund__c) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.approvalStatus__c==null && other.getApprovalStatus__c()==null) || 
             (this.approvalStatus__c!=null &&
              this.approvalStatus__c.equals(other.getApprovalStatus__c()))) &&
            ((this.attachments==null && other.getAttachments()==null) || 
             (this.attachments!=null &&
              this.attachments.equals(other.getAttachments()))) &&
            ((this.caseID__c==null && other.getCaseID__c()==null) || 
             (this.caseID__c!=null &&
              this.caseID__c.equals(other.getCaseID__c()))) &&
            ((this.caseID__r==null && other.getCaseID__r()==null) || 
             (this.caseID__r!=null &&
              this.caseID__r.equals(other.getCaseID__r()))) &&
            ((this.createdBy==null && other.getCreatedBy()==null) || 
             (this.createdBy!=null &&
              this.createdBy.equals(other.getCreatedBy()))) &&
            ((this.createdById==null && other.getCreatedById()==null) || 
             (this.createdById!=null &&
              this.createdById.equals(other.getCreatedById()))) &&
            ((this.createdDate==null && other.getCreatedDate()==null) || 
             (this.createdDate!=null &&
              this.createdDate.equals(other.getCreatedDate()))) &&
            ((this.isDeleted==null && other.getIsDeleted()==null) || 
             (this.isDeleted!=null &&
              this.isDeleted.equals(other.getIsDeleted()))) &&
            ((this.lastModifiedBy==null && other.getLastModifiedBy()==null) || 
             (this.lastModifiedBy!=null &&
              this.lastModifiedBy.equals(other.getLastModifiedBy()))) &&
            ((this.lastModifiedById==null && other.getLastModifiedById()==null) || 
             (this.lastModifiedById!=null &&
              this.lastModifiedById.equals(other.getLastModifiedById()))) &&
            ((this.lastModifiedDate==null && other.getLastModifiedDate()==null) || 
             (this.lastModifiedDate!=null &&
              this.lastModifiedDate.equals(other.getLastModifiedDate()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.notes==null && other.getNotes()==null) || 
             (this.notes!=null &&
              this.notes.equals(other.getNotes()))) &&
            ((this.notesAndAttachments==null && other.getNotesAndAttachments()==null) || 
             (this.notesAndAttachments!=null &&
              this.notesAndAttachments.equals(other.getNotesAndAttachments()))) &&
            ((this.orderID__c==null && other.getOrderID__c()==null) || 
             (this.orderID__c!=null &&
              this.orderID__c.equals(other.getOrderID__c()))) &&
            ((this.processInstances==null && other.getProcessInstances()==null) || 
             (this.processInstances!=null &&
              this.processInstances.equals(other.getProcessInstances()))) &&
            ((this.processSteps==null && other.getProcessSteps()==null) || 
             (this.processSteps!=null &&
              this.processSteps.equals(other.getProcessSteps()))) &&
            ((this.refundAPIKEY__c==null && other.getRefundAPIKEY__c()==null) || 
             (this.refundAPIKEY__c!=null &&
              this.refundAPIKEY__c.equals(other.getRefundAPIKEY__c()))) &&
            ((this.refundAmount__c==null && other.getRefundAmount__c()==null) || 
             (this.refundAmount__c!=null &&
              this.refundAmount__c.equals(other.getRefundAmount__c()))) &&
            ((this.refundLoginID__c==null && other.getRefundLoginID__c()==null) || 
             (this.refundLoginID__c!=null &&
              this.refundLoginID__c.equals(other.getRefundLoginID__c()))) &&
            ((this.refundMemo__c==null && other.getRefundMemo__c()==null) || 
             (this.refundMemo__c!=null &&
              this.refundMemo__c.equals(other.getRefundMemo__c()))) &&
            ((this.refundReason__c==null && other.getRefundReason__c()==null) || 
             (this.refundReason__c!=null &&
              this.refundReason__c.equals(other.getRefundReason__c()))) &&
            ((this.refundStatus__c==null && other.getRefundStatus__c()==null) || 
             (this.refundStatus__c!=null &&
              this.refundStatus__c.equals(other.getRefundStatus__c()))) &&
            ((this.refundTo__c==null && other.getRefundTo__c()==null) || 
             (this.refundTo__c!=null &&
              this.refundTo__c.equals(other.getRefundTo__c()))) &&
            ((this.refundType__c==null && other.getRefundType__c()==null) || 
             (this.refundType__c!=null &&
              this.refundType__c.equals(other.getRefundType__c()))) &&
            ((this.systemModstamp==null && other.getSystemModstamp()==null) || 
             (this.systemModstamp!=null &&
              this.systemModstamp.equals(other.getSystemModstamp()))) &&
            ((this.userID__c==null && other.getUserID__c()==null) || 
             (this.userID__c!=null &&
              this.userID__c.equals(other.getUserID__c())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getApprovalStatus__c() != null) {
            _hashCode += getApprovalStatus__c().hashCode();
        }
        if (getAttachments() != null) {
            _hashCode += getAttachments().hashCode();
        }
        if (getCaseID__c() != null) {
            _hashCode += getCaseID__c().hashCode();
        }
        if (getCaseID__r() != null) {
            _hashCode += getCaseID__r().hashCode();
        }
        if (getCreatedBy() != null) {
            _hashCode += getCreatedBy().hashCode();
        }
        if (getCreatedById() != null) {
            _hashCode += getCreatedById().hashCode();
        }
        if (getCreatedDate() != null) {
            _hashCode += getCreatedDate().hashCode();
        }
        if (getIsDeleted() != null) {
            _hashCode += getIsDeleted().hashCode();
        }
        if (getLastModifiedBy() != null) {
            _hashCode += getLastModifiedBy().hashCode();
        }
        if (getLastModifiedById() != null) {
            _hashCode += getLastModifiedById().hashCode();
        }
        if (getLastModifiedDate() != null) {
            _hashCode += getLastModifiedDate().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getNotes() != null) {
            _hashCode += getNotes().hashCode();
        }
        if (getNotesAndAttachments() != null) {
            _hashCode += getNotesAndAttachments().hashCode();
        }
        if (getOrderID__c() != null) {
            _hashCode += getOrderID__c().hashCode();
        }
        if (getProcessInstances() != null) {
            _hashCode += getProcessInstances().hashCode();
        }
        if (getProcessSteps() != null) {
            _hashCode += getProcessSteps().hashCode();
        }
        if (getRefundAPIKEY__c() != null) {
            _hashCode += getRefundAPIKEY__c().hashCode();
        }
        if (getRefundAmount__c() != null) {
            _hashCode += getRefundAmount__c().hashCode();
        }
        if (getRefundLoginID__c() != null) {
            _hashCode += getRefundLoginID__c().hashCode();
        }
        if (getRefundMemo__c() != null) {
            _hashCode += getRefundMemo__c().hashCode();
        }
        if (getRefundReason__c() != null) {
            _hashCode += getRefundReason__c().hashCode();
        }
        if (getRefundStatus__c() != null) {
            _hashCode += getRefundStatus__c().hashCode();
        }
        if (getRefundTo__c() != null) {
            _hashCode += getRefundTo__c().hashCode();
        }
        if (getRefundType__c() != null) {
            _hashCode += getRefundType__c().hashCode();
        }
        if (getSystemModstamp() != null) {
            _hashCode += getSystemModstamp().hashCode();
        }
        if (getUserID__c() != null) {
            _hashCode += getUserID__c().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CaseRefund__c.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CaseRefund__c"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("approvalStatus__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ApprovalStatus__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Attachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("caseID__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CaseID__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("caseID__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CaseID__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Case"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isDeleted");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsDeleted"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notes");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Notes"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notesAndAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NotesAndAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderID__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OrderID__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processInstances");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessInstances"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processSteps");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessSteps"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("refundAPIKEY__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RefundAPIKEY__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("refundAmount__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RefundAmount__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("refundLoginID__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RefundLoginID__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("refundMemo__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RefundMemo__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("refundReason__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RefundReason__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("refundStatus__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RefundStatus__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("refundTo__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RefundTo__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("refundType__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RefundType__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("systemModstamp");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SystemModstamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userID__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserID__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
