/**
 * City__c.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.sforce.soap.enterprise.sobject;

public class City__c  extends com.sforce.soap.enterprise.sobject.SObject  implements java.io.Serializable {
    private java.lang.String abbBusiness__c;

    private java.lang.String abbExternal__c;

    private com.sforce.soap.enterprise.QueryResult accountCity__r;

    private com.sforce.soap.enterprise.QueryResult attachments;

    private java.lang.String cityID__c;

    private java.lang.String cityPinyin__c;

    private com.sforce.soap.enterprise.QueryResult city__r;

    private com.sforce.soap.enterprise.QueryResult contractCity__r;

    private com.sforce.soap.enterprise.QueryResult contract_City__r;

    private com.sforce.soap.enterprise.sobject.User createdBy;

    private java.lang.String createdById;

    private java.util.Calendar createdDate;

    private com.sforce.soap.enterprise.QueryResult discountRule__r;

    private com.sforce.soap.enterprise.QueryResult employee__r;

    private com.sforce.soap.enterprise.QueryResult freeProductRule__r;

    private java.lang.Boolean isBulkBuyCity__c;

    private java.lang.Boolean isBusinessCity__c;

    private java.lang.Boolean isDeleted;

    private com.sforce.soap.enterprise.sobject.User lastModifiedBy;

    private java.lang.String lastModifiedById;

    private java.util.Calendar lastModifiedDate;

    private java.lang.String name;

    private com.sforce.soap.enterprise.QueryResult notes;

    private com.sforce.soap.enterprise.QueryResult notesAndAttachments;

    private com.sforce.soap.enterprise.QueryResult opportunityProduct__r;

    private com.sforce.soap.enterprise.sobject.Name owner;

    private java.lang.String ownerId;

    private com.sforce.soap.enterprise.QueryResult processInstances;

    private com.sforce.soap.enterprise.QueryResult processSteps;

    private java.lang.String province__c;

    private java.util.Calendar systemModstamp;

    private com.sforce.soap.enterprise.QueryResult contractAPSearchHelp__r;

    public City__c() {
    }

    public City__c(
           java.lang.String[] fieldsToNull,
           java.lang.String id,
           java.lang.String abbBusiness__c,
           java.lang.String abbExternal__c,
           com.sforce.soap.enterprise.QueryResult accountCity__r,
           com.sforce.soap.enterprise.QueryResult attachments,
           java.lang.String cityID__c,
           java.lang.String cityPinyin__c,
           com.sforce.soap.enterprise.QueryResult city__r,
           com.sforce.soap.enterprise.QueryResult contractCity__r,
           com.sforce.soap.enterprise.QueryResult contract_City__r,
           com.sforce.soap.enterprise.sobject.User createdBy,
           java.lang.String createdById,
           java.util.Calendar createdDate,
           com.sforce.soap.enterprise.QueryResult discountRule__r,
           com.sforce.soap.enterprise.QueryResult employee__r,
           com.sforce.soap.enterprise.QueryResult freeProductRule__r,
           java.lang.Boolean isBulkBuyCity__c,
           java.lang.Boolean isBusinessCity__c,
           java.lang.Boolean isDeleted,
           com.sforce.soap.enterprise.sobject.User lastModifiedBy,
           java.lang.String lastModifiedById,
           java.util.Calendar lastModifiedDate,
           java.lang.String name,
           com.sforce.soap.enterprise.QueryResult notes,
           com.sforce.soap.enterprise.QueryResult notesAndAttachments,
           com.sforce.soap.enterprise.QueryResult opportunityProduct__r,
           com.sforce.soap.enterprise.sobject.Name owner,
           java.lang.String ownerId,
           com.sforce.soap.enterprise.QueryResult processInstances,
           com.sforce.soap.enterprise.QueryResult processSteps,
           java.lang.String province__c,
           java.util.Calendar systemModstamp,
           com.sforce.soap.enterprise.QueryResult contractAPSearchHelp__r) {
        super(
            fieldsToNull,
            id);
        this.abbBusiness__c = abbBusiness__c;
        this.abbExternal__c = abbExternal__c;
        this.accountCity__r = accountCity__r;
        this.attachments = attachments;
        this.cityID__c = cityID__c;
        this.cityPinyin__c = cityPinyin__c;
        this.city__r = city__r;
        this.contractCity__r = contractCity__r;
        this.contract_City__r = contract_City__r;
        this.createdBy = createdBy;
        this.createdById = createdById;
        this.createdDate = createdDate;
        this.discountRule__r = discountRule__r;
        this.employee__r = employee__r;
        this.freeProductRule__r = freeProductRule__r;
        this.isBulkBuyCity__c = isBulkBuyCity__c;
        this.isBusinessCity__c = isBusinessCity__c;
        this.isDeleted = isDeleted;
        this.lastModifiedBy = lastModifiedBy;
        this.lastModifiedById = lastModifiedById;
        this.lastModifiedDate = lastModifiedDate;
        this.name = name;
        this.notes = notes;
        this.notesAndAttachments = notesAndAttachments;
        this.opportunityProduct__r = opportunityProduct__r;
        this.owner = owner;
        this.ownerId = ownerId;
        this.processInstances = processInstances;
        this.processSteps = processSteps;
        this.province__c = province__c;
        this.systemModstamp = systemModstamp;
        this.contractAPSearchHelp__r = contractAPSearchHelp__r;
    }


    /**
     * Gets the abbBusiness__c value for this City__c.
     * 
     * @return abbBusiness__c
     */
    public java.lang.String getAbbBusiness__c() {
        return abbBusiness__c;
    }


    /**
     * Sets the abbBusiness__c value for this City__c.
     * 
     * @param abbBusiness__c
     */
    public void setAbbBusiness__c(java.lang.String abbBusiness__c) {
        this.abbBusiness__c = abbBusiness__c;
    }


    /**
     * Gets the abbExternal__c value for this City__c.
     * 
     * @return abbExternal__c
     */
    public java.lang.String getAbbExternal__c() {
        return abbExternal__c;
    }


    /**
     * Sets the abbExternal__c value for this City__c.
     * 
     * @param abbExternal__c
     */
    public void setAbbExternal__c(java.lang.String abbExternal__c) {
        this.abbExternal__c = abbExternal__c;
    }


    /**
     * Gets the accountCity__r value for this City__c.
     * 
     * @return accountCity__r
     */
    public com.sforce.soap.enterprise.QueryResult getAccountCity__r() {
        return accountCity__r;
    }


    /**
     * Sets the accountCity__r value for this City__c.
     * 
     * @param accountCity__r
     */
    public void setAccountCity__r(com.sforce.soap.enterprise.QueryResult accountCity__r) {
        this.accountCity__r = accountCity__r;
    }


    /**
     * Gets the attachments value for this City__c.
     * 
     * @return attachments
     */
    public com.sforce.soap.enterprise.QueryResult getAttachments() {
        return attachments;
    }


    /**
     * Sets the attachments value for this City__c.
     * 
     * @param attachments
     */
    public void setAttachments(com.sforce.soap.enterprise.QueryResult attachments) {
        this.attachments = attachments;
    }


    /**
     * Gets the cityID__c value for this City__c.
     * 
     * @return cityID__c
     */
    public java.lang.String getCityID__c() {
        return cityID__c;
    }


    /**
     * Sets the cityID__c value for this City__c.
     * 
     * @param cityID__c
     */
    public void setCityID__c(java.lang.String cityID__c) {
        this.cityID__c = cityID__c;
    }


    /**
     * Gets the cityPinyin__c value for this City__c.
     * 
     * @return cityPinyin__c
     */
    public java.lang.String getCityPinyin__c() {
        return cityPinyin__c;
    }


    /**
     * Sets the cityPinyin__c value for this City__c.
     * 
     * @param cityPinyin__c
     */
    public void setCityPinyin__c(java.lang.String cityPinyin__c) {
        this.cityPinyin__c = cityPinyin__c;
    }


    /**
     * Gets the city__r value for this City__c.
     * 
     * @return city__r
     */
    public com.sforce.soap.enterprise.QueryResult getCity__r() {
        return city__r;
    }


    /**
     * Sets the city__r value for this City__c.
     * 
     * @param city__r
     */
    public void setCity__r(com.sforce.soap.enterprise.QueryResult city__r) {
        this.city__r = city__r;
    }


    /**
     * Gets the contractCity__r value for this City__c.
     * 
     * @return contractCity__r
     */
    public com.sforce.soap.enterprise.QueryResult getContractCity__r() {
        return contractCity__r;
    }


    /**
     * Sets the contractCity__r value for this City__c.
     * 
     * @param contractCity__r
     */
    public void setContractCity__r(com.sforce.soap.enterprise.QueryResult contractCity__r) {
        this.contractCity__r = contractCity__r;
    }


    /**
     * Gets the contract_City__r value for this City__c.
     * 
     * @return contract_City__r
     */
    public com.sforce.soap.enterprise.QueryResult getContract_City__r() {
        return contract_City__r;
    }


    /**
     * Sets the contract_City__r value for this City__c.
     * 
     * @param contract_City__r
     */
    public void setContract_City__r(com.sforce.soap.enterprise.QueryResult contract_City__r) {
        this.contract_City__r = contract_City__r;
    }


    /**
     * Gets the createdBy value for this City__c.
     * 
     * @return createdBy
     */
    public com.sforce.soap.enterprise.sobject.User getCreatedBy() {
        return createdBy;
    }


    /**
     * Sets the createdBy value for this City__c.
     * 
     * @param createdBy
     */
    public void setCreatedBy(com.sforce.soap.enterprise.sobject.User createdBy) {
        this.createdBy = createdBy;
    }


    /**
     * Gets the createdById value for this City__c.
     * 
     * @return createdById
     */
    public java.lang.String getCreatedById() {
        return createdById;
    }


    /**
     * Sets the createdById value for this City__c.
     * 
     * @param createdById
     */
    public void setCreatedById(java.lang.String createdById) {
        this.createdById = createdById;
    }


    /**
     * Gets the createdDate value for this City__c.
     * 
     * @return createdDate
     */
    public java.util.Calendar getCreatedDate() {
        return createdDate;
    }


    /**
     * Sets the createdDate value for this City__c.
     * 
     * @param createdDate
     */
    public void setCreatedDate(java.util.Calendar createdDate) {
        this.createdDate = createdDate;
    }


    /**
     * Gets the discountRule__r value for this City__c.
     * 
     * @return discountRule__r
     */
    public com.sforce.soap.enterprise.QueryResult getDiscountRule__r() {
        return discountRule__r;
    }


    /**
     * Sets the discountRule__r value for this City__c.
     * 
     * @param discountRule__r
     */
    public void setDiscountRule__r(com.sforce.soap.enterprise.QueryResult discountRule__r) {
        this.discountRule__r = discountRule__r;
    }


    /**
     * Gets the employee__r value for this City__c.
     * 
     * @return employee__r
     */
    public com.sforce.soap.enterprise.QueryResult getEmployee__r() {
        return employee__r;
    }


    /**
     * Sets the employee__r value for this City__c.
     * 
     * @param employee__r
     */
    public void setEmployee__r(com.sforce.soap.enterprise.QueryResult employee__r) {
        this.employee__r = employee__r;
    }


    /**
     * Gets the freeProductRule__r value for this City__c.
     * 
     * @return freeProductRule__r
     */
    public com.sforce.soap.enterprise.QueryResult getFreeProductRule__r() {
        return freeProductRule__r;
    }


    /**
     * Sets the freeProductRule__r value for this City__c.
     * 
     * @param freeProductRule__r
     */
    public void setFreeProductRule__r(com.sforce.soap.enterprise.QueryResult freeProductRule__r) {
        this.freeProductRule__r = freeProductRule__r;
    }


    /**
     * Gets the isBulkBuyCity__c value for this City__c.
     * 
     * @return isBulkBuyCity__c
     */
    public java.lang.Boolean getIsBulkBuyCity__c() {
        return isBulkBuyCity__c;
    }


    /**
     * Sets the isBulkBuyCity__c value for this City__c.
     * 
     * @param isBulkBuyCity__c
     */
    public void setIsBulkBuyCity__c(java.lang.Boolean isBulkBuyCity__c) {
        this.isBulkBuyCity__c = isBulkBuyCity__c;
    }


    /**
     * Gets the isBusinessCity__c value for this City__c.
     * 
     * @return isBusinessCity__c
     */
    public java.lang.Boolean getIsBusinessCity__c() {
        return isBusinessCity__c;
    }


    /**
     * Sets the isBusinessCity__c value for this City__c.
     * 
     * @param isBusinessCity__c
     */
    public void setIsBusinessCity__c(java.lang.Boolean isBusinessCity__c) {
        this.isBusinessCity__c = isBusinessCity__c;
    }


    /**
     * Gets the isDeleted value for this City__c.
     * 
     * @return isDeleted
     */
    public java.lang.Boolean getIsDeleted() {
        return isDeleted;
    }


    /**
     * Sets the isDeleted value for this City__c.
     * 
     * @param isDeleted
     */
    public void setIsDeleted(java.lang.Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }


    /**
     * Gets the lastModifiedBy value for this City__c.
     * 
     * @return lastModifiedBy
     */
    public com.sforce.soap.enterprise.sobject.User getLastModifiedBy() {
        return lastModifiedBy;
    }


    /**
     * Sets the lastModifiedBy value for this City__c.
     * 
     * @param lastModifiedBy
     */
    public void setLastModifiedBy(com.sforce.soap.enterprise.sobject.User lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }


    /**
     * Gets the lastModifiedById value for this City__c.
     * 
     * @return lastModifiedById
     */
    public java.lang.String getLastModifiedById() {
        return lastModifiedById;
    }


    /**
     * Sets the lastModifiedById value for this City__c.
     * 
     * @param lastModifiedById
     */
    public void setLastModifiedById(java.lang.String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }


    /**
     * Gets the lastModifiedDate value for this City__c.
     * 
     * @return lastModifiedDate
     */
    public java.util.Calendar getLastModifiedDate() {
        return lastModifiedDate;
    }


    /**
     * Sets the lastModifiedDate value for this City__c.
     * 
     * @param lastModifiedDate
     */
    public void setLastModifiedDate(java.util.Calendar lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }


    /**
     * Gets the name value for this City__c.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this City__c.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the notes value for this City__c.
     * 
     * @return notes
     */
    public com.sforce.soap.enterprise.QueryResult getNotes() {
        return notes;
    }


    /**
     * Sets the notes value for this City__c.
     * 
     * @param notes
     */
    public void setNotes(com.sforce.soap.enterprise.QueryResult notes) {
        this.notes = notes;
    }


    /**
     * Gets the notesAndAttachments value for this City__c.
     * 
     * @return notesAndAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getNotesAndAttachments() {
        return notesAndAttachments;
    }


    /**
     * Sets the notesAndAttachments value for this City__c.
     * 
     * @param notesAndAttachments
     */
    public void setNotesAndAttachments(com.sforce.soap.enterprise.QueryResult notesAndAttachments) {
        this.notesAndAttachments = notesAndAttachments;
    }


    /**
     * Gets the opportunityProduct__r value for this City__c.
     * 
     * @return opportunityProduct__r
     */
    public com.sforce.soap.enterprise.QueryResult getOpportunityProduct__r() {
        return opportunityProduct__r;
    }


    /**
     * Sets the opportunityProduct__r value for this City__c.
     * 
     * @param opportunityProduct__r
     */
    public void setOpportunityProduct__r(com.sforce.soap.enterprise.QueryResult opportunityProduct__r) {
        this.opportunityProduct__r = opportunityProduct__r;
    }


    /**
     * Gets the owner value for this City__c.
     * 
     * @return owner
     */
    public com.sforce.soap.enterprise.sobject.Name getOwner() {
        return owner;
    }


    /**
     * Sets the owner value for this City__c.
     * 
     * @param owner
     */
    public void setOwner(com.sforce.soap.enterprise.sobject.Name owner) {
        this.owner = owner;
    }


    /**
     * Gets the ownerId value for this City__c.
     * 
     * @return ownerId
     */
    public java.lang.String getOwnerId() {
        return ownerId;
    }


    /**
     * Sets the ownerId value for this City__c.
     * 
     * @param ownerId
     */
    public void setOwnerId(java.lang.String ownerId) {
        this.ownerId = ownerId;
    }


    /**
     * Gets the processInstances value for this City__c.
     * 
     * @return processInstances
     */
    public com.sforce.soap.enterprise.QueryResult getProcessInstances() {
        return processInstances;
    }


    /**
     * Sets the processInstances value for this City__c.
     * 
     * @param processInstances
     */
    public void setProcessInstances(com.sforce.soap.enterprise.QueryResult processInstances) {
        this.processInstances = processInstances;
    }


    /**
     * Gets the processSteps value for this City__c.
     * 
     * @return processSteps
     */
    public com.sforce.soap.enterprise.QueryResult getProcessSteps() {
        return processSteps;
    }


    /**
     * Sets the processSteps value for this City__c.
     * 
     * @param processSteps
     */
    public void setProcessSteps(com.sforce.soap.enterprise.QueryResult processSteps) {
        this.processSteps = processSteps;
    }


    /**
     * Gets the province__c value for this City__c.
     * 
     * @return province__c
     */
    public java.lang.String getProvince__c() {
        return province__c;
    }


    /**
     * Sets the province__c value for this City__c.
     * 
     * @param province__c
     */
    public void setProvince__c(java.lang.String province__c) {
        this.province__c = province__c;
    }


    /**
     * Gets the systemModstamp value for this City__c.
     * 
     * @return systemModstamp
     */
    public java.util.Calendar getSystemModstamp() {
        return systemModstamp;
    }


    /**
     * Sets the systemModstamp value for this City__c.
     * 
     * @param systemModstamp
     */
    public void setSystemModstamp(java.util.Calendar systemModstamp) {
        this.systemModstamp = systemModstamp;
    }


    /**
     * Gets the contractAPSearchHelp__r value for this City__c.
     * 
     * @return contractAPSearchHelp__r
     */
    public com.sforce.soap.enterprise.QueryResult getContractAPSearchHelp__r() {
        return contractAPSearchHelp__r;
    }


    /**
     * Sets the contractAPSearchHelp__r value for this City__c.
     * 
     * @param contractAPSearchHelp__r
     */
    public void setContractAPSearchHelp__r(com.sforce.soap.enterprise.QueryResult contractAPSearchHelp__r) {
        this.contractAPSearchHelp__r = contractAPSearchHelp__r;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof City__c)) return false;
        City__c other = (City__c) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.abbBusiness__c==null && other.getAbbBusiness__c()==null) || 
             (this.abbBusiness__c!=null &&
              this.abbBusiness__c.equals(other.getAbbBusiness__c()))) &&
            ((this.abbExternal__c==null && other.getAbbExternal__c()==null) || 
             (this.abbExternal__c!=null &&
              this.abbExternal__c.equals(other.getAbbExternal__c()))) &&
            ((this.accountCity__r==null && other.getAccountCity__r()==null) || 
             (this.accountCity__r!=null &&
              this.accountCity__r.equals(other.getAccountCity__r()))) &&
            ((this.attachments==null && other.getAttachments()==null) || 
             (this.attachments!=null &&
              this.attachments.equals(other.getAttachments()))) &&
            ((this.cityID__c==null && other.getCityID__c()==null) || 
             (this.cityID__c!=null &&
              this.cityID__c.equals(other.getCityID__c()))) &&
            ((this.cityPinyin__c==null && other.getCityPinyin__c()==null) || 
             (this.cityPinyin__c!=null &&
              this.cityPinyin__c.equals(other.getCityPinyin__c()))) &&
            ((this.city__r==null && other.getCity__r()==null) || 
             (this.city__r!=null &&
              this.city__r.equals(other.getCity__r()))) &&
            ((this.contractCity__r==null && other.getContractCity__r()==null) || 
             (this.contractCity__r!=null &&
              this.contractCity__r.equals(other.getContractCity__r()))) &&
            ((this.contract_City__r==null && other.getContract_City__r()==null) || 
             (this.contract_City__r!=null &&
              this.contract_City__r.equals(other.getContract_City__r()))) &&
            ((this.createdBy==null && other.getCreatedBy()==null) || 
             (this.createdBy!=null &&
              this.createdBy.equals(other.getCreatedBy()))) &&
            ((this.createdById==null && other.getCreatedById()==null) || 
             (this.createdById!=null &&
              this.createdById.equals(other.getCreatedById()))) &&
            ((this.createdDate==null && other.getCreatedDate()==null) || 
             (this.createdDate!=null &&
              this.createdDate.equals(other.getCreatedDate()))) &&
            ((this.discountRule__r==null && other.getDiscountRule__r()==null) || 
             (this.discountRule__r!=null &&
              this.discountRule__r.equals(other.getDiscountRule__r()))) &&
            ((this.employee__r==null && other.getEmployee__r()==null) || 
             (this.employee__r!=null &&
              this.employee__r.equals(other.getEmployee__r()))) &&
            ((this.freeProductRule__r==null && other.getFreeProductRule__r()==null) || 
             (this.freeProductRule__r!=null &&
              this.freeProductRule__r.equals(other.getFreeProductRule__r()))) &&
            ((this.isBulkBuyCity__c==null && other.getIsBulkBuyCity__c()==null) || 
             (this.isBulkBuyCity__c!=null &&
              this.isBulkBuyCity__c.equals(other.getIsBulkBuyCity__c()))) &&
            ((this.isBusinessCity__c==null && other.getIsBusinessCity__c()==null) || 
             (this.isBusinessCity__c!=null &&
              this.isBusinessCity__c.equals(other.getIsBusinessCity__c()))) &&
            ((this.isDeleted==null && other.getIsDeleted()==null) || 
             (this.isDeleted!=null &&
              this.isDeleted.equals(other.getIsDeleted()))) &&
            ((this.lastModifiedBy==null && other.getLastModifiedBy()==null) || 
             (this.lastModifiedBy!=null &&
              this.lastModifiedBy.equals(other.getLastModifiedBy()))) &&
            ((this.lastModifiedById==null && other.getLastModifiedById()==null) || 
             (this.lastModifiedById!=null &&
              this.lastModifiedById.equals(other.getLastModifiedById()))) &&
            ((this.lastModifiedDate==null && other.getLastModifiedDate()==null) || 
             (this.lastModifiedDate!=null &&
              this.lastModifiedDate.equals(other.getLastModifiedDate()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.notes==null && other.getNotes()==null) || 
             (this.notes!=null &&
              this.notes.equals(other.getNotes()))) &&
            ((this.notesAndAttachments==null && other.getNotesAndAttachments()==null) || 
             (this.notesAndAttachments!=null &&
              this.notesAndAttachments.equals(other.getNotesAndAttachments()))) &&
            ((this.opportunityProduct__r==null && other.getOpportunityProduct__r()==null) || 
             (this.opportunityProduct__r!=null &&
              this.opportunityProduct__r.equals(other.getOpportunityProduct__r()))) &&
            ((this.owner==null && other.getOwner()==null) || 
             (this.owner!=null &&
              this.owner.equals(other.getOwner()))) &&
            ((this.ownerId==null && other.getOwnerId()==null) || 
             (this.ownerId!=null &&
              this.ownerId.equals(other.getOwnerId()))) &&
            ((this.processInstances==null && other.getProcessInstances()==null) || 
             (this.processInstances!=null &&
              this.processInstances.equals(other.getProcessInstances()))) &&
            ((this.processSteps==null && other.getProcessSteps()==null) || 
             (this.processSteps!=null &&
              this.processSteps.equals(other.getProcessSteps()))) &&
            ((this.province__c==null && other.getProvince__c()==null) || 
             (this.province__c!=null &&
              this.province__c.equals(other.getProvince__c()))) &&
            ((this.systemModstamp==null && other.getSystemModstamp()==null) || 
             (this.systemModstamp!=null &&
              this.systemModstamp.equals(other.getSystemModstamp()))) &&
            ((this.contractAPSearchHelp__r==null && other.getContractAPSearchHelp__r()==null) || 
             (this.contractAPSearchHelp__r!=null &&
              this.contractAPSearchHelp__r.equals(other.getContractAPSearchHelp__r())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAbbBusiness__c() != null) {
            _hashCode += getAbbBusiness__c().hashCode();
        }
        if (getAbbExternal__c() != null) {
            _hashCode += getAbbExternal__c().hashCode();
        }
        if (getAccountCity__r() != null) {
            _hashCode += getAccountCity__r().hashCode();
        }
        if (getAttachments() != null) {
            _hashCode += getAttachments().hashCode();
        }
        if (getCityID__c() != null) {
            _hashCode += getCityID__c().hashCode();
        }
        if (getCityPinyin__c() != null) {
            _hashCode += getCityPinyin__c().hashCode();
        }
        if (getCity__r() != null) {
            _hashCode += getCity__r().hashCode();
        }
        if (getContractCity__r() != null) {
            _hashCode += getContractCity__r().hashCode();
        }
        if (getContract_City__r() != null) {
            _hashCode += getContract_City__r().hashCode();
        }
        if (getCreatedBy() != null) {
            _hashCode += getCreatedBy().hashCode();
        }
        if (getCreatedById() != null) {
            _hashCode += getCreatedById().hashCode();
        }
        if (getCreatedDate() != null) {
            _hashCode += getCreatedDate().hashCode();
        }
        if (getDiscountRule__r() != null) {
            _hashCode += getDiscountRule__r().hashCode();
        }
        if (getEmployee__r() != null) {
            _hashCode += getEmployee__r().hashCode();
        }
        if (getFreeProductRule__r() != null) {
            _hashCode += getFreeProductRule__r().hashCode();
        }
        if (getIsBulkBuyCity__c() != null) {
            _hashCode += getIsBulkBuyCity__c().hashCode();
        }
        if (getIsBusinessCity__c() != null) {
            _hashCode += getIsBusinessCity__c().hashCode();
        }
        if (getIsDeleted() != null) {
            _hashCode += getIsDeleted().hashCode();
        }
        if (getLastModifiedBy() != null) {
            _hashCode += getLastModifiedBy().hashCode();
        }
        if (getLastModifiedById() != null) {
            _hashCode += getLastModifiedById().hashCode();
        }
        if (getLastModifiedDate() != null) {
            _hashCode += getLastModifiedDate().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getNotes() != null) {
            _hashCode += getNotes().hashCode();
        }
        if (getNotesAndAttachments() != null) {
            _hashCode += getNotesAndAttachments().hashCode();
        }
        if (getOpportunityProduct__r() != null) {
            _hashCode += getOpportunityProduct__r().hashCode();
        }
        if (getOwner() != null) {
            _hashCode += getOwner().hashCode();
        }
        if (getOwnerId() != null) {
            _hashCode += getOwnerId().hashCode();
        }
        if (getProcessInstances() != null) {
            _hashCode += getProcessInstances().hashCode();
        }
        if (getProcessSteps() != null) {
            _hashCode += getProcessSteps().hashCode();
        }
        if (getProvince__c() != null) {
            _hashCode += getProvince__c().hashCode();
        }
        if (getSystemModstamp() != null) {
            _hashCode += getSystemModstamp().hashCode();
        }
        if (getContractAPSearchHelp__r() != null) {
            _hashCode += getContractAPSearchHelp__r().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(City__c.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "City__c"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("abbBusiness__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AbbBusiness__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("abbExternal__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AbbExternal__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accountCity__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AccountCity__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Attachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cityID__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CityID__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cityPinyin__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CityPinyin__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("city__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "City__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contractCity__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ContractCity__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contract_City__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Contract_City__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("discountRule__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DiscountRule__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("employee__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Employee__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("freeProductRule__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "FreeProductRule__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isBulkBuyCity__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsBulkBuyCity__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isBusinessCity__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsBusinessCity__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isDeleted");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsDeleted"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notes");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Notes"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notesAndAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NotesAndAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("opportunityProduct__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OpportunityProduct__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("owner");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Owner"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ownerId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OwnerId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processInstances");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessInstances"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processSteps");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessSteps"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("province__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Province__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("systemModstamp");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SystemModstamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contractAPSearchHelp__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "contractAPSearchHelp__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
