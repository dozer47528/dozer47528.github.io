/**
 * OpportunityLineItem.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.sforce.soap.enterprise.sobject;

public class OpportunityLineItem  extends com.sforce.soap.enterprise.sobject.SObject  implements java.io.Serializable {
    private java.lang.String channel__c;

    private java.lang.String city__c;

    private com.sforce.soap.enterprise.sobject.City__c city__r;

    private com.sforce.soap.enterprise.sobject.User createdBy;

    private java.lang.String createdById;

    private java.util.Calendar createdDate;

    private java.lang.String description;

    private java.lang.Double discount;

    private java.lang.String editStatus__c;

    private java.util.Date endDate__c;

    private java.lang.Boolean freeOptyProduct__c;

    private java.lang.String infoGood__c;

    private java.lang.String inventoryOperationResult__c;

    private java.lang.String inventoryStatus__c;

    private java.lang.Boolean isBrandAD__c;

    private java.lang.String isBrandAdProduct__c;

    private java.lang.Boolean isDeleted;

    private java.lang.Boolean isInfoGood__c;

    private java.lang.String keyWord__c;

    private java.lang.Double LTTotalListPrice__c;

    private com.sforce.soap.enterprise.sobject.User lastModifiedBy;

    private java.lang.String lastModifiedById;

    private java.util.Calendar lastModifiedDate;

    private java.lang.Double listPrice;

    private com.sforce.soap.enterprise.sobject.Opportunity opportunity;

    private java.lang.String opportunityId;

    private com.sforce.soap.enterprise.sobject.PricebookEntry pricebookEntry;

    private java.lang.String pricebookEntryId;

    private java.lang.Double quantity;

    private java.util.Date serviceDate;

    private java.lang.String shopAccount__c;

    private com.sforce.soap.enterprise.sobject.Account shopAccount__r;

    private java.lang.String showChannel__c;

    private java.lang.String showKeyWord__c;

    private java.lang.String showShopAccount__c;

    private java.lang.String showSysCrossShopSearch__c;

    private java.lang.String showSysInventory__c;

    private java.lang.Integer sortOrder;

    private java.util.Date startDate__c;

    private java.lang.Double subtotal;

    private java.util.Calendar systemModstamp;

    private java.lang.Double totalPrice;

    private java.lang.Double unitPrice;

    private java.lang.String isProductRPAppCalc__c;

    private java.lang.Boolean isProductRPApp__c;

    public OpportunityLineItem() {
    }

    public OpportunityLineItem(
           java.lang.String[] fieldsToNull,
           java.lang.String id,
           java.lang.String channel__c,
           java.lang.String city__c,
           com.sforce.soap.enterprise.sobject.City__c city__r,
           com.sforce.soap.enterprise.sobject.User createdBy,
           java.lang.String createdById,
           java.util.Calendar createdDate,
           java.lang.String description,
           java.lang.Double discount,
           java.lang.String editStatus__c,
           java.util.Date endDate__c,
           java.lang.Boolean freeOptyProduct__c,
           java.lang.String infoGood__c,
           java.lang.String inventoryOperationResult__c,
           java.lang.String inventoryStatus__c,
           java.lang.Boolean isBrandAD__c,
           java.lang.String isBrandAdProduct__c,
           java.lang.Boolean isDeleted,
           java.lang.Boolean isInfoGood__c,
           java.lang.String keyWord__c,
           java.lang.Double LTTotalListPrice__c,
           com.sforce.soap.enterprise.sobject.User lastModifiedBy,
           java.lang.String lastModifiedById,
           java.util.Calendar lastModifiedDate,
           java.lang.Double listPrice,
           com.sforce.soap.enterprise.sobject.Opportunity opportunity,
           java.lang.String opportunityId,
           com.sforce.soap.enterprise.sobject.PricebookEntry pricebookEntry,
           java.lang.String pricebookEntryId,
           java.lang.Double quantity,
           java.util.Date serviceDate,
           java.lang.String shopAccount__c,
           com.sforce.soap.enterprise.sobject.Account shopAccount__r,
           java.lang.String showChannel__c,
           java.lang.String showKeyWord__c,
           java.lang.String showShopAccount__c,
           java.lang.String showSysCrossShopSearch__c,
           java.lang.String showSysInventory__c,
           java.lang.Integer sortOrder,
           java.util.Date startDate__c,
           java.lang.Double subtotal,
           java.util.Calendar systemModstamp,
           java.lang.Double totalPrice,
           java.lang.Double unitPrice,
           java.lang.String isProductRPAppCalc__c,
           java.lang.Boolean isProductRPApp__c) {
        super(
            fieldsToNull,
            id);
        this.channel__c = channel__c;
        this.city__c = city__c;
        this.city__r = city__r;
        this.createdBy = createdBy;
        this.createdById = createdById;
        this.createdDate = createdDate;
        this.description = description;
        this.discount = discount;
        this.editStatus__c = editStatus__c;
        this.endDate__c = endDate__c;
        this.freeOptyProduct__c = freeOptyProduct__c;
        this.infoGood__c = infoGood__c;
        this.inventoryOperationResult__c = inventoryOperationResult__c;
        this.inventoryStatus__c = inventoryStatus__c;
        this.isBrandAD__c = isBrandAD__c;
        this.isBrandAdProduct__c = isBrandAdProduct__c;
        this.isDeleted = isDeleted;
        this.isInfoGood__c = isInfoGood__c;
        this.keyWord__c = keyWord__c;
        this.LTTotalListPrice__c = LTTotalListPrice__c;
        this.lastModifiedBy = lastModifiedBy;
        this.lastModifiedById = lastModifiedById;
        this.lastModifiedDate = lastModifiedDate;
        this.listPrice = listPrice;
        this.opportunity = opportunity;
        this.opportunityId = opportunityId;
        this.pricebookEntry = pricebookEntry;
        this.pricebookEntryId = pricebookEntryId;
        this.quantity = quantity;
        this.serviceDate = serviceDate;
        this.shopAccount__c = shopAccount__c;
        this.shopAccount__r = shopAccount__r;
        this.showChannel__c = showChannel__c;
        this.showKeyWord__c = showKeyWord__c;
        this.showShopAccount__c = showShopAccount__c;
        this.showSysCrossShopSearch__c = showSysCrossShopSearch__c;
        this.showSysInventory__c = showSysInventory__c;
        this.sortOrder = sortOrder;
        this.startDate__c = startDate__c;
        this.subtotal = subtotal;
        this.systemModstamp = systemModstamp;
        this.totalPrice = totalPrice;
        this.unitPrice = unitPrice;
        this.isProductRPAppCalc__c = isProductRPAppCalc__c;
        this.isProductRPApp__c = isProductRPApp__c;
    }


    /**
     * Gets the channel__c value for this OpportunityLineItem.
     * 
     * @return channel__c
     */
    public java.lang.String getChannel__c() {
        return channel__c;
    }


    /**
     * Sets the channel__c value for this OpportunityLineItem.
     * 
     * @param channel__c
     */
    public void setChannel__c(java.lang.String channel__c) {
        this.channel__c = channel__c;
    }


    /**
     * Gets the city__c value for this OpportunityLineItem.
     * 
     * @return city__c
     */
    public java.lang.String getCity__c() {
        return city__c;
    }


    /**
     * Sets the city__c value for this OpportunityLineItem.
     * 
     * @param city__c
     */
    public void setCity__c(java.lang.String city__c) {
        this.city__c = city__c;
    }


    /**
     * Gets the city__r value for this OpportunityLineItem.
     * 
     * @return city__r
     */
    public com.sforce.soap.enterprise.sobject.City__c getCity__r() {
        return city__r;
    }


    /**
     * Sets the city__r value for this OpportunityLineItem.
     * 
     * @param city__r
     */
    public void setCity__r(com.sforce.soap.enterprise.sobject.City__c city__r) {
        this.city__r = city__r;
    }


    /**
     * Gets the createdBy value for this OpportunityLineItem.
     * 
     * @return createdBy
     */
    public com.sforce.soap.enterprise.sobject.User getCreatedBy() {
        return createdBy;
    }


    /**
     * Sets the createdBy value for this OpportunityLineItem.
     * 
     * @param createdBy
     */
    public void setCreatedBy(com.sforce.soap.enterprise.sobject.User createdBy) {
        this.createdBy = createdBy;
    }


    /**
     * Gets the createdById value for this OpportunityLineItem.
     * 
     * @return createdById
     */
    public java.lang.String getCreatedById() {
        return createdById;
    }


    /**
     * Sets the createdById value for this OpportunityLineItem.
     * 
     * @param createdById
     */
    public void setCreatedById(java.lang.String createdById) {
        this.createdById = createdById;
    }


    /**
     * Gets the createdDate value for this OpportunityLineItem.
     * 
     * @return createdDate
     */
    public java.util.Calendar getCreatedDate() {
        return createdDate;
    }


    /**
     * Sets the createdDate value for this OpportunityLineItem.
     * 
     * @param createdDate
     */
    public void setCreatedDate(java.util.Calendar createdDate) {
        this.createdDate = createdDate;
    }


    /**
     * Gets the description value for this OpportunityLineItem.
     * 
     * @return description
     */
    public java.lang.String getDescription() {
        return description;
    }


    /**
     * Sets the description value for this OpportunityLineItem.
     * 
     * @param description
     */
    public void setDescription(java.lang.String description) {
        this.description = description;
    }


    /**
     * Gets the discount value for this OpportunityLineItem.
     * 
     * @return discount
     */
    public java.lang.Double getDiscount() {
        return discount;
    }


    /**
     * Sets the discount value for this OpportunityLineItem.
     * 
     * @param discount
     */
    public void setDiscount(java.lang.Double discount) {
        this.discount = discount;
    }


    /**
     * Gets the editStatus__c value for this OpportunityLineItem.
     * 
     * @return editStatus__c
     */
    public java.lang.String getEditStatus__c() {
        return editStatus__c;
    }


    /**
     * Sets the editStatus__c value for this OpportunityLineItem.
     * 
     * @param editStatus__c
     */
    public void setEditStatus__c(java.lang.String editStatus__c) {
        this.editStatus__c = editStatus__c;
    }


    /**
     * Gets the endDate__c value for this OpportunityLineItem.
     * 
     * @return endDate__c
     */
    public java.util.Date getEndDate__c() {
        return endDate__c;
    }


    /**
     * Sets the endDate__c value for this OpportunityLineItem.
     * 
     * @param endDate__c
     */
    public void setEndDate__c(java.util.Date endDate__c) {
        this.endDate__c = endDate__c;
    }


    /**
     * Gets the freeOptyProduct__c value for this OpportunityLineItem.
     * 
     * @return freeOptyProduct__c
     */
    public java.lang.Boolean getFreeOptyProduct__c() {
        return freeOptyProduct__c;
    }


    /**
     * Sets the freeOptyProduct__c value for this OpportunityLineItem.
     * 
     * @param freeOptyProduct__c
     */
    public void setFreeOptyProduct__c(java.lang.Boolean freeOptyProduct__c) {
        this.freeOptyProduct__c = freeOptyProduct__c;
    }


    /**
     * Gets the infoGood__c value for this OpportunityLineItem.
     * 
     * @return infoGood__c
     */
    public java.lang.String getInfoGood__c() {
        return infoGood__c;
    }


    /**
     * Sets the infoGood__c value for this OpportunityLineItem.
     * 
     * @param infoGood__c
     */
    public void setInfoGood__c(java.lang.String infoGood__c) {
        this.infoGood__c = infoGood__c;
    }


    /**
     * Gets the inventoryOperationResult__c value for this OpportunityLineItem.
     * 
     * @return inventoryOperationResult__c
     */
    public java.lang.String getInventoryOperationResult__c() {
        return inventoryOperationResult__c;
    }


    /**
     * Sets the inventoryOperationResult__c value for this OpportunityLineItem.
     * 
     * @param inventoryOperationResult__c
     */
    public void setInventoryOperationResult__c(java.lang.String inventoryOperationResult__c) {
        this.inventoryOperationResult__c = inventoryOperationResult__c;
    }


    /**
     * Gets the inventoryStatus__c value for this OpportunityLineItem.
     * 
     * @return inventoryStatus__c
     */
    public java.lang.String getInventoryStatus__c() {
        return inventoryStatus__c;
    }


    /**
     * Sets the inventoryStatus__c value for this OpportunityLineItem.
     * 
     * @param inventoryStatus__c
     */
    public void setInventoryStatus__c(java.lang.String inventoryStatus__c) {
        this.inventoryStatus__c = inventoryStatus__c;
    }


    /**
     * Gets the isBrandAD__c value for this OpportunityLineItem.
     * 
     * @return isBrandAD__c
     */
    public java.lang.Boolean getIsBrandAD__c() {
        return isBrandAD__c;
    }


    /**
     * Sets the isBrandAD__c value for this OpportunityLineItem.
     * 
     * @param isBrandAD__c
     */
    public void setIsBrandAD__c(java.lang.Boolean isBrandAD__c) {
        this.isBrandAD__c = isBrandAD__c;
    }


    /**
     * Gets the isBrandAdProduct__c value for this OpportunityLineItem.
     * 
     * @return isBrandAdProduct__c
     */
    public java.lang.String getIsBrandAdProduct__c() {
        return isBrandAdProduct__c;
    }


    /**
     * Sets the isBrandAdProduct__c value for this OpportunityLineItem.
     * 
     * @param isBrandAdProduct__c
     */
    public void setIsBrandAdProduct__c(java.lang.String isBrandAdProduct__c) {
        this.isBrandAdProduct__c = isBrandAdProduct__c;
    }


    /**
     * Gets the isDeleted value for this OpportunityLineItem.
     * 
     * @return isDeleted
     */
    public java.lang.Boolean getIsDeleted() {
        return isDeleted;
    }


    /**
     * Sets the isDeleted value for this OpportunityLineItem.
     * 
     * @param isDeleted
     */
    public void setIsDeleted(java.lang.Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }


    /**
     * Gets the isInfoGood__c value for this OpportunityLineItem.
     * 
     * @return isInfoGood__c
     */
    public java.lang.Boolean getIsInfoGood__c() {
        return isInfoGood__c;
    }


    /**
     * Sets the isInfoGood__c value for this OpportunityLineItem.
     * 
     * @param isInfoGood__c
     */
    public void setIsInfoGood__c(java.lang.Boolean isInfoGood__c) {
        this.isInfoGood__c = isInfoGood__c;
    }


    /**
     * Gets the keyWord__c value for this OpportunityLineItem.
     * 
     * @return keyWord__c
     */
    public java.lang.String getKeyWord__c() {
        return keyWord__c;
    }


    /**
     * Sets the keyWord__c value for this OpportunityLineItem.
     * 
     * @param keyWord__c
     */
    public void setKeyWord__c(java.lang.String keyWord__c) {
        this.keyWord__c = keyWord__c;
    }


    /**
     * Gets the LTTotalListPrice__c value for this OpportunityLineItem.
     * 
     * @return LTTotalListPrice__c
     */
    public java.lang.Double getLTTotalListPrice__c() {
        return LTTotalListPrice__c;
    }


    /**
     * Sets the LTTotalListPrice__c value for this OpportunityLineItem.
     * 
     * @param LTTotalListPrice__c
     */
    public void setLTTotalListPrice__c(java.lang.Double LTTotalListPrice__c) {
        this.LTTotalListPrice__c = LTTotalListPrice__c;
    }


    /**
     * Gets the lastModifiedBy value for this OpportunityLineItem.
     * 
     * @return lastModifiedBy
     */
    public com.sforce.soap.enterprise.sobject.User getLastModifiedBy() {
        return lastModifiedBy;
    }


    /**
     * Sets the lastModifiedBy value for this OpportunityLineItem.
     * 
     * @param lastModifiedBy
     */
    public void setLastModifiedBy(com.sforce.soap.enterprise.sobject.User lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }


    /**
     * Gets the lastModifiedById value for this OpportunityLineItem.
     * 
     * @return lastModifiedById
     */
    public java.lang.String getLastModifiedById() {
        return lastModifiedById;
    }


    /**
     * Sets the lastModifiedById value for this OpportunityLineItem.
     * 
     * @param lastModifiedById
     */
    public void setLastModifiedById(java.lang.String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }


    /**
     * Gets the lastModifiedDate value for this OpportunityLineItem.
     * 
     * @return lastModifiedDate
     */
    public java.util.Calendar getLastModifiedDate() {
        return lastModifiedDate;
    }


    /**
     * Sets the lastModifiedDate value for this OpportunityLineItem.
     * 
     * @param lastModifiedDate
     */
    public void setLastModifiedDate(java.util.Calendar lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }


    /**
     * Gets the listPrice value for this OpportunityLineItem.
     * 
     * @return listPrice
     */
    public java.lang.Double getListPrice() {
        return listPrice;
    }


    /**
     * Sets the listPrice value for this OpportunityLineItem.
     * 
     * @param listPrice
     */
    public void setListPrice(java.lang.Double listPrice) {
        this.listPrice = listPrice;
    }


    /**
     * Gets the opportunity value for this OpportunityLineItem.
     * 
     * @return opportunity
     */
    public com.sforce.soap.enterprise.sobject.Opportunity getOpportunity() {
        return opportunity;
    }


    /**
     * Sets the opportunity value for this OpportunityLineItem.
     * 
     * @param opportunity
     */
    public void setOpportunity(com.sforce.soap.enterprise.sobject.Opportunity opportunity) {
        this.opportunity = opportunity;
    }


    /**
     * Gets the opportunityId value for this OpportunityLineItem.
     * 
     * @return opportunityId
     */
    public java.lang.String getOpportunityId() {
        return opportunityId;
    }


    /**
     * Sets the opportunityId value for this OpportunityLineItem.
     * 
     * @param opportunityId
     */
    public void setOpportunityId(java.lang.String opportunityId) {
        this.opportunityId = opportunityId;
    }


    /**
     * Gets the pricebookEntry value for this OpportunityLineItem.
     * 
     * @return pricebookEntry
     */
    public com.sforce.soap.enterprise.sobject.PricebookEntry getPricebookEntry() {
        return pricebookEntry;
    }


    /**
     * Sets the pricebookEntry value for this OpportunityLineItem.
     * 
     * @param pricebookEntry
     */
    public void setPricebookEntry(com.sforce.soap.enterprise.sobject.PricebookEntry pricebookEntry) {
        this.pricebookEntry = pricebookEntry;
    }


    /**
     * Gets the pricebookEntryId value for this OpportunityLineItem.
     * 
     * @return pricebookEntryId
     */
    public java.lang.String getPricebookEntryId() {
        return pricebookEntryId;
    }


    /**
     * Sets the pricebookEntryId value for this OpportunityLineItem.
     * 
     * @param pricebookEntryId
     */
    public void setPricebookEntryId(java.lang.String pricebookEntryId) {
        this.pricebookEntryId = pricebookEntryId;
    }


    /**
     * Gets the quantity value for this OpportunityLineItem.
     * 
     * @return quantity
     */
    public java.lang.Double getQuantity() {
        return quantity;
    }


    /**
     * Sets the quantity value for this OpportunityLineItem.
     * 
     * @param quantity
     */
    public void setQuantity(java.lang.Double quantity) {
        this.quantity = quantity;
    }


    /**
     * Gets the serviceDate value for this OpportunityLineItem.
     * 
     * @return serviceDate
     */
    public java.util.Date getServiceDate() {
        return serviceDate;
    }


    /**
     * Sets the serviceDate value for this OpportunityLineItem.
     * 
     * @param serviceDate
     */
    public void setServiceDate(java.util.Date serviceDate) {
        this.serviceDate = serviceDate;
    }


    /**
     * Gets the shopAccount__c value for this OpportunityLineItem.
     * 
     * @return shopAccount__c
     */
    public java.lang.String getShopAccount__c() {
        return shopAccount__c;
    }


    /**
     * Sets the shopAccount__c value for this OpportunityLineItem.
     * 
     * @param shopAccount__c
     */
    public void setShopAccount__c(java.lang.String shopAccount__c) {
        this.shopAccount__c = shopAccount__c;
    }


    /**
     * Gets the shopAccount__r value for this OpportunityLineItem.
     * 
     * @return shopAccount__r
     */
    public com.sforce.soap.enterprise.sobject.Account getShopAccount__r() {
        return shopAccount__r;
    }


    /**
     * Sets the shopAccount__r value for this OpportunityLineItem.
     * 
     * @param shopAccount__r
     */
    public void setShopAccount__r(com.sforce.soap.enterprise.sobject.Account shopAccount__r) {
        this.shopAccount__r = shopAccount__r;
    }


    /**
     * Gets the showChannel__c value for this OpportunityLineItem.
     * 
     * @return showChannel__c
     */
    public java.lang.String getShowChannel__c() {
        return showChannel__c;
    }


    /**
     * Sets the showChannel__c value for this OpportunityLineItem.
     * 
     * @param showChannel__c
     */
    public void setShowChannel__c(java.lang.String showChannel__c) {
        this.showChannel__c = showChannel__c;
    }


    /**
     * Gets the showKeyWord__c value for this OpportunityLineItem.
     * 
     * @return showKeyWord__c
     */
    public java.lang.String getShowKeyWord__c() {
        return showKeyWord__c;
    }


    /**
     * Sets the showKeyWord__c value for this OpportunityLineItem.
     * 
     * @param showKeyWord__c
     */
    public void setShowKeyWord__c(java.lang.String showKeyWord__c) {
        this.showKeyWord__c = showKeyWord__c;
    }


    /**
     * Gets the showShopAccount__c value for this OpportunityLineItem.
     * 
     * @return showShopAccount__c
     */
    public java.lang.String getShowShopAccount__c() {
        return showShopAccount__c;
    }


    /**
     * Sets the showShopAccount__c value for this OpportunityLineItem.
     * 
     * @param showShopAccount__c
     */
    public void setShowShopAccount__c(java.lang.String showShopAccount__c) {
        this.showShopAccount__c = showShopAccount__c;
    }


    /**
     * Gets the showSysCrossShopSearch__c value for this OpportunityLineItem.
     * 
     * @return showSysCrossShopSearch__c
     */
    public java.lang.String getShowSysCrossShopSearch__c() {
        return showSysCrossShopSearch__c;
    }


    /**
     * Sets the showSysCrossShopSearch__c value for this OpportunityLineItem.
     * 
     * @param showSysCrossShopSearch__c
     */
    public void setShowSysCrossShopSearch__c(java.lang.String showSysCrossShopSearch__c) {
        this.showSysCrossShopSearch__c = showSysCrossShopSearch__c;
    }


    /**
     * Gets the showSysInventory__c value for this OpportunityLineItem.
     * 
     * @return showSysInventory__c
     */
    public java.lang.String getShowSysInventory__c() {
        return showSysInventory__c;
    }


    /**
     * Sets the showSysInventory__c value for this OpportunityLineItem.
     * 
     * @param showSysInventory__c
     */
    public void setShowSysInventory__c(java.lang.String showSysInventory__c) {
        this.showSysInventory__c = showSysInventory__c;
    }


    /**
     * Gets the sortOrder value for this OpportunityLineItem.
     * 
     * @return sortOrder
     */
    public java.lang.Integer getSortOrder() {
        return sortOrder;
    }


    /**
     * Sets the sortOrder value for this OpportunityLineItem.
     * 
     * @param sortOrder
     */
    public void setSortOrder(java.lang.Integer sortOrder) {
        this.sortOrder = sortOrder;
    }


    /**
     * Gets the startDate__c value for this OpportunityLineItem.
     * 
     * @return startDate__c
     */
    public java.util.Date getStartDate__c() {
        return startDate__c;
    }


    /**
     * Sets the startDate__c value for this OpportunityLineItem.
     * 
     * @param startDate__c
     */
    public void setStartDate__c(java.util.Date startDate__c) {
        this.startDate__c = startDate__c;
    }


    /**
     * Gets the subtotal value for this OpportunityLineItem.
     * 
     * @return subtotal
     */
    public java.lang.Double getSubtotal() {
        return subtotal;
    }


    /**
     * Sets the subtotal value for this OpportunityLineItem.
     * 
     * @param subtotal
     */
    public void setSubtotal(java.lang.Double subtotal) {
        this.subtotal = subtotal;
    }


    /**
     * Gets the systemModstamp value for this OpportunityLineItem.
     * 
     * @return systemModstamp
     */
    public java.util.Calendar getSystemModstamp() {
        return systemModstamp;
    }


    /**
     * Sets the systemModstamp value for this OpportunityLineItem.
     * 
     * @param systemModstamp
     */
    public void setSystemModstamp(java.util.Calendar systemModstamp) {
        this.systemModstamp = systemModstamp;
    }


    /**
     * Gets the totalPrice value for this OpportunityLineItem.
     * 
     * @return totalPrice
     */
    public java.lang.Double getTotalPrice() {
        return totalPrice;
    }


    /**
     * Sets the totalPrice value for this OpportunityLineItem.
     * 
     * @param totalPrice
     */
    public void setTotalPrice(java.lang.Double totalPrice) {
        this.totalPrice = totalPrice;
    }


    /**
     * Gets the unitPrice value for this OpportunityLineItem.
     * 
     * @return unitPrice
     */
    public java.lang.Double getUnitPrice() {
        return unitPrice;
    }


    /**
     * Sets the unitPrice value for this OpportunityLineItem.
     * 
     * @param unitPrice
     */
    public void setUnitPrice(java.lang.Double unitPrice) {
        this.unitPrice = unitPrice;
    }


    /**
     * Gets the isProductRPAppCalc__c value for this OpportunityLineItem.
     * 
     * @return isProductRPAppCalc__c
     */
    public java.lang.String getIsProductRPAppCalc__c() {
        return isProductRPAppCalc__c;
    }


    /**
     * Sets the isProductRPAppCalc__c value for this OpportunityLineItem.
     * 
     * @param isProductRPAppCalc__c
     */
    public void setIsProductRPAppCalc__c(java.lang.String isProductRPAppCalc__c) {
        this.isProductRPAppCalc__c = isProductRPAppCalc__c;
    }


    /**
     * Gets the isProductRPApp__c value for this OpportunityLineItem.
     * 
     * @return isProductRPApp__c
     */
    public java.lang.Boolean getIsProductRPApp__c() {
        return isProductRPApp__c;
    }


    /**
     * Sets the isProductRPApp__c value for this OpportunityLineItem.
     * 
     * @param isProductRPApp__c
     */
    public void setIsProductRPApp__c(java.lang.Boolean isProductRPApp__c) {
        this.isProductRPApp__c = isProductRPApp__c;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof OpportunityLineItem)) return false;
        OpportunityLineItem other = (OpportunityLineItem) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.channel__c==null && other.getChannel__c()==null) || 
             (this.channel__c!=null &&
              this.channel__c.equals(other.getChannel__c()))) &&
            ((this.city__c==null && other.getCity__c()==null) || 
             (this.city__c!=null &&
              this.city__c.equals(other.getCity__c()))) &&
            ((this.city__r==null && other.getCity__r()==null) || 
             (this.city__r!=null &&
              this.city__r.equals(other.getCity__r()))) &&
            ((this.createdBy==null && other.getCreatedBy()==null) || 
             (this.createdBy!=null &&
              this.createdBy.equals(other.getCreatedBy()))) &&
            ((this.createdById==null && other.getCreatedById()==null) || 
             (this.createdById!=null &&
              this.createdById.equals(other.getCreatedById()))) &&
            ((this.createdDate==null && other.getCreatedDate()==null) || 
             (this.createdDate!=null &&
              this.createdDate.equals(other.getCreatedDate()))) &&
            ((this.description==null && other.getDescription()==null) || 
             (this.description!=null &&
              this.description.equals(other.getDescription()))) &&
            ((this.discount==null && other.getDiscount()==null) || 
             (this.discount!=null &&
              this.discount.equals(other.getDiscount()))) &&
            ((this.editStatus__c==null && other.getEditStatus__c()==null) || 
             (this.editStatus__c!=null &&
              this.editStatus__c.equals(other.getEditStatus__c()))) &&
            ((this.endDate__c==null && other.getEndDate__c()==null) || 
             (this.endDate__c!=null &&
              this.endDate__c.equals(other.getEndDate__c()))) &&
            ((this.freeOptyProduct__c==null && other.getFreeOptyProduct__c()==null) || 
             (this.freeOptyProduct__c!=null &&
              this.freeOptyProduct__c.equals(other.getFreeOptyProduct__c()))) &&
            ((this.infoGood__c==null && other.getInfoGood__c()==null) || 
             (this.infoGood__c!=null &&
              this.infoGood__c.equals(other.getInfoGood__c()))) &&
            ((this.inventoryOperationResult__c==null && other.getInventoryOperationResult__c()==null) || 
             (this.inventoryOperationResult__c!=null &&
              this.inventoryOperationResult__c.equals(other.getInventoryOperationResult__c()))) &&
            ((this.inventoryStatus__c==null && other.getInventoryStatus__c()==null) || 
             (this.inventoryStatus__c!=null &&
              this.inventoryStatus__c.equals(other.getInventoryStatus__c()))) &&
            ((this.isBrandAD__c==null && other.getIsBrandAD__c()==null) || 
             (this.isBrandAD__c!=null &&
              this.isBrandAD__c.equals(other.getIsBrandAD__c()))) &&
            ((this.isBrandAdProduct__c==null && other.getIsBrandAdProduct__c()==null) || 
             (this.isBrandAdProduct__c!=null &&
              this.isBrandAdProduct__c.equals(other.getIsBrandAdProduct__c()))) &&
            ((this.isDeleted==null && other.getIsDeleted()==null) || 
             (this.isDeleted!=null &&
              this.isDeleted.equals(other.getIsDeleted()))) &&
            ((this.isInfoGood__c==null && other.getIsInfoGood__c()==null) || 
             (this.isInfoGood__c!=null &&
              this.isInfoGood__c.equals(other.getIsInfoGood__c()))) &&
            ((this.keyWord__c==null && other.getKeyWord__c()==null) || 
             (this.keyWord__c!=null &&
              this.keyWord__c.equals(other.getKeyWord__c()))) &&
            ((this.LTTotalListPrice__c==null && other.getLTTotalListPrice__c()==null) || 
             (this.LTTotalListPrice__c!=null &&
              this.LTTotalListPrice__c.equals(other.getLTTotalListPrice__c()))) &&
            ((this.lastModifiedBy==null && other.getLastModifiedBy()==null) || 
             (this.lastModifiedBy!=null &&
              this.lastModifiedBy.equals(other.getLastModifiedBy()))) &&
            ((this.lastModifiedById==null && other.getLastModifiedById()==null) || 
             (this.lastModifiedById!=null &&
              this.lastModifiedById.equals(other.getLastModifiedById()))) &&
            ((this.lastModifiedDate==null && other.getLastModifiedDate()==null) || 
             (this.lastModifiedDate!=null &&
              this.lastModifiedDate.equals(other.getLastModifiedDate()))) &&
            ((this.listPrice==null && other.getListPrice()==null) || 
             (this.listPrice!=null &&
              this.listPrice.equals(other.getListPrice()))) &&
            ((this.opportunity==null && other.getOpportunity()==null) || 
             (this.opportunity!=null &&
              this.opportunity.equals(other.getOpportunity()))) &&
            ((this.opportunityId==null && other.getOpportunityId()==null) || 
             (this.opportunityId!=null &&
              this.opportunityId.equals(other.getOpportunityId()))) &&
            ((this.pricebookEntry==null && other.getPricebookEntry()==null) || 
             (this.pricebookEntry!=null &&
              this.pricebookEntry.equals(other.getPricebookEntry()))) &&
            ((this.pricebookEntryId==null && other.getPricebookEntryId()==null) || 
             (this.pricebookEntryId!=null &&
              this.pricebookEntryId.equals(other.getPricebookEntryId()))) &&
            ((this.quantity==null && other.getQuantity()==null) || 
             (this.quantity!=null &&
              this.quantity.equals(other.getQuantity()))) &&
            ((this.serviceDate==null && other.getServiceDate()==null) || 
             (this.serviceDate!=null &&
              this.serviceDate.equals(other.getServiceDate()))) &&
            ((this.shopAccount__c==null && other.getShopAccount__c()==null) || 
             (this.shopAccount__c!=null &&
              this.shopAccount__c.equals(other.getShopAccount__c()))) &&
            ((this.shopAccount__r==null && other.getShopAccount__r()==null) || 
             (this.shopAccount__r!=null &&
              this.shopAccount__r.equals(other.getShopAccount__r()))) &&
            ((this.showChannel__c==null && other.getShowChannel__c()==null) || 
             (this.showChannel__c!=null &&
              this.showChannel__c.equals(other.getShowChannel__c()))) &&
            ((this.showKeyWord__c==null && other.getShowKeyWord__c()==null) || 
             (this.showKeyWord__c!=null &&
              this.showKeyWord__c.equals(other.getShowKeyWord__c()))) &&
            ((this.showShopAccount__c==null && other.getShowShopAccount__c()==null) || 
             (this.showShopAccount__c!=null &&
              this.showShopAccount__c.equals(other.getShowShopAccount__c()))) &&
            ((this.showSysCrossShopSearch__c==null && other.getShowSysCrossShopSearch__c()==null) || 
             (this.showSysCrossShopSearch__c!=null &&
              this.showSysCrossShopSearch__c.equals(other.getShowSysCrossShopSearch__c()))) &&
            ((this.showSysInventory__c==null && other.getShowSysInventory__c()==null) || 
             (this.showSysInventory__c!=null &&
              this.showSysInventory__c.equals(other.getShowSysInventory__c()))) &&
            ((this.sortOrder==null && other.getSortOrder()==null) || 
             (this.sortOrder!=null &&
              this.sortOrder.equals(other.getSortOrder()))) &&
            ((this.startDate__c==null && other.getStartDate__c()==null) || 
             (this.startDate__c!=null &&
              this.startDate__c.equals(other.getStartDate__c()))) &&
            ((this.subtotal==null && other.getSubtotal()==null) || 
             (this.subtotal!=null &&
              this.subtotal.equals(other.getSubtotal()))) &&
            ((this.systemModstamp==null && other.getSystemModstamp()==null) || 
             (this.systemModstamp!=null &&
              this.systemModstamp.equals(other.getSystemModstamp()))) &&
            ((this.totalPrice==null && other.getTotalPrice()==null) || 
             (this.totalPrice!=null &&
              this.totalPrice.equals(other.getTotalPrice()))) &&
            ((this.unitPrice==null && other.getUnitPrice()==null) || 
             (this.unitPrice!=null &&
              this.unitPrice.equals(other.getUnitPrice()))) &&
            ((this.isProductRPAppCalc__c==null && other.getIsProductRPAppCalc__c()==null) || 
             (this.isProductRPAppCalc__c!=null &&
              this.isProductRPAppCalc__c.equals(other.getIsProductRPAppCalc__c()))) &&
            ((this.isProductRPApp__c==null && other.getIsProductRPApp__c()==null) || 
             (this.isProductRPApp__c!=null &&
              this.isProductRPApp__c.equals(other.getIsProductRPApp__c())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getChannel__c() != null) {
            _hashCode += getChannel__c().hashCode();
        }
        if (getCity__c() != null) {
            _hashCode += getCity__c().hashCode();
        }
        if (getCity__r() != null) {
            _hashCode += getCity__r().hashCode();
        }
        if (getCreatedBy() != null) {
            _hashCode += getCreatedBy().hashCode();
        }
        if (getCreatedById() != null) {
            _hashCode += getCreatedById().hashCode();
        }
        if (getCreatedDate() != null) {
            _hashCode += getCreatedDate().hashCode();
        }
        if (getDescription() != null) {
            _hashCode += getDescription().hashCode();
        }
        if (getDiscount() != null) {
            _hashCode += getDiscount().hashCode();
        }
        if (getEditStatus__c() != null) {
            _hashCode += getEditStatus__c().hashCode();
        }
        if (getEndDate__c() != null) {
            _hashCode += getEndDate__c().hashCode();
        }
        if (getFreeOptyProduct__c() != null) {
            _hashCode += getFreeOptyProduct__c().hashCode();
        }
        if (getInfoGood__c() != null) {
            _hashCode += getInfoGood__c().hashCode();
        }
        if (getInventoryOperationResult__c() != null) {
            _hashCode += getInventoryOperationResult__c().hashCode();
        }
        if (getInventoryStatus__c() != null) {
            _hashCode += getInventoryStatus__c().hashCode();
        }
        if (getIsBrandAD__c() != null) {
            _hashCode += getIsBrandAD__c().hashCode();
        }
        if (getIsBrandAdProduct__c() != null) {
            _hashCode += getIsBrandAdProduct__c().hashCode();
        }
        if (getIsDeleted() != null) {
            _hashCode += getIsDeleted().hashCode();
        }
        if (getIsInfoGood__c() != null) {
            _hashCode += getIsInfoGood__c().hashCode();
        }
        if (getKeyWord__c() != null) {
            _hashCode += getKeyWord__c().hashCode();
        }
        if (getLTTotalListPrice__c() != null) {
            _hashCode += getLTTotalListPrice__c().hashCode();
        }
        if (getLastModifiedBy() != null) {
            _hashCode += getLastModifiedBy().hashCode();
        }
        if (getLastModifiedById() != null) {
            _hashCode += getLastModifiedById().hashCode();
        }
        if (getLastModifiedDate() != null) {
            _hashCode += getLastModifiedDate().hashCode();
        }
        if (getListPrice() != null) {
            _hashCode += getListPrice().hashCode();
        }
        if (getOpportunity() != null) {
            _hashCode += getOpportunity().hashCode();
        }
        if (getOpportunityId() != null) {
            _hashCode += getOpportunityId().hashCode();
        }
        if (getPricebookEntry() != null) {
            _hashCode += getPricebookEntry().hashCode();
        }
        if (getPricebookEntryId() != null) {
            _hashCode += getPricebookEntryId().hashCode();
        }
        if (getQuantity() != null) {
            _hashCode += getQuantity().hashCode();
        }
        if (getServiceDate() != null) {
            _hashCode += getServiceDate().hashCode();
        }
        if (getShopAccount__c() != null) {
            _hashCode += getShopAccount__c().hashCode();
        }
        if (getShopAccount__r() != null) {
            _hashCode += getShopAccount__r().hashCode();
        }
        if (getShowChannel__c() != null) {
            _hashCode += getShowChannel__c().hashCode();
        }
        if (getShowKeyWord__c() != null) {
            _hashCode += getShowKeyWord__c().hashCode();
        }
        if (getShowShopAccount__c() != null) {
            _hashCode += getShowShopAccount__c().hashCode();
        }
        if (getShowSysCrossShopSearch__c() != null) {
            _hashCode += getShowSysCrossShopSearch__c().hashCode();
        }
        if (getShowSysInventory__c() != null) {
            _hashCode += getShowSysInventory__c().hashCode();
        }
        if (getSortOrder() != null) {
            _hashCode += getSortOrder().hashCode();
        }
        if (getStartDate__c() != null) {
            _hashCode += getStartDate__c().hashCode();
        }
        if (getSubtotal() != null) {
            _hashCode += getSubtotal().hashCode();
        }
        if (getSystemModstamp() != null) {
            _hashCode += getSystemModstamp().hashCode();
        }
        if (getTotalPrice() != null) {
            _hashCode += getTotalPrice().hashCode();
        }
        if (getUnitPrice() != null) {
            _hashCode += getUnitPrice().hashCode();
        }
        if (getIsProductRPAppCalc__c() != null) {
            _hashCode += getIsProductRPAppCalc__c().hashCode();
        }
        if (getIsProductRPApp__c() != null) {
            _hashCode += getIsProductRPApp__c().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(OpportunityLineItem.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OpportunityLineItem"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("channel__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Channel__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("city__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "City__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("city__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "City__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "City__c"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("discount");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Discount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("editStatus__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "EditStatus__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("endDate__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "EndDate__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("freeOptyProduct__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "FreeOptyProduct__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("infoGood__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "InfoGood__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inventoryOperationResult__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "InventoryOperationResult__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inventoryStatus__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "InventoryStatus__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isBrandAD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsBrandAD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isBrandAdProduct__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsBrandAdProduct__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isDeleted");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsDeleted"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isInfoGood__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsInfoGood__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("keyWord__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KeyWord__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("LTTotalListPrice__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LTTotalListPrice__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("listPrice");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ListPrice"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("opportunity");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Opportunity"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Opportunity"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("opportunityId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OpportunityId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pricebookEntry");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PricebookEntry"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PricebookEntry"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pricebookEntryId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PricebookEntryId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("quantity");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Quantity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serviceDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ServiceDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shopAccount__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ShopAccount__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shopAccount__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ShopAccount__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Account"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("showChannel__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ShowChannel__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("showKeyWord__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ShowKeyWord__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("showShopAccount__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ShowShopAccount__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("showSysCrossShopSearch__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ShowSysCrossShopSearch__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("showSysInventory__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ShowSysInventory__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sortOrder");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SortOrder"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("startDate__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "StartDate__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("subtotal");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Subtotal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("systemModstamp");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SystemModstamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalPrice");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TotalPrice"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("unitPrice");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UnitPrice"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isProductRPAppCalc__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "isProductRPAppCalc__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isProductRPApp__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "isProductRPApp__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
