/**
 * _case.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.sforce.soap.enterprise.sobject;

public class _case  extends com.sforce.soap.enterprise.sobject.SObject  implements java.io.Serializable {
    private com.sforce.soap.enterprise.sobject.Account account;

    private java.lang.String accountId;

    private com.sforce.soap.enterprise.QueryResult activityHistories;

    private java.lang.String ageSect__c;

    private java.lang.String alipayAccountNo__c;

    private com.sforce.soap.enterprise.sobject.Asset asset;

    private java.lang.String assetId;

    private com.sforce.soap.enterprise.QueryResult attachments;

    private java.lang.String bookContact__c;

    private java.util.Date bookDate__c;

    private java.lang.String bookPerson__c;

    private com.sforce.soap.enterprise.sobject.BusinessHours businessHours;

    private java.lang.String businessHoursId;

    private com.sforce.soap.enterprise.QueryResult caseComments;

    private com.sforce.soap.enterprise.QueryResult caseContactRoles;

    private java.lang.String caseContactWay__c;

    private java.lang.String caseContact__c;

    private java.lang.String caseNumber;

    private com.sforce.soap.enterprise.QueryResult caseRefund__r;

    private com.sforce.soap.enterprise.QueryResult caseSolutions;

    private com.sforce.soap.enterprise.QueryResult cases;

    private java.util.Calendar closedDate;

    private com.sforce.soap.enterprise.sobject.Contact contact;

    private java.lang.String contactId;

    private com.sforce.soap.enterprise.sobject.User createdBy;

    private java.lang.String createdById;

    private java.util.Calendar createdDate;

    private java.lang.String customerRequire__c;

    private java.lang.String dealID__c;

    private java.lang.String dealName__c;

    private java.lang.String description;

    private java.lang.String description__c;

    private com.sforce.soap.enterprise.QueryResult events;

    private com.sforce.soap.enterprise.QueryResult histories;

    private java.lang.Boolean isClosed;

    private java.lang.Boolean isClosedOnCreate;

    private java.lang.Boolean isComplain__c;

    private java.lang.Boolean isDeleted;

    private java.lang.Boolean isEscalated;

    private java.lang.Boolean isNeedFollow__c;

    private com.sforce.soap.enterprise.sobject.User lastModifiedBy;

    private java.lang.String lastModifiedById;

    private java.util.Calendar lastModifiedDate;

    private java.lang.String netBankAccountName__c;

    private java.lang.String netBankAccoutNo__c;

    private java.lang.String netBankName__c;

    private com.sforce.soap.enterprise.QueryResult openActivities;

    private java.lang.String orderID__c;

    private java.lang.String origin;

    private com.sforce.soap.enterprise.sobject.Name owner;

    private java.lang.String ownerId;

    private com.sforce.soap.enterprise.sobject._case parent;

    private java.lang.String parentId;

    private java.lang.String priority;

    private com.sforce.soap.enterprise.QueryResult processInstances;

    private com.sforce.soap.enterprise.QueryResult processSteps;

    private java.lang.String purchaseMobileNo__c;

    private java.lang.String reason;

    private java.lang.String referURL__c;

    private com.sforce.soap.enterprise.QueryResult shares;

    private java.lang.String shipExpressInfo__c;

    private java.lang.String shipProductName__c;

    private java.lang.String shopGroupID__c;

    private java.lang.String shopGroupName__c;

    private java.lang.String shopID__c;

    private java.lang.String shopName__c;

    private com.sforce.soap.enterprise.QueryResult solutions;

    private java.lang.String status;

    private java.lang.String subType__c;

    private java.lang.String subject;

    private java.lang.String suppliedCompany;

    private java.lang.String suppliedEmail;

    private java.lang.String suppliedName;

    private java.lang.String suppliedPhone;

    private java.util.Calendar systemModstamp;

    private com.sforce.soap.enterprise.QueryResult tasks;

    private com.sforce.soap.enterprise.QueryResult teamMembers;

    private com.sforce.soap.enterprise.QueryResult teamTemplateRecords;

    private java.lang.String thirdPartSerialNo__c;

    private java.lang.String thirdSubType__c;

    private java.lang.String type;

    private java.lang.String userAddress__c;

    private java.lang.String userCardNo__c;

    private java.lang.String userEmail__c;

    private java.lang.String userID__c;

    public _case() {
    }

    public _case(
           java.lang.String[] fieldsToNull,
           java.lang.String id,
           com.sforce.soap.enterprise.sobject.Account account,
           java.lang.String accountId,
           com.sforce.soap.enterprise.QueryResult activityHistories,
           java.lang.String ageSect__c,
           java.lang.String alipayAccountNo__c,
           com.sforce.soap.enterprise.sobject.Asset asset,
           java.lang.String assetId,
           com.sforce.soap.enterprise.QueryResult attachments,
           java.lang.String bookContact__c,
           java.util.Date bookDate__c,
           java.lang.String bookPerson__c,
           com.sforce.soap.enterprise.sobject.BusinessHours businessHours,
           java.lang.String businessHoursId,
           com.sforce.soap.enterprise.QueryResult caseComments,
           com.sforce.soap.enterprise.QueryResult caseContactRoles,
           java.lang.String caseContactWay__c,
           java.lang.String caseContact__c,
           java.lang.String caseNumber,
           com.sforce.soap.enterprise.QueryResult caseRefund__r,
           com.sforce.soap.enterprise.QueryResult caseSolutions,
           com.sforce.soap.enterprise.QueryResult cases,
           java.util.Calendar closedDate,
           com.sforce.soap.enterprise.sobject.Contact contact,
           java.lang.String contactId,
           com.sforce.soap.enterprise.sobject.User createdBy,
           java.lang.String createdById,
           java.util.Calendar createdDate,
           java.lang.String customerRequire__c,
           java.lang.String dealID__c,
           java.lang.String dealName__c,
           java.lang.String description,
           java.lang.String description__c,
           com.sforce.soap.enterprise.QueryResult events,
           com.sforce.soap.enterprise.QueryResult histories,
           java.lang.Boolean isClosed,
           java.lang.Boolean isClosedOnCreate,
           java.lang.Boolean isComplain__c,
           java.lang.Boolean isDeleted,
           java.lang.Boolean isEscalated,
           java.lang.Boolean isNeedFollow__c,
           com.sforce.soap.enterprise.sobject.User lastModifiedBy,
           java.lang.String lastModifiedById,
           java.util.Calendar lastModifiedDate,
           java.lang.String netBankAccountName__c,
           java.lang.String netBankAccoutNo__c,
           java.lang.String netBankName__c,
           com.sforce.soap.enterprise.QueryResult openActivities,
           java.lang.String orderID__c,
           java.lang.String origin,
           com.sforce.soap.enterprise.sobject.Name owner,
           java.lang.String ownerId,
           com.sforce.soap.enterprise.sobject._case parent,
           java.lang.String parentId,
           java.lang.String priority,
           com.sforce.soap.enterprise.QueryResult processInstances,
           com.sforce.soap.enterprise.QueryResult processSteps,
           java.lang.String purchaseMobileNo__c,
           java.lang.String reason,
           java.lang.String referURL__c,
           com.sforce.soap.enterprise.QueryResult shares,
           java.lang.String shipExpressInfo__c,
           java.lang.String shipProductName__c,
           java.lang.String shopGroupID__c,
           java.lang.String shopGroupName__c,
           java.lang.String shopID__c,
           java.lang.String shopName__c,
           com.sforce.soap.enterprise.QueryResult solutions,
           java.lang.String status,
           java.lang.String subType__c,
           java.lang.String subject,
           java.lang.String suppliedCompany,
           java.lang.String suppliedEmail,
           java.lang.String suppliedName,
           java.lang.String suppliedPhone,
           java.util.Calendar systemModstamp,
           com.sforce.soap.enterprise.QueryResult tasks,
           com.sforce.soap.enterprise.QueryResult teamMembers,
           com.sforce.soap.enterprise.QueryResult teamTemplateRecords,
           java.lang.String thirdPartSerialNo__c,
           java.lang.String thirdSubType__c,
           java.lang.String type,
           java.lang.String userAddress__c,
           java.lang.String userCardNo__c,
           java.lang.String userEmail__c,
           java.lang.String userID__c) {
        super(
            fieldsToNull,
            id);
        this.account = account;
        this.accountId = accountId;
        this.activityHistories = activityHistories;
        this.ageSect__c = ageSect__c;
        this.alipayAccountNo__c = alipayAccountNo__c;
        this.asset = asset;
        this.assetId = assetId;
        this.attachments = attachments;
        this.bookContact__c = bookContact__c;
        this.bookDate__c = bookDate__c;
        this.bookPerson__c = bookPerson__c;
        this.businessHours = businessHours;
        this.businessHoursId = businessHoursId;
        this.caseComments = caseComments;
        this.caseContactRoles = caseContactRoles;
        this.caseContactWay__c = caseContactWay__c;
        this.caseContact__c = caseContact__c;
        this.caseNumber = caseNumber;
        this.caseRefund__r = caseRefund__r;
        this.caseSolutions = caseSolutions;
        this.cases = cases;
        this.closedDate = closedDate;
        this.contact = contact;
        this.contactId = contactId;
        this.createdBy = createdBy;
        this.createdById = createdById;
        this.createdDate = createdDate;
        this.customerRequire__c = customerRequire__c;
        this.dealID__c = dealID__c;
        this.dealName__c = dealName__c;
        this.description = description;
        this.description__c = description__c;
        this.events = events;
        this.histories = histories;
        this.isClosed = isClosed;
        this.isClosedOnCreate = isClosedOnCreate;
        this.isComplain__c = isComplain__c;
        this.isDeleted = isDeleted;
        this.isEscalated = isEscalated;
        this.isNeedFollow__c = isNeedFollow__c;
        this.lastModifiedBy = lastModifiedBy;
        this.lastModifiedById = lastModifiedById;
        this.lastModifiedDate = lastModifiedDate;
        this.netBankAccountName__c = netBankAccountName__c;
        this.netBankAccoutNo__c = netBankAccoutNo__c;
        this.netBankName__c = netBankName__c;
        this.openActivities = openActivities;
        this.orderID__c = orderID__c;
        this.origin = origin;
        this.owner = owner;
        this.ownerId = ownerId;
        this.parent = parent;
        this.parentId = parentId;
        this.priority = priority;
        this.processInstances = processInstances;
        this.processSteps = processSteps;
        this.purchaseMobileNo__c = purchaseMobileNo__c;
        this.reason = reason;
        this.referURL__c = referURL__c;
        this.shares = shares;
        this.shipExpressInfo__c = shipExpressInfo__c;
        this.shipProductName__c = shipProductName__c;
        this.shopGroupID__c = shopGroupID__c;
        this.shopGroupName__c = shopGroupName__c;
        this.shopID__c = shopID__c;
        this.shopName__c = shopName__c;
        this.solutions = solutions;
        this.status = status;
        this.subType__c = subType__c;
        this.subject = subject;
        this.suppliedCompany = suppliedCompany;
        this.suppliedEmail = suppliedEmail;
        this.suppliedName = suppliedName;
        this.suppliedPhone = suppliedPhone;
        this.systemModstamp = systemModstamp;
        this.tasks = tasks;
        this.teamMembers = teamMembers;
        this.teamTemplateRecords = teamTemplateRecords;
        this.thirdPartSerialNo__c = thirdPartSerialNo__c;
        this.thirdSubType__c = thirdSubType__c;
        this.type = type;
        this.userAddress__c = userAddress__c;
        this.userCardNo__c = userCardNo__c;
        this.userEmail__c = userEmail__c;
        this.userID__c = userID__c;
    }


    /**
     * Gets the account value for this _case.
     * 
     * @return account
     */
    public com.sforce.soap.enterprise.sobject.Account getAccount() {
        return account;
    }


    /**
     * Sets the account value for this _case.
     * 
     * @param account
     */
    public void setAccount(com.sforce.soap.enterprise.sobject.Account account) {
        this.account = account;
    }


    /**
     * Gets the accountId value for this _case.
     * 
     * @return accountId
     */
    public java.lang.String getAccountId() {
        return accountId;
    }


    /**
     * Sets the accountId value for this _case.
     * 
     * @param accountId
     */
    public void setAccountId(java.lang.String accountId) {
        this.accountId = accountId;
    }


    /**
     * Gets the activityHistories value for this _case.
     * 
     * @return activityHistories
     */
    public com.sforce.soap.enterprise.QueryResult getActivityHistories() {
        return activityHistories;
    }


    /**
     * Sets the activityHistories value for this _case.
     * 
     * @param activityHistories
     */
    public void setActivityHistories(com.sforce.soap.enterprise.QueryResult activityHistories) {
        this.activityHistories = activityHistories;
    }


    /**
     * Gets the ageSect__c value for this _case.
     * 
     * @return ageSect__c
     */
    public java.lang.String getAgeSect__c() {
        return ageSect__c;
    }


    /**
     * Sets the ageSect__c value for this _case.
     * 
     * @param ageSect__c
     */
    public void setAgeSect__c(java.lang.String ageSect__c) {
        this.ageSect__c = ageSect__c;
    }


    /**
     * Gets the alipayAccountNo__c value for this _case.
     * 
     * @return alipayAccountNo__c
     */
    public java.lang.String getAlipayAccountNo__c() {
        return alipayAccountNo__c;
    }


    /**
     * Sets the alipayAccountNo__c value for this _case.
     * 
     * @param alipayAccountNo__c
     */
    public void setAlipayAccountNo__c(java.lang.String alipayAccountNo__c) {
        this.alipayAccountNo__c = alipayAccountNo__c;
    }


    /**
     * Gets the asset value for this _case.
     * 
     * @return asset
     */
    public com.sforce.soap.enterprise.sobject.Asset getAsset() {
        return asset;
    }


    /**
     * Sets the asset value for this _case.
     * 
     * @param asset
     */
    public void setAsset(com.sforce.soap.enterprise.sobject.Asset asset) {
        this.asset = asset;
    }


    /**
     * Gets the assetId value for this _case.
     * 
     * @return assetId
     */
    public java.lang.String getAssetId() {
        return assetId;
    }


    /**
     * Sets the assetId value for this _case.
     * 
     * @param assetId
     */
    public void setAssetId(java.lang.String assetId) {
        this.assetId = assetId;
    }


    /**
     * Gets the attachments value for this _case.
     * 
     * @return attachments
     */
    public com.sforce.soap.enterprise.QueryResult getAttachments() {
        return attachments;
    }


    /**
     * Sets the attachments value for this _case.
     * 
     * @param attachments
     */
    public void setAttachments(com.sforce.soap.enterprise.QueryResult attachments) {
        this.attachments = attachments;
    }


    /**
     * Gets the bookContact__c value for this _case.
     * 
     * @return bookContact__c
     */
    public java.lang.String getBookContact__c() {
        return bookContact__c;
    }


    /**
     * Sets the bookContact__c value for this _case.
     * 
     * @param bookContact__c
     */
    public void setBookContact__c(java.lang.String bookContact__c) {
        this.bookContact__c = bookContact__c;
    }


    /**
     * Gets the bookDate__c value for this _case.
     * 
     * @return bookDate__c
     */
    public java.util.Date getBookDate__c() {
        return bookDate__c;
    }


    /**
     * Sets the bookDate__c value for this _case.
     * 
     * @param bookDate__c
     */
    public void setBookDate__c(java.util.Date bookDate__c) {
        this.bookDate__c = bookDate__c;
    }


    /**
     * Gets the bookPerson__c value for this _case.
     * 
     * @return bookPerson__c
     */
    public java.lang.String getBookPerson__c() {
        return bookPerson__c;
    }


    /**
     * Sets the bookPerson__c value for this _case.
     * 
     * @param bookPerson__c
     */
    public void setBookPerson__c(java.lang.String bookPerson__c) {
        this.bookPerson__c = bookPerson__c;
    }


    /**
     * Gets the businessHours value for this _case.
     * 
     * @return businessHours
     */
    public com.sforce.soap.enterprise.sobject.BusinessHours getBusinessHours() {
        return businessHours;
    }


    /**
     * Sets the businessHours value for this _case.
     * 
     * @param businessHours
     */
    public void setBusinessHours(com.sforce.soap.enterprise.sobject.BusinessHours businessHours) {
        this.businessHours = businessHours;
    }


    /**
     * Gets the businessHoursId value for this _case.
     * 
     * @return businessHoursId
     */
    public java.lang.String getBusinessHoursId() {
        return businessHoursId;
    }


    /**
     * Sets the businessHoursId value for this _case.
     * 
     * @param businessHoursId
     */
    public void setBusinessHoursId(java.lang.String businessHoursId) {
        this.businessHoursId = businessHoursId;
    }


    /**
     * Gets the caseComments value for this _case.
     * 
     * @return caseComments
     */
    public com.sforce.soap.enterprise.QueryResult getCaseComments() {
        return caseComments;
    }


    /**
     * Sets the caseComments value for this _case.
     * 
     * @param caseComments
     */
    public void setCaseComments(com.sforce.soap.enterprise.QueryResult caseComments) {
        this.caseComments = caseComments;
    }


    /**
     * Gets the caseContactRoles value for this _case.
     * 
     * @return caseContactRoles
     */
    public com.sforce.soap.enterprise.QueryResult getCaseContactRoles() {
        return caseContactRoles;
    }


    /**
     * Sets the caseContactRoles value for this _case.
     * 
     * @param caseContactRoles
     */
    public void setCaseContactRoles(com.sforce.soap.enterprise.QueryResult caseContactRoles) {
        this.caseContactRoles = caseContactRoles;
    }


    /**
     * Gets the caseContactWay__c value for this _case.
     * 
     * @return caseContactWay__c
     */
    public java.lang.String getCaseContactWay__c() {
        return caseContactWay__c;
    }


    /**
     * Sets the caseContactWay__c value for this _case.
     * 
     * @param caseContactWay__c
     */
    public void setCaseContactWay__c(java.lang.String caseContactWay__c) {
        this.caseContactWay__c = caseContactWay__c;
    }


    /**
     * Gets the caseContact__c value for this _case.
     * 
     * @return caseContact__c
     */
    public java.lang.String getCaseContact__c() {
        return caseContact__c;
    }


    /**
     * Sets the caseContact__c value for this _case.
     * 
     * @param caseContact__c
     */
    public void setCaseContact__c(java.lang.String caseContact__c) {
        this.caseContact__c = caseContact__c;
    }


    /**
     * Gets the caseNumber value for this _case.
     * 
     * @return caseNumber
     */
    public java.lang.String getCaseNumber() {
        return caseNumber;
    }


    /**
     * Sets the caseNumber value for this _case.
     * 
     * @param caseNumber
     */
    public void setCaseNumber(java.lang.String caseNumber) {
        this.caseNumber = caseNumber;
    }


    /**
     * Gets the caseRefund__r value for this _case.
     * 
     * @return caseRefund__r
     */
    public com.sforce.soap.enterprise.QueryResult getCaseRefund__r() {
        return caseRefund__r;
    }


    /**
     * Sets the caseRefund__r value for this _case.
     * 
     * @param caseRefund__r
     */
    public void setCaseRefund__r(com.sforce.soap.enterprise.QueryResult caseRefund__r) {
        this.caseRefund__r = caseRefund__r;
    }


    /**
     * Gets the caseSolutions value for this _case.
     * 
     * @return caseSolutions
     */
    public com.sforce.soap.enterprise.QueryResult getCaseSolutions() {
        return caseSolutions;
    }


    /**
     * Sets the caseSolutions value for this _case.
     * 
     * @param caseSolutions
     */
    public void setCaseSolutions(com.sforce.soap.enterprise.QueryResult caseSolutions) {
        this.caseSolutions = caseSolutions;
    }


    /**
     * Gets the cases value for this _case.
     * 
     * @return cases
     */
    public com.sforce.soap.enterprise.QueryResult getCases() {
        return cases;
    }


    /**
     * Sets the cases value for this _case.
     * 
     * @param cases
     */
    public void setCases(com.sforce.soap.enterprise.QueryResult cases) {
        this.cases = cases;
    }


    /**
     * Gets the closedDate value for this _case.
     * 
     * @return closedDate
     */
    public java.util.Calendar getClosedDate() {
        return closedDate;
    }


    /**
     * Sets the closedDate value for this _case.
     * 
     * @param closedDate
     */
    public void setClosedDate(java.util.Calendar closedDate) {
        this.closedDate = closedDate;
    }


    /**
     * Gets the contact value for this _case.
     * 
     * @return contact
     */
    public com.sforce.soap.enterprise.sobject.Contact getContact() {
        return contact;
    }


    /**
     * Sets the contact value for this _case.
     * 
     * @param contact
     */
    public void setContact(com.sforce.soap.enterprise.sobject.Contact contact) {
        this.contact = contact;
    }


    /**
     * Gets the contactId value for this _case.
     * 
     * @return contactId
     */
    public java.lang.String getContactId() {
        return contactId;
    }


    /**
     * Sets the contactId value for this _case.
     * 
     * @param contactId
     */
    public void setContactId(java.lang.String contactId) {
        this.contactId = contactId;
    }


    /**
     * Gets the createdBy value for this _case.
     * 
     * @return createdBy
     */
    public com.sforce.soap.enterprise.sobject.User getCreatedBy() {
        return createdBy;
    }


    /**
     * Sets the createdBy value for this _case.
     * 
     * @param createdBy
     */
    public void setCreatedBy(com.sforce.soap.enterprise.sobject.User createdBy) {
        this.createdBy = createdBy;
    }


    /**
     * Gets the createdById value for this _case.
     * 
     * @return createdById
     */
    public java.lang.String getCreatedById() {
        return createdById;
    }


    /**
     * Sets the createdById value for this _case.
     * 
     * @param createdById
     */
    public void setCreatedById(java.lang.String createdById) {
        this.createdById = createdById;
    }


    /**
     * Gets the createdDate value for this _case.
     * 
     * @return createdDate
     */
    public java.util.Calendar getCreatedDate() {
        return createdDate;
    }


    /**
     * Sets the createdDate value for this _case.
     * 
     * @param createdDate
     */
    public void setCreatedDate(java.util.Calendar createdDate) {
        this.createdDate = createdDate;
    }


    /**
     * Gets the customerRequire__c value for this _case.
     * 
     * @return customerRequire__c
     */
    public java.lang.String getCustomerRequire__c() {
        return customerRequire__c;
    }


    /**
     * Sets the customerRequire__c value for this _case.
     * 
     * @param customerRequire__c
     */
    public void setCustomerRequire__c(java.lang.String customerRequire__c) {
        this.customerRequire__c = customerRequire__c;
    }


    /**
     * Gets the dealID__c value for this _case.
     * 
     * @return dealID__c
     */
    public java.lang.String getDealID__c() {
        return dealID__c;
    }


    /**
     * Sets the dealID__c value for this _case.
     * 
     * @param dealID__c
     */
    public void setDealID__c(java.lang.String dealID__c) {
        this.dealID__c = dealID__c;
    }


    /**
     * Gets the dealName__c value for this _case.
     * 
     * @return dealName__c
     */
    public java.lang.String getDealName__c() {
        return dealName__c;
    }


    /**
     * Sets the dealName__c value for this _case.
     * 
     * @param dealName__c
     */
    public void setDealName__c(java.lang.String dealName__c) {
        this.dealName__c = dealName__c;
    }


    /**
     * Gets the description value for this _case.
     * 
     * @return description
     */
    public java.lang.String getDescription() {
        return description;
    }


    /**
     * Sets the description value for this _case.
     * 
     * @param description
     */
    public void setDescription(java.lang.String description) {
        this.description = description;
    }


    /**
     * Gets the description__c value for this _case.
     * 
     * @return description__c
     */
    public java.lang.String getDescription__c() {
        return description__c;
    }


    /**
     * Sets the description__c value for this _case.
     * 
     * @param description__c
     */
    public void setDescription__c(java.lang.String description__c) {
        this.description__c = description__c;
    }


    /**
     * Gets the events value for this _case.
     * 
     * @return events
     */
    public com.sforce.soap.enterprise.QueryResult getEvents() {
        return events;
    }


    /**
     * Sets the events value for this _case.
     * 
     * @param events
     */
    public void setEvents(com.sforce.soap.enterprise.QueryResult events) {
        this.events = events;
    }


    /**
     * Gets the histories value for this _case.
     * 
     * @return histories
     */
    public com.sforce.soap.enterprise.QueryResult getHistories() {
        return histories;
    }


    /**
     * Sets the histories value for this _case.
     * 
     * @param histories
     */
    public void setHistories(com.sforce.soap.enterprise.QueryResult histories) {
        this.histories = histories;
    }


    /**
     * Gets the isClosed value for this _case.
     * 
     * @return isClosed
     */
    public java.lang.Boolean getIsClosed() {
        return isClosed;
    }


    /**
     * Sets the isClosed value for this _case.
     * 
     * @param isClosed
     */
    public void setIsClosed(java.lang.Boolean isClosed) {
        this.isClosed = isClosed;
    }


    /**
     * Gets the isClosedOnCreate value for this _case.
     * 
     * @return isClosedOnCreate
     */
    public java.lang.Boolean getIsClosedOnCreate() {
        return isClosedOnCreate;
    }


    /**
     * Sets the isClosedOnCreate value for this _case.
     * 
     * @param isClosedOnCreate
     */
    public void setIsClosedOnCreate(java.lang.Boolean isClosedOnCreate) {
        this.isClosedOnCreate = isClosedOnCreate;
    }


    /**
     * Gets the isComplain__c value for this _case.
     * 
     * @return isComplain__c
     */
    public java.lang.Boolean getIsComplain__c() {
        return isComplain__c;
    }


    /**
     * Sets the isComplain__c value for this _case.
     * 
     * @param isComplain__c
     */
    public void setIsComplain__c(java.lang.Boolean isComplain__c) {
        this.isComplain__c = isComplain__c;
    }


    /**
     * Gets the isDeleted value for this _case.
     * 
     * @return isDeleted
     */
    public java.lang.Boolean getIsDeleted() {
        return isDeleted;
    }


    /**
     * Sets the isDeleted value for this _case.
     * 
     * @param isDeleted
     */
    public void setIsDeleted(java.lang.Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }


    /**
     * Gets the isEscalated value for this _case.
     * 
     * @return isEscalated
     */
    public java.lang.Boolean getIsEscalated() {
        return isEscalated;
    }


    /**
     * Sets the isEscalated value for this _case.
     * 
     * @param isEscalated
     */
    public void setIsEscalated(java.lang.Boolean isEscalated) {
        this.isEscalated = isEscalated;
    }


    /**
     * Gets the isNeedFollow__c value for this _case.
     * 
     * @return isNeedFollow__c
     */
    public java.lang.Boolean getIsNeedFollow__c() {
        return isNeedFollow__c;
    }


    /**
     * Sets the isNeedFollow__c value for this _case.
     * 
     * @param isNeedFollow__c
     */
    public void setIsNeedFollow__c(java.lang.Boolean isNeedFollow__c) {
        this.isNeedFollow__c = isNeedFollow__c;
    }


    /**
     * Gets the lastModifiedBy value for this _case.
     * 
     * @return lastModifiedBy
     */
    public com.sforce.soap.enterprise.sobject.User getLastModifiedBy() {
        return lastModifiedBy;
    }


    /**
     * Sets the lastModifiedBy value for this _case.
     * 
     * @param lastModifiedBy
     */
    public void setLastModifiedBy(com.sforce.soap.enterprise.sobject.User lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }


    /**
     * Gets the lastModifiedById value for this _case.
     * 
     * @return lastModifiedById
     */
    public java.lang.String getLastModifiedById() {
        return lastModifiedById;
    }


    /**
     * Sets the lastModifiedById value for this _case.
     * 
     * @param lastModifiedById
     */
    public void setLastModifiedById(java.lang.String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }


    /**
     * Gets the lastModifiedDate value for this _case.
     * 
     * @return lastModifiedDate
     */
    public java.util.Calendar getLastModifiedDate() {
        return lastModifiedDate;
    }


    /**
     * Sets the lastModifiedDate value for this _case.
     * 
     * @param lastModifiedDate
     */
    public void setLastModifiedDate(java.util.Calendar lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }


    /**
     * Gets the netBankAccountName__c value for this _case.
     * 
     * @return netBankAccountName__c
     */
    public java.lang.String getNetBankAccountName__c() {
        return netBankAccountName__c;
    }


    /**
     * Sets the netBankAccountName__c value for this _case.
     * 
     * @param netBankAccountName__c
     */
    public void setNetBankAccountName__c(java.lang.String netBankAccountName__c) {
        this.netBankAccountName__c = netBankAccountName__c;
    }


    /**
     * Gets the netBankAccoutNo__c value for this _case.
     * 
     * @return netBankAccoutNo__c
     */
    public java.lang.String getNetBankAccoutNo__c() {
        return netBankAccoutNo__c;
    }


    /**
     * Sets the netBankAccoutNo__c value for this _case.
     * 
     * @param netBankAccoutNo__c
     */
    public void setNetBankAccoutNo__c(java.lang.String netBankAccoutNo__c) {
        this.netBankAccoutNo__c = netBankAccoutNo__c;
    }


    /**
     * Gets the netBankName__c value for this _case.
     * 
     * @return netBankName__c
     */
    public java.lang.String getNetBankName__c() {
        return netBankName__c;
    }


    /**
     * Sets the netBankName__c value for this _case.
     * 
     * @param netBankName__c
     */
    public void setNetBankName__c(java.lang.String netBankName__c) {
        this.netBankName__c = netBankName__c;
    }


    /**
     * Gets the openActivities value for this _case.
     * 
     * @return openActivities
     */
    public com.sforce.soap.enterprise.QueryResult getOpenActivities() {
        return openActivities;
    }


    /**
     * Sets the openActivities value for this _case.
     * 
     * @param openActivities
     */
    public void setOpenActivities(com.sforce.soap.enterprise.QueryResult openActivities) {
        this.openActivities = openActivities;
    }


    /**
     * Gets the orderID__c value for this _case.
     * 
     * @return orderID__c
     */
    public java.lang.String getOrderID__c() {
        return orderID__c;
    }


    /**
     * Sets the orderID__c value for this _case.
     * 
     * @param orderID__c
     */
    public void setOrderID__c(java.lang.String orderID__c) {
        this.orderID__c = orderID__c;
    }


    /**
     * Gets the origin value for this _case.
     * 
     * @return origin
     */
    public java.lang.String getOrigin() {
        return origin;
    }


    /**
     * Sets the origin value for this _case.
     * 
     * @param origin
     */
    public void setOrigin(java.lang.String origin) {
        this.origin = origin;
    }


    /**
     * Gets the owner value for this _case.
     * 
     * @return owner
     */
    public com.sforce.soap.enterprise.sobject.Name getOwner() {
        return owner;
    }


    /**
     * Sets the owner value for this _case.
     * 
     * @param owner
     */
    public void setOwner(com.sforce.soap.enterprise.sobject.Name owner) {
        this.owner = owner;
    }


    /**
     * Gets the ownerId value for this _case.
     * 
     * @return ownerId
     */
    public java.lang.String getOwnerId() {
        return ownerId;
    }


    /**
     * Sets the ownerId value for this _case.
     * 
     * @param ownerId
     */
    public void setOwnerId(java.lang.String ownerId) {
        this.ownerId = ownerId;
    }


    /**
     * Gets the parent value for this _case.
     * 
     * @return parent
     */
    public com.sforce.soap.enterprise.sobject._case getParent() {
        return parent;
    }


    /**
     * Sets the parent value for this _case.
     * 
     * @param parent
     */
    public void setParent(com.sforce.soap.enterprise.sobject._case parent) {
        this.parent = parent;
    }


    /**
     * Gets the parentId value for this _case.
     * 
     * @return parentId
     */
    public java.lang.String getParentId() {
        return parentId;
    }


    /**
     * Sets the parentId value for this _case.
     * 
     * @param parentId
     */
    public void setParentId(java.lang.String parentId) {
        this.parentId = parentId;
    }


    /**
     * Gets the priority value for this _case.
     * 
     * @return priority
     */
    public java.lang.String getPriority() {
        return priority;
    }


    /**
     * Sets the priority value for this _case.
     * 
     * @param priority
     */
    public void setPriority(java.lang.String priority) {
        this.priority = priority;
    }


    /**
     * Gets the processInstances value for this _case.
     * 
     * @return processInstances
     */
    public com.sforce.soap.enterprise.QueryResult getProcessInstances() {
        return processInstances;
    }


    /**
     * Sets the processInstances value for this _case.
     * 
     * @param processInstances
     */
    public void setProcessInstances(com.sforce.soap.enterprise.QueryResult processInstances) {
        this.processInstances = processInstances;
    }


    /**
     * Gets the processSteps value for this _case.
     * 
     * @return processSteps
     */
    public com.sforce.soap.enterprise.QueryResult getProcessSteps() {
        return processSteps;
    }


    /**
     * Sets the processSteps value for this _case.
     * 
     * @param processSteps
     */
    public void setProcessSteps(com.sforce.soap.enterprise.QueryResult processSteps) {
        this.processSteps = processSteps;
    }


    /**
     * Gets the purchaseMobileNo__c value for this _case.
     * 
     * @return purchaseMobileNo__c
     */
    public java.lang.String getPurchaseMobileNo__c() {
        return purchaseMobileNo__c;
    }


    /**
     * Sets the purchaseMobileNo__c value for this _case.
     * 
     * @param purchaseMobileNo__c
     */
    public void setPurchaseMobileNo__c(java.lang.String purchaseMobileNo__c) {
        this.purchaseMobileNo__c = purchaseMobileNo__c;
    }


    /**
     * Gets the reason value for this _case.
     * 
     * @return reason
     */
    public java.lang.String getReason() {
        return reason;
    }


    /**
     * Sets the reason value for this _case.
     * 
     * @param reason
     */
    public void setReason(java.lang.String reason) {
        this.reason = reason;
    }


    /**
     * Gets the referURL__c value for this _case.
     * 
     * @return referURL__c
     */
    public java.lang.String getReferURL__c() {
        return referURL__c;
    }


    /**
     * Sets the referURL__c value for this _case.
     * 
     * @param referURL__c
     */
    public void setReferURL__c(java.lang.String referURL__c) {
        this.referURL__c = referURL__c;
    }


    /**
     * Gets the shares value for this _case.
     * 
     * @return shares
     */
    public com.sforce.soap.enterprise.QueryResult getShares() {
        return shares;
    }


    /**
     * Sets the shares value for this _case.
     * 
     * @param shares
     */
    public void setShares(com.sforce.soap.enterprise.QueryResult shares) {
        this.shares = shares;
    }


    /**
     * Gets the shipExpressInfo__c value for this _case.
     * 
     * @return shipExpressInfo__c
     */
    public java.lang.String getShipExpressInfo__c() {
        return shipExpressInfo__c;
    }


    /**
     * Sets the shipExpressInfo__c value for this _case.
     * 
     * @param shipExpressInfo__c
     */
    public void setShipExpressInfo__c(java.lang.String shipExpressInfo__c) {
        this.shipExpressInfo__c = shipExpressInfo__c;
    }


    /**
     * Gets the shipProductName__c value for this _case.
     * 
     * @return shipProductName__c
     */
    public java.lang.String getShipProductName__c() {
        return shipProductName__c;
    }


    /**
     * Sets the shipProductName__c value for this _case.
     * 
     * @param shipProductName__c
     */
    public void setShipProductName__c(java.lang.String shipProductName__c) {
        this.shipProductName__c = shipProductName__c;
    }


    /**
     * Gets the shopGroupID__c value for this _case.
     * 
     * @return shopGroupID__c
     */
    public java.lang.String getShopGroupID__c() {
        return shopGroupID__c;
    }


    /**
     * Sets the shopGroupID__c value for this _case.
     * 
     * @param shopGroupID__c
     */
    public void setShopGroupID__c(java.lang.String shopGroupID__c) {
        this.shopGroupID__c = shopGroupID__c;
    }


    /**
     * Gets the shopGroupName__c value for this _case.
     * 
     * @return shopGroupName__c
     */
    public java.lang.String getShopGroupName__c() {
        return shopGroupName__c;
    }


    /**
     * Sets the shopGroupName__c value for this _case.
     * 
     * @param shopGroupName__c
     */
    public void setShopGroupName__c(java.lang.String shopGroupName__c) {
        this.shopGroupName__c = shopGroupName__c;
    }


    /**
     * Gets the shopID__c value for this _case.
     * 
     * @return shopID__c
     */
    public java.lang.String getShopID__c() {
        return shopID__c;
    }


    /**
     * Sets the shopID__c value for this _case.
     * 
     * @param shopID__c
     */
    public void setShopID__c(java.lang.String shopID__c) {
        this.shopID__c = shopID__c;
    }


    /**
     * Gets the shopName__c value for this _case.
     * 
     * @return shopName__c
     */
    public java.lang.String getShopName__c() {
        return shopName__c;
    }


    /**
     * Sets the shopName__c value for this _case.
     * 
     * @param shopName__c
     */
    public void setShopName__c(java.lang.String shopName__c) {
        this.shopName__c = shopName__c;
    }


    /**
     * Gets the solutions value for this _case.
     * 
     * @return solutions
     */
    public com.sforce.soap.enterprise.QueryResult getSolutions() {
        return solutions;
    }


    /**
     * Sets the solutions value for this _case.
     * 
     * @param solutions
     */
    public void setSolutions(com.sforce.soap.enterprise.QueryResult solutions) {
        this.solutions = solutions;
    }


    /**
     * Gets the status value for this _case.
     * 
     * @return status
     */
    public java.lang.String getStatus() {
        return status;
    }


    /**
     * Sets the status value for this _case.
     * 
     * @param status
     */
    public void setStatus(java.lang.String status) {
        this.status = status;
    }


    /**
     * Gets the subType__c value for this _case.
     * 
     * @return subType__c
     */
    public java.lang.String getSubType__c() {
        return subType__c;
    }


    /**
     * Sets the subType__c value for this _case.
     * 
     * @param subType__c
     */
    public void setSubType__c(java.lang.String subType__c) {
        this.subType__c = subType__c;
    }


    /**
     * Gets the subject value for this _case.
     * 
     * @return subject
     */
    public java.lang.String getSubject() {
        return subject;
    }


    /**
     * Sets the subject value for this _case.
     * 
     * @param subject
     */
    public void setSubject(java.lang.String subject) {
        this.subject = subject;
    }


    /**
     * Gets the suppliedCompany value for this _case.
     * 
     * @return suppliedCompany
     */
    public java.lang.String getSuppliedCompany() {
        return suppliedCompany;
    }


    /**
     * Sets the suppliedCompany value for this _case.
     * 
     * @param suppliedCompany
     */
    public void setSuppliedCompany(java.lang.String suppliedCompany) {
        this.suppliedCompany = suppliedCompany;
    }


    /**
     * Gets the suppliedEmail value for this _case.
     * 
     * @return suppliedEmail
     */
    public java.lang.String getSuppliedEmail() {
        return suppliedEmail;
    }


    /**
     * Sets the suppliedEmail value for this _case.
     * 
     * @param suppliedEmail
     */
    public void setSuppliedEmail(java.lang.String suppliedEmail) {
        this.suppliedEmail = suppliedEmail;
    }


    /**
     * Gets the suppliedName value for this _case.
     * 
     * @return suppliedName
     */
    public java.lang.String getSuppliedName() {
        return suppliedName;
    }


    /**
     * Sets the suppliedName value for this _case.
     * 
     * @param suppliedName
     */
    public void setSuppliedName(java.lang.String suppliedName) {
        this.suppliedName = suppliedName;
    }


    /**
     * Gets the suppliedPhone value for this _case.
     * 
     * @return suppliedPhone
     */
    public java.lang.String getSuppliedPhone() {
        return suppliedPhone;
    }


    /**
     * Sets the suppliedPhone value for this _case.
     * 
     * @param suppliedPhone
     */
    public void setSuppliedPhone(java.lang.String suppliedPhone) {
        this.suppliedPhone = suppliedPhone;
    }


    /**
     * Gets the systemModstamp value for this _case.
     * 
     * @return systemModstamp
     */
    public java.util.Calendar getSystemModstamp() {
        return systemModstamp;
    }


    /**
     * Sets the systemModstamp value for this _case.
     * 
     * @param systemModstamp
     */
    public void setSystemModstamp(java.util.Calendar systemModstamp) {
        this.systemModstamp = systemModstamp;
    }


    /**
     * Gets the tasks value for this _case.
     * 
     * @return tasks
     */
    public com.sforce.soap.enterprise.QueryResult getTasks() {
        return tasks;
    }


    /**
     * Sets the tasks value for this _case.
     * 
     * @param tasks
     */
    public void setTasks(com.sforce.soap.enterprise.QueryResult tasks) {
        this.tasks = tasks;
    }


    /**
     * Gets the teamMembers value for this _case.
     * 
     * @return teamMembers
     */
    public com.sforce.soap.enterprise.QueryResult getTeamMembers() {
        return teamMembers;
    }


    /**
     * Sets the teamMembers value for this _case.
     * 
     * @param teamMembers
     */
    public void setTeamMembers(com.sforce.soap.enterprise.QueryResult teamMembers) {
        this.teamMembers = teamMembers;
    }


    /**
     * Gets the teamTemplateRecords value for this _case.
     * 
     * @return teamTemplateRecords
     */
    public com.sforce.soap.enterprise.QueryResult getTeamTemplateRecords() {
        return teamTemplateRecords;
    }


    /**
     * Sets the teamTemplateRecords value for this _case.
     * 
     * @param teamTemplateRecords
     */
    public void setTeamTemplateRecords(com.sforce.soap.enterprise.QueryResult teamTemplateRecords) {
        this.teamTemplateRecords = teamTemplateRecords;
    }


    /**
     * Gets the thirdPartSerialNo__c value for this _case.
     * 
     * @return thirdPartSerialNo__c
     */
    public java.lang.String getThirdPartSerialNo__c() {
        return thirdPartSerialNo__c;
    }


    /**
     * Sets the thirdPartSerialNo__c value for this _case.
     * 
     * @param thirdPartSerialNo__c
     */
    public void setThirdPartSerialNo__c(java.lang.String thirdPartSerialNo__c) {
        this.thirdPartSerialNo__c = thirdPartSerialNo__c;
    }


    /**
     * Gets the thirdSubType__c value for this _case.
     * 
     * @return thirdSubType__c
     */
    public java.lang.String getThirdSubType__c() {
        return thirdSubType__c;
    }


    /**
     * Sets the thirdSubType__c value for this _case.
     * 
     * @param thirdSubType__c
     */
    public void setThirdSubType__c(java.lang.String thirdSubType__c) {
        this.thirdSubType__c = thirdSubType__c;
    }


    /**
     * Gets the type value for this _case.
     * 
     * @return type
     */
    public java.lang.String getType() {
        return type;
    }


    /**
     * Sets the type value for this _case.
     * 
     * @param type
     */
    public void setType(java.lang.String type) {
        this.type = type;
    }


    /**
     * Gets the userAddress__c value for this _case.
     * 
     * @return userAddress__c
     */
    public java.lang.String getUserAddress__c() {
        return userAddress__c;
    }


    /**
     * Sets the userAddress__c value for this _case.
     * 
     * @param userAddress__c
     */
    public void setUserAddress__c(java.lang.String userAddress__c) {
        this.userAddress__c = userAddress__c;
    }


    /**
     * Gets the userCardNo__c value for this _case.
     * 
     * @return userCardNo__c
     */
    public java.lang.String getUserCardNo__c() {
        return userCardNo__c;
    }


    /**
     * Sets the userCardNo__c value for this _case.
     * 
     * @param userCardNo__c
     */
    public void setUserCardNo__c(java.lang.String userCardNo__c) {
        this.userCardNo__c = userCardNo__c;
    }


    /**
     * Gets the userEmail__c value for this _case.
     * 
     * @return userEmail__c
     */
    public java.lang.String getUserEmail__c() {
        return userEmail__c;
    }


    /**
     * Sets the userEmail__c value for this _case.
     * 
     * @param userEmail__c
     */
    public void setUserEmail__c(java.lang.String userEmail__c) {
        this.userEmail__c = userEmail__c;
    }


    /**
     * Gets the userID__c value for this _case.
     * 
     * @return userID__c
     */
    public java.lang.String getUserID__c() {
        return userID__c;
    }


    /**
     * Sets the userID__c value for this _case.
     * 
     * @param userID__c
     */
    public void setUserID__c(java.lang.String userID__c) {
        this.userID__c = userID__c;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof _case)) return false;
        _case other = (_case) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.account==null && other.getAccount()==null) || 
             (this.account!=null &&
              this.account.equals(other.getAccount()))) &&
            ((this.accountId==null && other.getAccountId()==null) || 
             (this.accountId!=null &&
              this.accountId.equals(other.getAccountId()))) &&
            ((this.activityHistories==null && other.getActivityHistories()==null) || 
             (this.activityHistories!=null &&
              this.activityHistories.equals(other.getActivityHistories()))) &&
            ((this.ageSect__c==null && other.getAgeSect__c()==null) || 
             (this.ageSect__c!=null &&
              this.ageSect__c.equals(other.getAgeSect__c()))) &&
            ((this.alipayAccountNo__c==null && other.getAlipayAccountNo__c()==null) || 
             (this.alipayAccountNo__c!=null &&
              this.alipayAccountNo__c.equals(other.getAlipayAccountNo__c()))) &&
            ((this.asset==null && other.getAsset()==null) || 
             (this.asset!=null &&
              this.asset.equals(other.getAsset()))) &&
            ((this.assetId==null && other.getAssetId()==null) || 
             (this.assetId!=null &&
              this.assetId.equals(other.getAssetId()))) &&
            ((this.attachments==null && other.getAttachments()==null) || 
             (this.attachments!=null &&
              this.attachments.equals(other.getAttachments()))) &&
            ((this.bookContact__c==null && other.getBookContact__c()==null) || 
             (this.bookContact__c!=null &&
              this.bookContact__c.equals(other.getBookContact__c()))) &&
            ((this.bookDate__c==null && other.getBookDate__c()==null) || 
             (this.bookDate__c!=null &&
              this.bookDate__c.equals(other.getBookDate__c()))) &&
            ((this.bookPerson__c==null && other.getBookPerson__c()==null) || 
             (this.bookPerson__c!=null &&
              this.bookPerson__c.equals(other.getBookPerson__c()))) &&
            ((this.businessHours==null && other.getBusinessHours()==null) || 
             (this.businessHours!=null &&
              this.businessHours.equals(other.getBusinessHours()))) &&
            ((this.businessHoursId==null && other.getBusinessHoursId()==null) || 
             (this.businessHoursId!=null &&
              this.businessHoursId.equals(other.getBusinessHoursId()))) &&
            ((this.caseComments==null && other.getCaseComments()==null) || 
             (this.caseComments!=null &&
              this.caseComments.equals(other.getCaseComments()))) &&
            ((this.caseContactRoles==null && other.getCaseContactRoles()==null) || 
             (this.caseContactRoles!=null &&
              this.caseContactRoles.equals(other.getCaseContactRoles()))) &&
            ((this.caseContactWay__c==null && other.getCaseContactWay__c()==null) || 
             (this.caseContactWay__c!=null &&
              this.caseContactWay__c.equals(other.getCaseContactWay__c()))) &&
            ((this.caseContact__c==null && other.getCaseContact__c()==null) || 
             (this.caseContact__c!=null &&
              this.caseContact__c.equals(other.getCaseContact__c()))) &&
            ((this.caseNumber==null && other.getCaseNumber()==null) || 
             (this.caseNumber!=null &&
              this.caseNumber.equals(other.getCaseNumber()))) &&
            ((this.caseRefund__r==null && other.getCaseRefund__r()==null) || 
             (this.caseRefund__r!=null &&
              this.caseRefund__r.equals(other.getCaseRefund__r()))) &&
            ((this.caseSolutions==null && other.getCaseSolutions()==null) || 
             (this.caseSolutions!=null &&
              this.caseSolutions.equals(other.getCaseSolutions()))) &&
            ((this.cases==null && other.getCases()==null) || 
             (this.cases!=null &&
              this.cases.equals(other.getCases()))) &&
            ((this.closedDate==null && other.getClosedDate()==null) || 
             (this.closedDate!=null &&
              this.closedDate.equals(other.getClosedDate()))) &&
            ((this.contact==null && other.getContact()==null) || 
             (this.contact!=null &&
              this.contact.equals(other.getContact()))) &&
            ((this.contactId==null && other.getContactId()==null) || 
             (this.contactId!=null &&
              this.contactId.equals(other.getContactId()))) &&
            ((this.createdBy==null && other.getCreatedBy()==null) || 
             (this.createdBy!=null &&
              this.createdBy.equals(other.getCreatedBy()))) &&
            ((this.createdById==null && other.getCreatedById()==null) || 
             (this.createdById!=null &&
              this.createdById.equals(other.getCreatedById()))) &&
            ((this.createdDate==null && other.getCreatedDate()==null) || 
             (this.createdDate!=null &&
              this.createdDate.equals(other.getCreatedDate()))) &&
            ((this.customerRequire__c==null && other.getCustomerRequire__c()==null) || 
             (this.customerRequire__c!=null &&
              this.customerRequire__c.equals(other.getCustomerRequire__c()))) &&
            ((this.dealID__c==null && other.getDealID__c()==null) || 
             (this.dealID__c!=null &&
              this.dealID__c.equals(other.getDealID__c()))) &&
            ((this.dealName__c==null && other.getDealName__c()==null) || 
             (this.dealName__c!=null &&
              this.dealName__c.equals(other.getDealName__c()))) &&
            ((this.description==null && other.getDescription()==null) || 
             (this.description!=null &&
              this.description.equals(other.getDescription()))) &&
            ((this.description__c==null && other.getDescription__c()==null) || 
             (this.description__c!=null &&
              this.description__c.equals(other.getDescription__c()))) &&
            ((this.events==null && other.getEvents()==null) || 
             (this.events!=null &&
              this.events.equals(other.getEvents()))) &&
            ((this.histories==null && other.getHistories()==null) || 
             (this.histories!=null &&
              this.histories.equals(other.getHistories()))) &&
            ((this.isClosed==null && other.getIsClosed()==null) || 
             (this.isClosed!=null &&
              this.isClosed.equals(other.getIsClosed()))) &&
            ((this.isClosedOnCreate==null && other.getIsClosedOnCreate()==null) || 
             (this.isClosedOnCreate!=null &&
              this.isClosedOnCreate.equals(other.getIsClosedOnCreate()))) &&
            ((this.isComplain__c==null && other.getIsComplain__c()==null) || 
             (this.isComplain__c!=null &&
              this.isComplain__c.equals(other.getIsComplain__c()))) &&
            ((this.isDeleted==null && other.getIsDeleted()==null) || 
             (this.isDeleted!=null &&
              this.isDeleted.equals(other.getIsDeleted()))) &&
            ((this.isEscalated==null && other.getIsEscalated()==null) || 
             (this.isEscalated!=null &&
              this.isEscalated.equals(other.getIsEscalated()))) &&
            ((this.isNeedFollow__c==null && other.getIsNeedFollow__c()==null) || 
             (this.isNeedFollow__c!=null &&
              this.isNeedFollow__c.equals(other.getIsNeedFollow__c()))) &&
            ((this.lastModifiedBy==null && other.getLastModifiedBy()==null) || 
             (this.lastModifiedBy!=null &&
              this.lastModifiedBy.equals(other.getLastModifiedBy()))) &&
            ((this.lastModifiedById==null && other.getLastModifiedById()==null) || 
             (this.lastModifiedById!=null &&
              this.lastModifiedById.equals(other.getLastModifiedById()))) &&
            ((this.lastModifiedDate==null && other.getLastModifiedDate()==null) || 
             (this.lastModifiedDate!=null &&
              this.lastModifiedDate.equals(other.getLastModifiedDate()))) &&
            ((this.netBankAccountName__c==null && other.getNetBankAccountName__c()==null) || 
             (this.netBankAccountName__c!=null &&
              this.netBankAccountName__c.equals(other.getNetBankAccountName__c()))) &&
            ((this.netBankAccoutNo__c==null && other.getNetBankAccoutNo__c()==null) || 
             (this.netBankAccoutNo__c!=null &&
              this.netBankAccoutNo__c.equals(other.getNetBankAccoutNo__c()))) &&
            ((this.netBankName__c==null && other.getNetBankName__c()==null) || 
             (this.netBankName__c!=null &&
              this.netBankName__c.equals(other.getNetBankName__c()))) &&
            ((this.openActivities==null && other.getOpenActivities()==null) || 
             (this.openActivities!=null &&
              this.openActivities.equals(other.getOpenActivities()))) &&
            ((this.orderID__c==null && other.getOrderID__c()==null) || 
             (this.orderID__c!=null &&
              this.orderID__c.equals(other.getOrderID__c()))) &&
            ((this.origin==null && other.getOrigin()==null) || 
             (this.origin!=null &&
              this.origin.equals(other.getOrigin()))) &&
            ((this.owner==null && other.getOwner()==null) || 
             (this.owner!=null &&
              this.owner.equals(other.getOwner()))) &&
            ((this.ownerId==null && other.getOwnerId()==null) || 
             (this.ownerId!=null &&
              this.ownerId.equals(other.getOwnerId()))) &&
            ((this.parent==null && other.getParent()==null) || 
             (this.parent!=null &&
              this.parent.equals(other.getParent()))) &&
            ((this.parentId==null && other.getParentId()==null) || 
             (this.parentId!=null &&
              this.parentId.equals(other.getParentId()))) &&
            ((this.priority==null && other.getPriority()==null) || 
             (this.priority!=null &&
              this.priority.equals(other.getPriority()))) &&
            ((this.processInstances==null && other.getProcessInstances()==null) || 
             (this.processInstances!=null &&
              this.processInstances.equals(other.getProcessInstances()))) &&
            ((this.processSteps==null && other.getProcessSteps()==null) || 
             (this.processSteps!=null &&
              this.processSteps.equals(other.getProcessSteps()))) &&
            ((this.purchaseMobileNo__c==null && other.getPurchaseMobileNo__c()==null) || 
             (this.purchaseMobileNo__c!=null &&
              this.purchaseMobileNo__c.equals(other.getPurchaseMobileNo__c()))) &&
            ((this.reason==null && other.getReason()==null) || 
             (this.reason!=null &&
              this.reason.equals(other.getReason()))) &&
            ((this.referURL__c==null && other.getReferURL__c()==null) || 
             (this.referURL__c!=null &&
              this.referURL__c.equals(other.getReferURL__c()))) &&
            ((this.shares==null && other.getShares()==null) || 
             (this.shares!=null &&
              this.shares.equals(other.getShares()))) &&
            ((this.shipExpressInfo__c==null && other.getShipExpressInfo__c()==null) || 
             (this.shipExpressInfo__c!=null &&
              this.shipExpressInfo__c.equals(other.getShipExpressInfo__c()))) &&
            ((this.shipProductName__c==null && other.getShipProductName__c()==null) || 
             (this.shipProductName__c!=null &&
              this.shipProductName__c.equals(other.getShipProductName__c()))) &&
            ((this.shopGroupID__c==null && other.getShopGroupID__c()==null) || 
             (this.shopGroupID__c!=null &&
              this.shopGroupID__c.equals(other.getShopGroupID__c()))) &&
            ((this.shopGroupName__c==null && other.getShopGroupName__c()==null) || 
             (this.shopGroupName__c!=null &&
              this.shopGroupName__c.equals(other.getShopGroupName__c()))) &&
            ((this.shopID__c==null && other.getShopID__c()==null) || 
             (this.shopID__c!=null &&
              this.shopID__c.equals(other.getShopID__c()))) &&
            ((this.shopName__c==null && other.getShopName__c()==null) || 
             (this.shopName__c!=null &&
              this.shopName__c.equals(other.getShopName__c()))) &&
            ((this.solutions==null && other.getSolutions()==null) || 
             (this.solutions!=null &&
              this.solutions.equals(other.getSolutions()))) &&
            ((this.status==null && other.getStatus()==null) || 
             (this.status!=null &&
              this.status.equals(other.getStatus()))) &&
            ((this.subType__c==null && other.getSubType__c()==null) || 
             (this.subType__c!=null &&
              this.subType__c.equals(other.getSubType__c()))) &&
            ((this.subject==null && other.getSubject()==null) || 
             (this.subject!=null &&
              this.subject.equals(other.getSubject()))) &&
            ((this.suppliedCompany==null && other.getSuppliedCompany()==null) || 
             (this.suppliedCompany!=null &&
              this.suppliedCompany.equals(other.getSuppliedCompany()))) &&
            ((this.suppliedEmail==null && other.getSuppliedEmail()==null) || 
             (this.suppliedEmail!=null &&
              this.suppliedEmail.equals(other.getSuppliedEmail()))) &&
            ((this.suppliedName==null && other.getSuppliedName()==null) || 
             (this.suppliedName!=null &&
              this.suppliedName.equals(other.getSuppliedName()))) &&
            ((this.suppliedPhone==null && other.getSuppliedPhone()==null) || 
             (this.suppliedPhone!=null &&
              this.suppliedPhone.equals(other.getSuppliedPhone()))) &&
            ((this.systemModstamp==null && other.getSystemModstamp()==null) || 
             (this.systemModstamp!=null &&
              this.systemModstamp.equals(other.getSystemModstamp()))) &&
            ((this.tasks==null && other.getTasks()==null) || 
             (this.tasks!=null &&
              this.tasks.equals(other.getTasks()))) &&
            ((this.teamMembers==null && other.getTeamMembers()==null) || 
             (this.teamMembers!=null &&
              this.teamMembers.equals(other.getTeamMembers()))) &&
            ((this.teamTemplateRecords==null && other.getTeamTemplateRecords()==null) || 
             (this.teamTemplateRecords!=null &&
              this.teamTemplateRecords.equals(other.getTeamTemplateRecords()))) &&
            ((this.thirdPartSerialNo__c==null && other.getThirdPartSerialNo__c()==null) || 
             (this.thirdPartSerialNo__c!=null &&
              this.thirdPartSerialNo__c.equals(other.getThirdPartSerialNo__c()))) &&
            ((this.thirdSubType__c==null && other.getThirdSubType__c()==null) || 
             (this.thirdSubType__c!=null &&
              this.thirdSubType__c.equals(other.getThirdSubType__c()))) &&
            ((this.type==null && other.getType()==null) || 
             (this.type!=null &&
              this.type.equals(other.getType()))) &&
            ((this.userAddress__c==null && other.getUserAddress__c()==null) || 
             (this.userAddress__c!=null &&
              this.userAddress__c.equals(other.getUserAddress__c()))) &&
            ((this.userCardNo__c==null && other.getUserCardNo__c()==null) || 
             (this.userCardNo__c!=null &&
              this.userCardNo__c.equals(other.getUserCardNo__c()))) &&
            ((this.userEmail__c==null && other.getUserEmail__c()==null) || 
             (this.userEmail__c!=null &&
              this.userEmail__c.equals(other.getUserEmail__c()))) &&
            ((this.userID__c==null && other.getUserID__c()==null) || 
             (this.userID__c!=null &&
              this.userID__c.equals(other.getUserID__c())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAccount() != null) {
            _hashCode += getAccount().hashCode();
        }
        if (getAccountId() != null) {
            _hashCode += getAccountId().hashCode();
        }
        if (getActivityHistories() != null) {
            _hashCode += getActivityHistories().hashCode();
        }
        if (getAgeSect__c() != null) {
            _hashCode += getAgeSect__c().hashCode();
        }
        if (getAlipayAccountNo__c() != null) {
            _hashCode += getAlipayAccountNo__c().hashCode();
        }
        if (getAsset() != null) {
            _hashCode += getAsset().hashCode();
        }
        if (getAssetId() != null) {
            _hashCode += getAssetId().hashCode();
        }
        if (getAttachments() != null) {
            _hashCode += getAttachments().hashCode();
        }
        if (getBookContact__c() != null) {
            _hashCode += getBookContact__c().hashCode();
        }
        if (getBookDate__c() != null) {
            _hashCode += getBookDate__c().hashCode();
        }
        if (getBookPerson__c() != null) {
            _hashCode += getBookPerson__c().hashCode();
        }
        if (getBusinessHours() != null) {
            _hashCode += getBusinessHours().hashCode();
        }
        if (getBusinessHoursId() != null) {
            _hashCode += getBusinessHoursId().hashCode();
        }
        if (getCaseComments() != null) {
            _hashCode += getCaseComments().hashCode();
        }
        if (getCaseContactRoles() != null) {
            _hashCode += getCaseContactRoles().hashCode();
        }
        if (getCaseContactWay__c() != null) {
            _hashCode += getCaseContactWay__c().hashCode();
        }
        if (getCaseContact__c() != null) {
            _hashCode += getCaseContact__c().hashCode();
        }
        if (getCaseNumber() != null) {
            _hashCode += getCaseNumber().hashCode();
        }
        if (getCaseRefund__r() != null) {
            _hashCode += getCaseRefund__r().hashCode();
        }
        if (getCaseSolutions() != null) {
            _hashCode += getCaseSolutions().hashCode();
        }
        if (getCases() != null) {
            _hashCode += getCases().hashCode();
        }
        if (getClosedDate() != null) {
            _hashCode += getClosedDate().hashCode();
        }
        if (getContact() != null) {
            _hashCode += getContact().hashCode();
        }
        if (getContactId() != null) {
            _hashCode += getContactId().hashCode();
        }
        if (getCreatedBy() != null) {
            _hashCode += getCreatedBy().hashCode();
        }
        if (getCreatedById() != null) {
            _hashCode += getCreatedById().hashCode();
        }
        if (getCreatedDate() != null) {
            _hashCode += getCreatedDate().hashCode();
        }
        if (getCustomerRequire__c() != null) {
            _hashCode += getCustomerRequire__c().hashCode();
        }
        if (getDealID__c() != null) {
            _hashCode += getDealID__c().hashCode();
        }
        if (getDealName__c() != null) {
            _hashCode += getDealName__c().hashCode();
        }
        if (getDescription() != null) {
            _hashCode += getDescription().hashCode();
        }
        if (getDescription__c() != null) {
            _hashCode += getDescription__c().hashCode();
        }
        if (getEvents() != null) {
            _hashCode += getEvents().hashCode();
        }
        if (getHistories() != null) {
            _hashCode += getHistories().hashCode();
        }
        if (getIsClosed() != null) {
            _hashCode += getIsClosed().hashCode();
        }
        if (getIsClosedOnCreate() != null) {
            _hashCode += getIsClosedOnCreate().hashCode();
        }
        if (getIsComplain__c() != null) {
            _hashCode += getIsComplain__c().hashCode();
        }
        if (getIsDeleted() != null) {
            _hashCode += getIsDeleted().hashCode();
        }
        if (getIsEscalated() != null) {
            _hashCode += getIsEscalated().hashCode();
        }
        if (getIsNeedFollow__c() != null) {
            _hashCode += getIsNeedFollow__c().hashCode();
        }
        if (getLastModifiedBy() != null) {
            _hashCode += getLastModifiedBy().hashCode();
        }
        if (getLastModifiedById() != null) {
            _hashCode += getLastModifiedById().hashCode();
        }
        if (getLastModifiedDate() != null) {
            _hashCode += getLastModifiedDate().hashCode();
        }
        if (getNetBankAccountName__c() != null) {
            _hashCode += getNetBankAccountName__c().hashCode();
        }
        if (getNetBankAccoutNo__c() != null) {
            _hashCode += getNetBankAccoutNo__c().hashCode();
        }
        if (getNetBankName__c() != null) {
            _hashCode += getNetBankName__c().hashCode();
        }
        if (getOpenActivities() != null) {
            _hashCode += getOpenActivities().hashCode();
        }
        if (getOrderID__c() != null) {
            _hashCode += getOrderID__c().hashCode();
        }
        if (getOrigin() != null) {
            _hashCode += getOrigin().hashCode();
        }
        if (getOwner() != null) {
            _hashCode += getOwner().hashCode();
        }
        if (getOwnerId() != null) {
            _hashCode += getOwnerId().hashCode();
        }
        if (getParent() != null) {
            _hashCode += getParent().hashCode();
        }
        if (getParentId() != null) {
            _hashCode += getParentId().hashCode();
        }
        if (getPriority() != null) {
            _hashCode += getPriority().hashCode();
        }
        if (getProcessInstances() != null) {
            _hashCode += getProcessInstances().hashCode();
        }
        if (getProcessSteps() != null) {
            _hashCode += getProcessSteps().hashCode();
        }
        if (getPurchaseMobileNo__c() != null) {
            _hashCode += getPurchaseMobileNo__c().hashCode();
        }
        if (getReason() != null) {
            _hashCode += getReason().hashCode();
        }
        if (getReferURL__c() != null) {
            _hashCode += getReferURL__c().hashCode();
        }
        if (getShares() != null) {
            _hashCode += getShares().hashCode();
        }
        if (getShipExpressInfo__c() != null) {
            _hashCode += getShipExpressInfo__c().hashCode();
        }
        if (getShipProductName__c() != null) {
            _hashCode += getShipProductName__c().hashCode();
        }
        if (getShopGroupID__c() != null) {
            _hashCode += getShopGroupID__c().hashCode();
        }
        if (getShopGroupName__c() != null) {
            _hashCode += getShopGroupName__c().hashCode();
        }
        if (getShopID__c() != null) {
            _hashCode += getShopID__c().hashCode();
        }
        if (getShopName__c() != null) {
            _hashCode += getShopName__c().hashCode();
        }
        if (getSolutions() != null) {
            _hashCode += getSolutions().hashCode();
        }
        if (getStatus() != null) {
            _hashCode += getStatus().hashCode();
        }
        if (getSubType__c() != null) {
            _hashCode += getSubType__c().hashCode();
        }
        if (getSubject() != null) {
            _hashCode += getSubject().hashCode();
        }
        if (getSuppliedCompany() != null) {
            _hashCode += getSuppliedCompany().hashCode();
        }
        if (getSuppliedEmail() != null) {
            _hashCode += getSuppliedEmail().hashCode();
        }
        if (getSuppliedName() != null) {
            _hashCode += getSuppliedName().hashCode();
        }
        if (getSuppliedPhone() != null) {
            _hashCode += getSuppliedPhone().hashCode();
        }
        if (getSystemModstamp() != null) {
            _hashCode += getSystemModstamp().hashCode();
        }
        if (getTasks() != null) {
            _hashCode += getTasks().hashCode();
        }
        if (getTeamMembers() != null) {
            _hashCode += getTeamMembers().hashCode();
        }
        if (getTeamTemplateRecords() != null) {
            _hashCode += getTeamTemplateRecords().hashCode();
        }
        if (getThirdPartSerialNo__c() != null) {
            _hashCode += getThirdPartSerialNo__c().hashCode();
        }
        if (getThirdSubType__c() != null) {
            _hashCode += getThirdSubType__c().hashCode();
        }
        if (getType() != null) {
            _hashCode += getType().hashCode();
        }
        if (getUserAddress__c() != null) {
            _hashCode += getUserAddress__c().hashCode();
        }
        if (getUserCardNo__c() != null) {
            _hashCode += getUserCardNo__c().hashCode();
        }
        if (getUserEmail__c() != null) {
            _hashCode += getUserEmail__c().hashCode();
        }
        if (getUserID__c() != null) {
            _hashCode += getUserID__c().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(_case.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Case"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("account");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Account"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Account"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accountId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AccountId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("activityHistories");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ActivityHistories"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ageSect__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AgeSect__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("alipayAccountNo__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AlipayAccountNo__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("asset");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Asset"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Asset"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("assetId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AssetId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Attachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bookContact__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BookContact__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bookDate__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BookDate__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bookPerson__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BookPerson__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("businessHours");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BusinessHours"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BusinessHours"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("businessHoursId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BusinessHoursId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("caseComments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CaseComments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("caseContactRoles");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CaseContactRoles"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("caseContactWay__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CaseContactWay__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("caseContact__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CaseContact__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("caseNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CaseNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("caseRefund__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CaseRefund__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("caseSolutions");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CaseSolutions"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cases");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Cases"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("closedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ClosedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contact");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Contact"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Contact"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contactId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ContactId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("customerRequire__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CustomerRequire__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dealID__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DealID__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dealName__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DealName__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Description__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("events");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Events"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("histories");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Histories"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isClosed");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsClosed"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isClosedOnCreate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsClosedOnCreate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isComplain__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsComplain__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isDeleted");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsDeleted"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isEscalated");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsEscalated"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isNeedFollow__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsNeedFollow__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("netBankAccountName__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NetBankAccountName__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("netBankAccoutNo__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NetBankAccoutNo__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("netBankName__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NetBankName__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("openActivities");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OpenActivities"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderID__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OrderID__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("origin");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Origin"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("owner");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Owner"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ownerId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OwnerId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("parent");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Parent"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Case"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("parentId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ParentId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("priority");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Priority"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processInstances");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessInstances"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processSteps");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessSteps"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("purchaseMobileNo__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PurchaseMobileNo__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reason");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Reason"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("referURL__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ReferURL__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shares");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Shares"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shipExpressInfo__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ShipExpressInfo__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shipProductName__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ShipProductName__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shopGroupID__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ShopGroupID__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shopGroupName__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ShopGroupName__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shopID__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ShopID__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shopName__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ShopName__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("solutions");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Solutions"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("status");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("subType__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SubType__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("subject");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Subject"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("suppliedCompany");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SuppliedCompany"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("suppliedEmail");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SuppliedEmail"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("suppliedName");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SuppliedName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("suppliedPhone");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SuppliedPhone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("systemModstamp");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SystemModstamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tasks");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Tasks"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("teamMembers");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TeamMembers"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("teamTemplateRecords");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TeamTemplateRecords"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("thirdPartSerialNo__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ThirdPartSerialNo__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("thirdSubType__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ThirdSubType__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("type");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userAddress__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserAddress__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userCardNo__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserCardNo__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userEmail__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserEmail__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userID__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserID__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
