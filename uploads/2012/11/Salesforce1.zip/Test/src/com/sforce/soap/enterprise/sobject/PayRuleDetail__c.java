/**
 * PayRuleDetail__c.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.sforce.soap.enterprise.sobject;

public class PayRuleDetail__c  extends com.sforce.soap.enterprise.sobject.SObject  implements java.io.Serializable {
    private com.sforce.soap.enterprise.QueryResult attachments;

    private com.sforce.soap.enterprise.sobject.User createdBy;

    private java.lang.String createdById;

    private java.util.Calendar createdDate;

    private java.lang.Double firstPaymentDay__c;

    private java.util.Calendar fixedDate__c;

    private com.sforce.soap.enterprise.QueryResult histories;

    private java.lang.Double interval__c;

    private java.lang.Boolean isDeleted;

    private com.sforce.soap.enterprise.sobject.User lastModifiedBy;

    private java.lang.String lastModifiedById;

    private java.util.Calendar lastModifiedDate;

    private java.lang.Double monthNumber__c;

    private java.lang.String name;

    private com.sforce.soap.enterprise.QueryResult notes;

    private com.sforce.soap.enterprise.QueryResult notesAndAttachments;

    private java.lang.Double payBalance__c;

    private java.lang.String payRule__c;

    private com.sforce.soap.enterprise.sobject.PayRule__c payRule__r;

    private java.lang.Double paymentAmount__c;

    private java.lang.Double paymentCouponNumber__c;

    private java.lang.Double paymentPercentage__c;

    private java.lang.Double paymentTimePoint__c;

    private com.sforce.soap.enterprise.QueryResult processInstances;

    private com.sforce.soap.enterprise.QueryResult processSteps;

    private java.lang.Double secondPaymentDay__c;

    private java.lang.Double seqence__c;

    private java.lang.Double settlementPrice__c;

    private java.lang.Double stagePayType__c;

    private java.lang.Double stage__c;

    private java.util.Calendar systemModstamp;

    private java.lang.Double usagePercentage__c;

    private java.lang.Double workdayNumber__c;

    public PayRuleDetail__c() {
    }

    public PayRuleDetail__c(
           java.lang.String[] fieldsToNull,
           java.lang.String id,
           com.sforce.soap.enterprise.QueryResult attachments,
           com.sforce.soap.enterprise.sobject.User createdBy,
           java.lang.String createdById,
           java.util.Calendar createdDate,
           java.lang.Double firstPaymentDay__c,
           java.util.Calendar fixedDate__c,
           com.sforce.soap.enterprise.QueryResult histories,
           java.lang.Double interval__c,
           java.lang.Boolean isDeleted,
           com.sforce.soap.enterprise.sobject.User lastModifiedBy,
           java.lang.String lastModifiedById,
           java.util.Calendar lastModifiedDate,
           java.lang.Double monthNumber__c,
           java.lang.String name,
           com.sforce.soap.enterprise.QueryResult notes,
           com.sforce.soap.enterprise.QueryResult notesAndAttachments,
           java.lang.Double payBalance__c,
           java.lang.String payRule__c,
           com.sforce.soap.enterprise.sobject.PayRule__c payRule__r,
           java.lang.Double paymentAmount__c,
           java.lang.Double paymentCouponNumber__c,
           java.lang.Double paymentPercentage__c,
           java.lang.Double paymentTimePoint__c,
           com.sforce.soap.enterprise.QueryResult processInstances,
           com.sforce.soap.enterprise.QueryResult processSteps,
           java.lang.Double secondPaymentDay__c,
           java.lang.Double seqence__c,
           java.lang.Double settlementPrice__c,
           java.lang.Double stagePayType__c,
           java.lang.Double stage__c,
           java.util.Calendar systemModstamp,
           java.lang.Double usagePercentage__c,
           java.lang.Double workdayNumber__c) {
        super(
            fieldsToNull,
            id);
        this.attachments = attachments;
        this.createdBy = createdBy;
        this.createdById = createdById;
        this.createdDate = createdDate;
        this.firstPaymentDay__c = firstPaymentDay__c;
        this.fixedDate__c = fixedDate__c;
        this.histories = histories;
        this.interval__c = interval__c;
        this.isDeleted = isDeleted;
        this.lastModifiedBy = lastModifiedBy;
        this.lastModifiedById = lastModifiedById;
        this.lastModifiedDate = lastModifiedDate;
        this.monthNumber__c = monthNumber__c;
        this.name = name;
        this.notes = notes;
        this.notesAndAttachments = notesAndAttachments;
        this.payBalance__c = payBalance__c;
        this.payRule__c = payRule__c;
        this.payRule__r = payRule__r;
        this.paymentAmount__c = paymentAmount__c;
        this.paymentCouponNumber__c = paymentCouponNumber__c;
        this.paymentPercentage__c = paymentPercentage__c;
        this.paymentTimePoint__c = paymentTimePoint__c;
        this.processInstances = processInstances;
        this.processSteps = processSteps;
        this.secondPaymentDay__c = secondPaymentDay__c;
        this.seqence__c = seqence__c;
        this.settlementPrice__c = settlementPrice__c;
        this.stagePayType__c = stagePayType__c;
        this.stage__c = stage__c;
        this.systemModstamp = systemModstamp;
        this.usagePercentage__c = usagePercentage__c;
        this.workdayNumber__c = workdayNumber__c;
    }


    /**
     * Gets the attachments value for this PayRuleDetail__c.
     * 
     * @return attachments
     */
    public com.sforce.soap.enterprise.QueryResult getAttachments() {
        return attachments;
    }


    /**
     * Sets the attachments value for this PayRuleDetail__c.
     * 
     * @param attachments
     */
    public void setAttachments(com.sforce.soap.enterprise.QueryResult attachments) {
        this.attachments = attachments;
    }


    /**
     * Gets the createdBy value for this PayRuleDetail__c.
     * 
     * @return createdBy
     */
    public com.sforce.soap.enterprise.sobject.User getCreatedBy() {
        return createdBy;
    }


    /**
     * Sets the createdBy value for this PayRuleDetail__c.
     * 
     * @param createdBy
     */
    public void setCreatedBy(com.sforce.soap.enterprise.sobject.User createdBy) {
        this.createdBy = createdBy;
    }


    /**
     * Gets the createdById value for this PayRuleDetail__c.
     * 
     * @return createdById
     */
    public java.lang.String getCreatedById() {
        return createdById;
    }


    /**
     * Sets the createdById value for this PayRuleDetail__c.
     * 
     * @param createdById
     */
    public void setCreatedById(java.lang.String createdById) {
        this.createdById = createdById;
    }


    /**
     * Gets the createdDate value for this PayRuleDetail__c.
     * 
     * @return createdDate
     */
    public java.util.Calendar getCreatedDate() {
        return createdDate;
    }


    /**
     * Sets the createdDate value for this PayRuleDetail__c.
     * 
     * @param createdDate
     */
    public void setCreatedDate(java.util.Calendar createdDate) {
        this.createdDate = createdDate;
    }


    /**
     * Gets the firstPaymentDay__c value for this PayRuleDetail__c.
     * 
     * @return firstPaymentDay__c
     */
    public java.lang.Double getFirstPaymentDay__c() {
        return firstPaymentDay__c;
    }


    /**
     * Sets the firstPaymentDay__c value for this PayRuleDetail__c.
     * 
     * @param firstPaymentDay__c
     */
    public void setFirstPaymentDay__c(java.lang.Double firstPaymentDay__c) {
        this.firstPaymentDay__c = firstPaymentDay__c;
    }


    /**
     * Gets the fixedDate__c value for this PayRuleDetail__c.
     * 
     * @return fixedDate__c
     */
    public java.util.Calendar getFixedDate__c() {
        return fixedDate__c;
    }


    /**
     * Sets the fixedDate__c value for this PayRuleDetail__c.
     * 
     * @param fixedDate__c
     */
    public void setFixedDate__c(java.util.Calendar fixedDate__c) {
        this.fixedDate__c = fixedDate__c;
    }


    /**
     * Gets the histories value for this PayRuleDetail__c.
     * 
     * @return histories
     */
    public com.sforce.soap.enterprise.QueryResult getHistories() {
        return histories;
    }


    /**
     * Sets the histories value for this PayRuleDetail__c.
     * 
     * @param histories
     */
    public void setHistories(com.sforce.soap.enterprise.QueryResult histories) {
        this.histories = histories;
    }


    /**
     * Gets the interval__c value for this PayRuleDetail__c.
     * 
     * @return interval__c
     */
    public java.lang.Double getInterval__c() {
        return interval__c;
    }


    /**
     * Sets the interval__c value for this PayRuleDetail__c.
     * 
     * @param interval__c
     */
    public void setInterval__c(java.lang.Double interval__c) {
        this.interval__c = interval__c;
    }


    /**
     * Gets the isDeleted value for this PayRuleDetail__c.
     * 
     * @return isDeleted
     */
    public java.lang.Boolean getIsDeleted() {
        return isDeleted;
    }


    /**
     * Sets the isDeleted value for this PayRuleDetail__c.
     * 
     * @param isDeleted
     */
    public void setIsDeleted(java.lang.Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }


    /**
     * Gets the lastModifiedBy value for this PayRuleDetail__c.
     * 
     * @return lastModifiedBy
     */
    public com.sforce.soap.enterprise.sobject.User getLastModifiedBy() {
        return lastModifiedBy;
    }


    /**
     * Sets the lastModifiedBy value for this PayRuleDetail__c.
     * 
     * @param lastModifiedBy
     */
    public void setLastModifiedBy(com.sforce.soap.enterprise.sobject.User lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }


    /**
     * Gets the lastModifiedById value for this PayRuleDetail__c.
     * 
     * @return lastModifiedById
     */
    public java.lang.String getLastModifiedById() {
        return lastModifiedById;
    }


    /**
     * Sets the lastModifiedById value for this PayRuleDetail__c.
     * 
     * @param lastModifiedById
     */
    public void setLastModifiedById(java.lang.String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }


    /**
     * Gets the lastModifiedDate value for this PayRuleDetail__c.
     * 
     * @return lastModifiedDate
     */
    public java.util.Calendar getLastModifiedDate() {
        return lastModifiedDate;
    }


    /**
     * Sets the lastModifiedDate value for this PayRuleDetail__c.
     * 
     * @param lastModifiedDate
     */
    public void setLastModifiedDate(java.util.Calendar lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }


    /**
     * Gets the monthNumber__c value for this PayRuleDetail__c.
     * 
     * @return monthNumber__c
     */
    public java.lang.Double getMonthNumber__c() {
        return monthNumber__c;
    }


    /**
     * Sets the monthNumber__c value for this PayRuleDetail__c.
     * 
     * @param monthNumber__c
     */
    public void setMonthNumber__c(java.lang.Double monthNumber__c) {
        this.monthNumber__c = monthNumber__c;
    }


    /**
     * Gets the name value for this PayRuleDetail__c.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this PayRuleDetail__c.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the notes value for this PayRuleDetail__c.
     * 
     * @return notes
     */
    public com.sforce.soap.enterprise.QueryResult getNotes() {
        return notes;
    }


    /**
     * Sets the notes value for this PayRuleDetail__c.
     * 
     * @param notes
     */
    public void setNotes(com.sforce.soap.enterprise.QueryResult notes) {
        this.notes = notes;
    }


    /**
     * Gets the notesAndAttachments value for this PayRuleDetail__c.
     * 
     * @return notesAndAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getNotesAndAttachments() {
        return notesAndAttachments;
    }


    /**
     * Sets the notesAndAttachments value for this PayRuleDetail__c.
     * 
     * @param notesAndAttachments
     */
    public void setNotesAndAttachments(com.sforce.soap.enterprise.QueryResult notesAndAttachments) {
        this.notesAndAttachments = notesAndAttachments;
    }


    /**
     * Gets the payBalance__c value for this PayRuleDetail__c.
     * 
     * @return payBalance__c
     */
    public java.lang.Double getPayBalance__c() {
        return payBalance__c;
    }


    /**
     * Sets the payBalance__c value for this PayRuleDetail__c.
     * 
     * @param payBalance__c
     */
    public void setPayBalance__c(java.lang.Double payBalance__c) {
        this.payBalance__c = payBalance__c;
    }


    /**
     * Gets the payRule__c value for this PayRuleDetail__c.
     * 
     * @return payRule__c
     */
    public java.lang.String getPayRule__c() {
        return payRule__c;
    }


    /**
     * Sets the payRule__c value for this PayRuleDetail__c.
     * 
     * @param payRule__c
     */
    public void setPayRule__c(java.lang.String payRule__c) {
        this.payRule__c = payRule__c;
    }


    /**
     * Gets the payRule__r value for this PayRuleDetail__c.
     * 
     * @return payRule__r
     */
    public com.sforce.soap.enterprise.sobject.PayRule__c getPayRule__r() {
        return payRule__r;
    }


    /**
     * Sets the payRule__r value for this PayRuleDetail__c.
     * 
     * @param payRule__r
     */
    public void setPayRule__r(com.sforce.soap.enterprise.sobject.PayRule__c payRule__r) {
        this.payRule__r = payRule__r;
    }


    /**
     * Gets the paymentAmount__c value for this PayRuleDetail__c.
     * 
     * @return paymentAmount__c
     */
    public java.lang.Double getPaymentAmount__c() {
        return paymentAmount__c;
    }


    /**
     * Sets the paymentAmount__c value for this PayRuleDetail__c.
     * 
     * @param paymentAmount__c
     */
    public void setPaymentAmount__c(java.lang.Double paymentAmount__c) {
        this.paymentAmount__c = paymentAmount__c;
    }


    /**
     * Gets the paymentCouponNumber__c value for this PayRuleDetail__c.
     * 
     * @return paymentCouponNumber__c
     */
    public java.lang.Double getPaymentCouponNumber__c() {
        return paymentCouponNumber__c;
    }


    /**
     * Sets the paymentCouponNumber__c value for this PayRuleDetail__c.
     * 
     * @param paymentCouponNumber__c
     */
    public void setPaymentCouponNumber__c(java.lang.Double paymentCouponNumber__c) {
        this.paymentCouponNumber__c = paymentCouponNumber__c;
    }


    /**
     * Gets the paymentPercentage__c value for this PayRuleDetail__c.
     * 
     * @return paymentPercentage__c
     */
    public java.lang.Double getPaymentPercentage__c() {
        return paymentPercentage__c;
    }


    /**
     * Sets the paymentPercentage__c value for this PayRuleDetail__c.
     * 
     * @param paymentPercentage__c
     */
    public void setPaymentPercentage__c(java.lang.Double paymentPercentage__c) {
        this.paymentPercentage__c = paymentPercentage__c;
    }


    /**
     * Gets the paymentTimePoint__c value for this PayRuleDetail__c.
     * 
     * @return paymentTimePoint__c
     */
    public java.lang.Double getPaymentTimePoint__c() {
        return paymentTimePoint__c;
    }


    /**
     * Sets the paymentTimePoint__c value for this PayRuleDetail__c.
     * 
     * @param paymentTimePoint__c
     */
    public void setPaymentTimePoint__c(java.lang.Double paymentTimePoint__c) {
        this.paymentTimePoint__c = paymentTimePoint__c;
    }


    /**
     * Gets the processInstances value for this PayRuleDetail__c.
     * 
     * @return processInstances
     */
    public com.sforce.soap.enterprise.QueryResult getProcessInstances() {
        return processInstances;
    }


    /**
     * Sets the processInstances value for this PayRuleDetail__c.
     * 
     * @param processInstances
     */
    public void setProcessInstances(com.sforce.soap.enterprise.QueryResult processInstances) {
        this.processInstances = processInstances;
    }


    /**
     * Gets the processSteps value for this PayRuleDetail__c.
     * 
     * @return processSteps
     */
    public com.sforce.soap.enterprise.QueryResult getProcessSteps() {
        return processSteps;
    }


    /**
     * Sets the processSteps value for this PayRuleDetail__c.
     * 
     * @param processSteps
     */
    public void setProcessSteps(com.sforce.soap.enterprise.QueryResult processSteps) {
        this.processSteps = processSteps;
    }


    /**
     * Gets the secondPaymentDay__c value for this PayRuleDetail__c.
     * 
     * @return secondPaymentDay__c
     */
    public java.lang.Double getSecondPaymentDay__c() {
        return secondPaymentDay__c;
    }


    /**
     * Sets the secondPaymentDay__c value for this PayRuleDetail__c.
     * 
     * @param secondPaymentDay__c
     */
    public void setSecondPaymentDay__c(java.lang.Double secondPaymentDay__c) {
        this.secondPaymentDay__c = secondPaymentDay__c;
    }


    /**
     * Gets the seqence__c value for this PayRuleDetail__c.
     * 
     * @return seqence__c
     */
    public java.lang.Double getSeqence__c() {
        return seqence__c;
    }


    /**
     * Sets the seqence__c value for this PayRuleDetail__c.
     * 
     * @param seqence__c
     */
    public void setSeqence__c(java.lang.Double seqence__c) {
        this.seqence__c = seqence__c;
    }


    /**
     * Gets the settlementPrice__c value for this PayRuleDetail__c.
     * 
     * @return settlementPrice__c
     */
    public java.lang.Double getSettlementPrice__c() {
        return settlementPrice__c;
    }


    /**
     * Sets the settlementPrice__c value for this PayRuleDetail__c.
     * 
     * @param settlementPrice__c
     */
    public void setSettlementPrice__c(java.lang.Double settlementPrice__c) {
        this.settlementPrice__c = settlementPrice__c;
    }


    /**
     * Gets the stagePayType__c value for this PayRuleDetail__c.
     * 
     * @return stagePayType__c
     */
    public java.lang.Double getStagePayType__c() {
        return stagePayType__c;
    }


    /**
     * Sets the stagePayType__c value for this PayRuleDetail__c.
     * 
     * @param stagePayType__c
     */
    public void setStagePayType__c(java.lang.Double stagePayType__c) {
        this.stagePayType__c = stagePayType__c;
    }


    /**
     * Gets the stage__c value for this PayRuleDetail__c.
     * 
     * @return stage__c
     */
    public java.lang.Double getStage__c() {
        return stage__c;
    }


    /**
     * Sets the stage__c value for this PayRuleDetail__c.
     * 
     * @param stage__c
     */
    public void setStage__c(java.lang.Double stage__c) {
        this.stage__c = stage__c;
    }


    /**
     * Gets the systemModstamp value for this PayRuleDetail__c.
     * 
     * @return systemModstamp
     */
    public java.util.Calendar getSystemModstamp() {
        return systemModstamp;
    }


    /**
     * Sets the systemModstamp value for this PayRuleDetail__c.
     * 
     * @param systemModstamp
     */
    public void setSystemModstamp(java.util.Calendar systemModstamp) {
        this.systemModstamp = systemModstamp;
    }


    /**
     * Gets the usagePercentage__c value for this PayRuleDetail__c.
     * 
     * @return usagePercentage__c
     */
    public java.lang.Double getUsagePercentage__c() {
        return usagePercentage__c;
    }


    /**
     * Sets the usagePercentage__c value for this PayRuleDetail__c.
     * 
     * @param usagePercentage__c
     */
    public void setUsagePercentage__c(java.lang.Double usagePercentage__c) {
        this.usagePercentage__c = usagePercentage__c;
    }


    /**
     * Gets the workdayNumber__c value for this PayRuleDetail__c.
     * 
     * @return workdayNumber__c
     */
    public java.lang.Double getWorkdayNumber__c() {
        return workdayNumber__c;
    }


    /**
     * Sets the workdayNumber__c value for this PayRuleDetail__c.
     * 
     * @param workdayNumber__c
     */
    public void setWorkdayNumber__c(java.lang.Double workdayNumber__c) {
        this.workdayNumber__c = workdayNumber__c;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof PayRuleDetail__c)) return false;
        PayRuleDetail__c other = (PayRuleDetail__c) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.attachments==null && other.getAttachments()==null) || 
             (this.attachments!=null &&
              this.attachments.equals(other.getAttachments()))) &&
            ((this.createdBy==null && other.getCreatedBy()==null) || 
             (this.createdBy!=null &&
              this.createdBy.equals(other.getCreatedBy()))) &&
            ((this.createdById==null && other.getCreatedById()==null) || 
             (this.createdById!=null &&
              this.createdById.equals(other.getCreatedById()))) &&
            ((this.createdDate==null && other.getCreatedDate()==null) || 
             (this.createdDate!=null &&
              this.createdDate.equals(other.getCreatedDate()))) &&
            ((this.firstPaymentDay__c==null && other.getFirstPaymentDay__c()==null) || 
             (this.firstPaymentDay__c!=null &&
              this.firstPaymentDay__c.equals(other.getFirstPaymentDay__c()))) &&
            ((this.fixedDate__c==null && other.getFixedDate__c()==null) || 
             (this.fixedDate__c!=null &&
              this.fixedDate__c.equals(other.getFixedDate__c()))) &&
            ((this.histories==null && other.getHistories()==null) || 
             (this.histories!=null &&
              this.histories.equals(other.getHistories()))) &&
            ((this.interval__c==null && other.getInterval__c()==null) || 
             (this.interval__c!=null &&
              this.interval__c.equals(other.getInterval__c()))) &&
            ((this.isDeleted==null && other.getIsDeleted()==null) || 
             (this.isDeleted!=null &&
              this.isDeleted.equals(other.getIsDeleted()))) &&
            ((this.lastModifiedBy==null && other.getLastModifiedBy()==null) || 
             (this.lastModifiedBy!=null &&
              this.lastModifiedBy.equals(other.getLastModifiedBy()))) &&
            ((this.lastModifiedById==null && other.getLastModifiedById()==null) || 
             (this.lastModifiedById!=null &&
              this.lastModifiedById.equals(other.getLastModifiedById()))) &&
            ((this.lastModifiedDate==null && other.getLastModifiedDate()==null) || 
             (this.lastModifiedDate!=null &&
              this.lastModifiedDate.equals(other.getLastModifiedDate()))) &&
            ((this.monthNumber__c==null && other.getMonthNumber__c()==null) || 
             (this.monthNumber__c!=null &&
              this.monthNumber__c.equals(other.getMonthNumber__c()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.notes==null && other.getNotes()==null) || 
             (this.notes!=null &&
              this.notes.equals(other.getNotes()))) &&
            ((this.notesAndAttachments==null && other.getNotesAndAttachments()==null) || 
             (this.notesAndAttachments!=null &&
              this.notesAndAttachments.equals(other.getNotesAndAttachments()))) &&
            ((this.payBalance__c==null && other.getPayBalance__c()==null) || 
             (this.payBalance__c!=null &&
              this.payBalance__c.equals(other.getPayBalance__c()))) &&
            ((this.payRule__c==null && other.getPayRule__c()==null) || 
             (this.payRule__c!=null &&
              this.payRule__c.equals(other.getPayRule__c()))) &&
            ((this.payRule__r==null && other.getPayRule__r()==null) || 
             (this.payRule__r!=null &&
              this.payRule__r.equals(other.getPayRule__r()))) &&
            ((this.paymentAmount__c==null && other.getPaymentAmount__c()==null) || 
             (this.paymentAmount__c!=null &&
              this.paymentAmount__c.equals(other.getPaymentAmount__c()))) &&
            ((this.paymentCouponNumber__c==null && other.getPaymentCouponNumber__c()==null) || 
             (this.paymentCouponNumber__c!=null &&
              this.paymentCouponNumber__c.equals(other.getPaymentCouponNumber__c()))) &&
            ((this.paymentPercentage__c==null && other.getPaymentPercentage__c()==null) || 
             (this.paymentPercentage__c!=null &&
              this.paymentPercentage__c.equals(other.getPaymentPercentage__c()))) &&
            ((this.paymentTimePoint__c==null && other.getPaymentTimePoint__c()==null) || 
             (this.paymentTimePoint__c!=null &&
              this.paymentTimePoint__c.equals(other.getPaymentTimePoint__c()))) &&
            ((this.processInstances==null && other.getProcessInstances()==null) || 
             (this.processInstances!=null &&
              this.processInstances.equals(other.getProcessInstances()))) &&
            ((this.processSteps==null && other.getProcessSteps()==null) || 
             (this.processSteps!=null &&
              this.processSteps.equals(other.getProcessSteps()))) &&
            ((this.secondPaymentDay__c==null && other.getSecondPaymentDay__c()==null) || 
             (this.secondPaymentDay__c!=null &&
              this.secondPaymentDay__c.equals(other.getSecondPaymentDay__c()))) &&
            ((this.seqence__c==null && other.getSeqence__c()==null) || 
             (this.seqence__c!=null &&
              this.seqence__c.equals(other.getSeqence__c()))) &&
            ((this.settlementPrice__c==null && other.getSettlementPrice__c()==null) || 
             (this.settlementPrice__c!=null &&
              this.settlementPrice__c.equals(other.getSettlementPrice__c()))) &&
            ((this.stagePayType__c==null && other.getStagePayType__c()==null) || 
             (this.stagePayType__c!=null &&
              this.stagePayType__c.equals(other.getStagePayType__c()))) &&
            ((this.stage__c==null && other.getStage__c()==null) || 
             (this.stage__c!=null &&
              this.stage__c.equals(other.getStage__c()))) &&
            ((this.systemModstamp==null && other.getSystemModstamp()==null) || 
             (this.systemModstamp!=null &&
              this.systemModstamp.equals(other.getSystemModstamp()))) &&
            ((this.usagePercentage__c==null && other.getUsagePercentage__c()==null) || 
             (this.usagePercentage__c!=null &&
              this.usagePercentage__c.equals(other.getUsagePercentage__c()))) &&
            ((this.workdayNumber__c==null && other.getWorkdayNumber__c()==null) || 
             (this.workdayNumber__c!=null &&
              this.workdayNumber__c.equals(other.getWorkdayNumber__c())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAttachments() != null) {
            _hashCode += getAttachments().hashCode();
        }
        if (getCreatedBy() != null) {
            _hashCode += getCreatedBy().hashCode();
        }
        if (getCreatedById() != null) {
            _hashCode += getCreatedById().hashCode();
        }
        if (getCreatedDate() != null) {
            _hashCode += getCreatedDate().hashCode();
        }
        if (getFirstPaymentDay__c() != null) {
            _hashCode += getFirstPaymentDay__c().hashCode();
        }
        if (getFixedDate__c() != null) {
            _hashCode += getFixedDate__c().hashCode();
        }
        if (getHistories() != null) {
            _hashCode += getHistories().hashCode();
        }
        if (getInterval__c() != null) {
            _hashCode += getInterval__c().hashCode();
        }
        if (getIsDeleted() != null) {
            _hashCode += getIsDeleted().hashCode();
        }
        if (getLastModifiedBy() != null) {
            _hashCode += getLastModifiedBy().hashCode();
        }
        if (getLastModifiedById() != null) {
            _hashCode += getLastModifiedById().hashCode();
        }
        if (getLastModifiedDate() != null) {
            _hashCode += getLastModifiedDate().hashCode();
        }
        if (getMonthNumber__c() != null) {
            _hashCode += getMonthNumber__c().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getNotes() != null) {
            _hashCode += getNotes().hashCode();
        }
        if (getNotesAndAttachments() != null) {
            _hashCode += getNotesAndAttachments().hashCode();
        }
        if (getPayBalance__c() != null) {
            _hashCode += getPayBalance__c().hashCode();
        }
        if (getPayRule__c() != null) {
            _hashCode += getPayRule__c().hashCode();
        }
        if (getPayRule__r() != null) {
            _hashCode += getPayRule__r().hashCode();
        }
        if (getPaymentAmount__c() != null) {
            _hashCode += getPaymentAmount__c().hashCode();
        }
        if (getPaymentCouponNumber__c() != null) {
            _hashCode += getPaymentCouponNumber__c().hashCode();
        }
        if (getPaymentPercentage__c() != null) {
            _hashCode += getPaymentPercentage__c().hashCode();
        }
        if (getPaymentTimePoint__c() != null) {
            _hashCode += getPaymentTimePoint__c().hashCode();
        }
        if (getProcessInstances() != null) {
            _hashCode += getProcessInstances().hashCode();
        }
        if (getProcessSteps() != null) {
            _hashCode += getProcessSteps().hashCode();
        }
        if (getSecondPaymentDay__c() != null) {
            _hashCode += getSecondPaymentDay__c().hashCode();
        }
        if (getSeqence__c() != null) {
            _hashCode += getSeqence__c().hashCode();
        }
        if (getSettlementPrice__c() != null) {
            _hashCode += getSettlementPrice__c().hashCode();
        }
        if (getStagePayType__c() != null) {
            _hashCode += getStagePayType__c().hashCode();
        }
        if (getStage__c() != null) {
            _hashCode += getStage__c().hashCode();
        }
        if (getSystemModstamp() != null) {
            _hashCode += getSystemModstamp().hashCode();
        }
        if (getUsagePercentage__c() != null) {
            _hashCode += getUsagePercentage__c().hashCode();
        }
        if (getWorkdayNumber__c() != null) {
            _hashCode += getWorkdayNumber__c().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(PayRuleDetail__c.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PayRuleDetail__c"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Attachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("firstPaymentDay__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "FirstPaymentDay__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fixedDate__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "FixedDate__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("histories");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Histories"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("interval__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Interval__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isDeleted");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsDeleted"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("monthNumber__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "MonthNumber__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notes");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Notes"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notesAndAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NotesAndAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("payBalance__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PayBalance__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("payRule__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PayRule__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("payRule__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PayRule__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PayRule__c"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paymentAmount__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PaymentAmount__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paymentCouponNumber__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PaymentCouponNumber__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paymentPercentage__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PaymentPercentage__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paymentTimePoint__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PaymentTimePoint__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processInstances");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessInstances"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processSteps");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessSteps"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("secondPaymentDay__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SecondPaymentDay__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("seqence__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Seqence__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("settlementPrice__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SettlementPrice__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("stagePayType__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "StagePayType__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("stage__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Stage__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("systemModstamp");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SystemModstamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("usagePercentage__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UsagePercentage__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("workdayNumber__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "WorkdayNumber__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
