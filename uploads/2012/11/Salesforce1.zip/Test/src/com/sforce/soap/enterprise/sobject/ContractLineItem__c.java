/**
 * ContractLineItem__c.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.sforce.soap.enterprise.sobject;

public class ContractLineItem__c  extends com.sforce.soap.enterprise.sobject.SObject  implements java.io.Serializable {
    private java.lang.Double AP_IsOtherProduct__c;

    private java.lang.Boolean AP_OtherProduct__c;

    private com.sforce.soap.enterprise.QueryResult attachments;

    private java.lang.String channel__c;

    private java.lang.String city__c;

    private com.sforce.soap.enterprise.sobject.City__c city__r;

    private java.lang.String contract__c;

    private com.sforce.soap.enterprise.sobject.Contract contract__r;

    private com.sforce.soap.enterprise.sobject.User createdBy;

    private java.lang.String createdById;

    private java.util.Calendar createdDate;

    private java.lang.String editStatus__c;

    private java.util.Date endDate__c;

    private java.lang.Boolean freeProduct__c;

    private com.sforce.soap.enterprise.QueryResult histories;

    private java.lang.String infoGood__c;

    private java.lang.String inventoryOperationResult__c;

    private java.lang.String inventoryStatus__c;

    private java.lang.Boolean isBrandAD__c;

    private java.lang.String isBrandAdProduct__c;

    private java.lang.Boolean isDeleted;

    private java.lang.Boolean isInfoGood__c;

    private java.lang.String keyWord__c;

    private java.lang.Double LTTotalListPrice__c;

    private com.sforce.soap.enterprise.sobject.User lastModifiedBy;

    private java.lang.String lastModifiedById;

    private java.util.Calendar lastModifiedDate;

    private java.lang.Double listPrice__c;

    private java.lang.String name;

    private java.lang.String needBookInventory__c;

    private com.sforce.soap.enterprise.QueryResult notes;

    private com.sforce.soap.enterprise.QueryResult notesAndAttachments;

    private java.lang.String optyLineItemId__c;

    private com.sforce.soap.enterprise.QueryResult processInstances;

    private com.sforce.soap.enterprise.QueryResult processSteps;

    private java.lang.String product2__c;

    private com.sforce.soap.enterprise.sobject.Product2 product2__r;

    private java.lang.String productADType__c;

    private java.lang.String productDetail__c;

    private java.lang.String productType__c;

    private java.lang.Double quantity__c;

    private java.lang.Double sharedAmount__c;

    private java.lang.String shopAccount__c;

    private com.sforce.soap.enterprise.sobject.Account shopAccount__r;

    private java.lang.String showChannel__c;

    private java.lang.String showKeyWord__c;

    private java.lang.String showShopAccount__c;

    private java.lang.String showSysCrossShopSearch__c;

    private java.lang.String showSysInventory__c;

    private java.util.Date startDate__c;

    private java.util.Calendar systemModstamp;

    private java.lang.Double unitPrice__c;

    private java.lang.String isProductRPAppCalc__c;

    private java.lang.Boolean isProductRPApp__c;

    public ContractLineItem__c() {
    }

    public ContractLineItem__c(
           java.lang.String[] fieldsToNull,
           java.lang.String id,
           java.lang.Double AP_IsOtherProduct__c,
           java.lang.Boolean AP_OtherProduct__c,
           com.sforce.soap.enterprise.QueryResult attachments,
           java.lang.String channel__c,
           java.lang.String city__c,
           com.sforce.soap.enterprise.sobject.City__c city__r,
           java.lang.String contract__c,
           com.sforce.soap.enterprise.sobject.Contract contract__r,
           com.sforce.soap.enterprise.sobject.User createdBy,
           java.lang.String createdById,
           java.util.Calendar createdDate,
           java.lang.String editStatus__c,
           java.util.Date endDate__c,
           java.lang.Boolean freeProduct__c,
           com.sforce.soap.enterprise.QueryResult histories,
           java.lang.String infoGood__c,
           java.lang.String inventoryOperationResult__c,
           java.lang.String inventoryStatus__c,
           java.lang.Boolean isBrandAD__c,
           java.lang.String isBrandAdProduct__c,
           java.lang.Boolean isDeleted,
           java.lang.Boolean isInfoGood__c,
           java.lang.String keyWord__c,
           java.lang.Double LTTotalListPrice__c,
           com.sforce.soap.enterprise.sobject.User lastModifiedBy,
           java.lang.String lastModifiedById,
           java.util.Calendar lastModifiedDate,
           java.lang.Double listPrice__c,
           java.lang.String name,
           java.lang.String needBookInventory__c,
           com.sforce.soap.enterprise.QueryResult notes,
           com.sforce.soap.enterprise.QueryResult notesAndAttachments,
           java.lang.String optyLineItemId__c,
           com.sforce.soap.enterprise.QueryResult processInstances,
           com.sforce.soap.enterprise.QueryResult processSteps,
           java.lang.String product2__c,
           com.sforce.soap.enterprise.sobject.Product2 product2__r,
           java.lang.String productADType__c,
           java.lang.String productDetail__c,
           java.lang.String productType__c,
           java.lang.Double quantity__c,
           java.lang.Double sharedAmount__c,
           java.lang.String shopAccount__c,
           com.sforce.soap.enterprise.sobject.Account shopAccount__r,
           java.lang.String showChannel__c,
           java.lang.String showKeyWord__c,
           java.lang.String showShopAccount__c,
           java.lang.String showSysCrossShopSearch__c,
           java.lang.String showSysInventory__c,
           java.util.Date startDate__c,
           java.util.Calendar systemModstamp,
           java.lang.Double unitPrice__c,
           java.lang.String isProductRPAppCalc__c,
           java.lang.Boolean isProductRPApp__c) {
        super(
            fieldsToNull,
            id);
        this.AP_IsOtherProduct__c = AP_IsOtherProduct__c;
        this.AP_OtherProduct__c = AP_OtherProduct__c;
        this.attachments = attachments;
        this.channel__c = channel__c;
        this.city__c = city__c;
        this.city__r = city__r;
        this.contract__c = contract__c;
        this.contract__r = contract__r;
        this.createdBy = createdBy;
        this.createdById = createdById;
        this.createdDate = createdDate;
        this.editStatus__c = editStatus__c;
        this.endDate__c = endDate__c;
        this.freeProduct__c = freeProduct__c;
        this.histories = histories;
        this.infoGood__c = infoGood__c;
        this.inventoryOperationResult__c = inventoryOperationResult__c;
        this.inventoryStatus__c = inventoryStatus__c;
        this.isBrandAD__c = isBrandAD__c;
        this.isBrandAdProduct__c = isBrandAdProduct__c;
        this.isDeleted = isDeleted;
        this.isInfoGood__c = isInfoGood__c;
        this.keyWord__c = keyWord__c;
        this.LTTotalListPrice__c = LTTotalListPrice__c;
        this.lastModifiedBy = lastModifiedBy;
        this.lastModifiedById = lastModifiedById;
        this.lastModifiedDate = lastModifiedDate;
        this.listPrice__c = listPrice__c;
        this.name = name;
        this.needBookInventory__c = needBookInventory__c;
        this.notes = notes;
        this.notesAndAttachments = notesAndAttachments;
        this.optyLineItemId__c = optyLineItemId__c;
        this.processInstances = processInstances;
        this.processSteps = processSteps;
        this.product2__c = product2__c;
        this.product2__r = product2__r;
        this.productADType__c = productADType__c;
        this.productDetail__c = productDetail__c;
        this.productType__c = productType__c;
        this.quantity__c = quantity__c;
        this.sharedAmount__c = sharedAmount__c;
        this.shopAccount__c = shopAccount__c;
        this.shopAccount__r = shopAccount__r;
        this.showChannel__c = showChannel__c;
        this.showKeyWord__c = showKeyWord__c;
        this.showShopAccount__c = showShopAccount__c;
        this.showSysCrossShopSearch__c = showSysCrossShopSearch__c;
        this.showSysInventory__c = showSysInventory__c;
        this.startDate__c = startDate__c;
        this.systemModstamp = systemModstamp;
        this.unitPrice__c = unitPrice__c;
        this.isProductRPAppCalc__c = isProductRPAppCalc__c;
        this.isProductRPApp__c = isProductRPApp__c;
    }


    /**
     * Gets the AP_IsOtherProduct__c value for this ContractLineItem__c.
     * 
     * @return AP_IsOtherProduct__c
     */
    public java.lang.Double getAP_IsOtherProduct__c() {
        return AP_IsOtherProduct__c;
    }


    /**
     * Sets the AP_IsOtherProduct__c value for this ContractLineItem__c.
     * 
     * @param AP_IsOtherProduct__c
     */
    public void setAP_IsOtherProduct__c(java.lang.Double AP_IsOtherProduct__c) {
        this.AP_IsOtherProduct__c = AP_IsOtherProduct__c;
    }


    /**
     * Gets the AP_OtherProduct__c value for this ContractLineItem__c.
     * 
     * @return AP_OtherProduct__c
     */
    public java.lang.Boolean getAP_OtherProduct__c() {
        return AP_OtherProduct__c;
    }


    /**
     * Sets the AP_OtherProduct__c value for this ContractLineItem__c.
     * 
     * @param AP_OtherProduct__c
     */
    public void setAP_OtherProduct__c(java.lang.Boolean AP_OtherProduct__c) {
        this.AP_OtherProduct__c = AP_OtherProduct__c;
    }


    /**
     * Gets the attachments value for this ContractLineItem__c.
     * 
     * @return attachments
     */
    public com.sforce.soap.enterprise.QueryResult getAttachments() {
        return attachments;
    }


    /**
     * Sets the attachments value for this ContractLineItem__c.
     * 
     * @param attachments
     */
    public void setAttachments(com.sforce.soap.enterprise.QueryResult attachments) {
        this.attachments = attachments;
    }


    /**
     * Gets the channel__c value for this ContractLineItem__c.
     * 
     * @return channel__c
     */
    public java.lang.String getChannel__c() {
        return channel__c;
    }


    /**
     * Sets the channel__c value for this ContractLineItem__c.
     * 
     * @param channel__c
     */
    public void setChannel__c(java.lang.String channel__c) {
        this.channel__c = channel__c;
    }


    /**
     * Gets the city__c value for this ContractLineItem__c.
     * 
     * @return city__c
     */
    public java.lang.String getCity__c() {
        return city__c;
    }


    /**
     * Sets the city__c value for this ContractLineItem__c.
     * 
     * @param city__c
     */
    public void setCity__c(java.lang.String city__c) {
        this.city__c = city__c;
    }


    /**
     * Gets the city__r value for this ContractLineItem__c.
     * 
     * @return city__r
     */
    public com.sforce.soap.enterprise.sobject.City__c getCity__r() {
        return city__r;
    }


    /**
     * Sets the city__r value for this ContractLineItem__c.
     * 
     * @param city__r
     */
    public void setCity__r(com.sforce.soap.enterprise.sobject.City__c city__r) {
        this.city__r = city__r;
    }


    /**
     * Gets the contract__c value for this ContractLineItem__c.
     * 
     * @return contract__c
     */
    public java.lang.String getContract__c() {
        return contract__c;
    }


    /**
     * Sets the contract__c value for this ContractLineItem__c.
     * 
     * @param contract__c
     */
    public void setContract__c(java.lang.String contract__c) {
        this.contract__c = contract__c;
    }


    /**
     * Gets the contract__r value for this ContractLineItem__c.
     * 
     * @return contract__r
     */
    public com.sforce.soap.enterprise.sobject.Contract getContract__r() {
        return contract__r;
    }


    /**
     * Sets the contract__r value for this ContractLineItem__c.
     * 
     * @param contract__r
     */
    public void setContract__r(com.sforce.soap.enterprise.sobject.Contract contract__r) {
        this.contract__r = contract__r;
    }


    /**
     * Gets the createdBy value for this ContractLineItem__c.
     * 
     * @return createdBy
     */
    public com.sforce.soap.enterprise.sobject.User getCreatedBy() {
        return createdBy;
    }


    /**
     * Sets the createdBy value for this ContractLineItem__c.
     * 
     * @param createdBy
     */
    public void setCreatedBy(com.sforce.soap.enterprise.sobject.User createdBy) {
        this.createdBy = createdBy;
    }


    /**
     * Gets the createdById value for this ContractLineItem__c.
     * 
     * @return createdById
     */
    public java.lang.String getCreatedById() {
        return createdById;
    }


    /**
     * Sets the createdById value for this ContractLineItem__c.
     * 
     * @param createdById
     */
    public void setCreatedById(java.lang.String createdById) {
        this.createdById = createdById;
    }


    /**
     * Gets the createdDate value for this ContractLineItem__c.
     * 
     * @return createdDate
     */
    public java.util.Calendar getCreatedDate() {
        return createdDate;
    }


    /**
     * Sets the createdDate value for this ContractLineItem__c.
     * 
     * @param createdDate
     */
    public void setCreatedDate(java.util.Calendar createdDate) {
        this.createdDate = createdDate;
    }


    /**
     * Gets the editStatus__c value for this ContractLineItem__c.
     * 
     * @return editStatus__c
     */
    public java.lang.String getEditStatus__c() {
        return editStatus__c;
    }


    /**
     * Sets the editStatus__c value for this ContractLineItem__c.
     * 
     * @param editStatus__c
     */
    public void setEditStatus__c(java.lang.String editStatus__c) {
        this.editStatus__c = editStatus__c;
    }


    /**
     * Gets the endDate__c value for this ContractLineItem__c.
     * 
     * @return endDate__c
     */
    public java.util.Date getEndDate__c() {
        return endDate__c;
    }


    /**
     * Sets the endDate__c value for this ContractLineItem__c.
     * 
     * @param endDate__c
     */
    public void setEndDate__c(java.util.Date endDate__c) {
        this.endDate__c = endDate__c;
    }


    /**
     * Gets the freeProduct__c value for this ContractLineItem__c.
     * 
     * @return freeProduct__c
     */
    public java.lang.Boolean getFreeProduct__c() {
        return freeProduct__c;
    }


    /**
     * Sets the freeProduct__c value for this ContractLineItem__c.
     * 
     * @param freeProduct__c
     */
    public void setFreeProduct__c(java.lang.Boolean freeProduct__c) {
        this.freeProduct__c = freeProduct__c;
    }


    /**
     * Gets the histories value for this ContractLineItem__c.
     * 
     * @return histories
     */
    public com.sforce.soap.enterprise.QueryResult getHistories() {
        return histories;
    }


    /**
     * Sets the histories value for this ContractLineItem__c.
     * 
     * @param histories
     */
    public void setHistories(com.sforce.soap.enterprise.QueryResult histories) {
        this.histories = histories;
    }


    /**
     * Gets the infoGood__c value for this ContractLineItem__c.
     * 
     * @return infoGood__c
     */
    public java.lang.String getInfoGood__c() {
        return infoGood__c;
    }


    /**
     * Sets the infoGood__c value for this ContractLineItem__c.
     * 
     * @param infoGood__c
     */
    public void setInfoGood__c(java.lang.String infoGood__c) {
        this.infoGood__c = infoGood__c;
    }


    /**
     * Gets the inventoryOperationResult__c value for this ContractLineItem__c.
     * 
     * @return inventoryOperationResult__c
     */
    public java.lang.String getInventoryOperationResult__c() {
        return inventoryOperationResult__c;
    }


    /**
     * Sets the inventoryOperationResult__c value for this ContractLineItem__c.
     * 
     * @param inventoryOperationResult__c
     */
    public void setInventoryOperationResult__c(java.lang.String inventoryOperationResult__c) {
        this.inventoryOperationResult__c = inventoryOperationResult__c;
    }


    /**
     * Gets the inventoryStatus__c value for this ContractLineItem__c.
     * 
     * @return inventoryStatus__c
     */
    public java.lang.String getInventoryStatus__c() {
        return inventoryStatus__c;
    }


    /**
     * Sets the inventoryStatus__c value for this ContractLineItem__c.
     * 
     * @param inventoryStatus__c
     */
    public void setInventoryStatus__c(java.lang.String inventoryStatus__c) {
        this.inventoryStatus__c = inventoryStatus__c;
    }


    /**
     * Gets the isBrandAD__c value for this ContractLineItem__c.
     * 
     * @return isBrandAD__c
     */
    public java.lang.Boolean getIsBrandAD__c() {
        return isBrandAD__c;
    }


    /**
     * Sets the isBrandAD__c value for this ContractLineItem__c.
     * 
     * @param isBrandAD__c
     */
    public void setIsBrandAD__c(java.lang.Boolean isBrandAD__c) {
        this.isBrandAD__c = isBrandAD__c;
    }


    /**
     * Gets the isBrandAdProduct__c value for this ContractLineItem__c.
     * 
     * @return isBrandAdProduct__c
     */
    public java.lang.String getIsBrandAdProduct__c() {
        return isBrandAdProduct__c;
    }


    /**
     * Sets the isBrandAdProduct__c value for this ContractLineItem__c.
     * 
     * @param isBrandAdProduct__c
     */
    public void setIsBrandAdProduct__c(java.lang.String isBrandAdProduct__c) {
        this.isBrandAdProduct__c = isBrandAdProduct__c;
    }


    /**
     * Gets the isDeleted value for this ContractLineItem__c.
     * 
     * @return isDeleted
     */
    public java.lang.Boolean getIsDeleted() {
        return isDeleted;
    }


    /**
     * Sets the isDeleted value for this ContractLineItem__c.
     * 
     * @param isDeleted
     */
    public void setIsDeleted(java.lang.Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }


    /**
     * Gets the isInfoGood__c value for this ContractLineItem__c.
     * 
     * @return isInfoGood__c
     */
    public java.lang.Boolean getIsInfoGood__c() {
        return isInfoGood__c;
    }


    /**
     * Sets the isInfoGood__c value for this ContractLineItem__c.
     * 
     * @param isInfoGood__c
     */
    public void setIsInfoGood__c(java.lang.Boolean isInfoGood__c) {
        this.isInfoGood__c = isInfoGood__c;
    }


    /**
     * Gets the keyWord__c value for this ContractLineItem__c.
     * 
     * @return keyWord__c
     */
    public java.lang.String getKeyWord__c() {
        return keyWord__c;
    }


    /**
     * Sets the keyWord__c value for this ContractLineItem__c.
     * 
     * @param keyWord__c
     */
    public void setKeyWord__c(java.lang.String keyWord__c) {
        this.keyWord__c = keyWord__c;
    }


    /**
     * Gets the LTTotalListPrice__c value for this ContractLineItem__c.
     * 
     * @return LTTotalListPrice__c
     */
    public java.lang.Double getLTTotalListPrice__c() {
        return LTTotalListPrice__c;
    }


    /**
     * Sets the LTTotalListPrice__c value for this ContractLineItem__c.
     * 
     * @param LTTotalListPrice__c
     */
    public void setLTTotalListPrice__c(java.lang.Double LTTotalListPrice__c) {
        this.LTTotalListPrice__c = LTTotalListPrice__c;
    }


    /**
     * Gets the lastModifiedBy value for this ContractLineItem__c.
     * 
     * @return lastModifiedBy
     */
    public com.sforce.soap.enterprise.sobject.User getLastModifiedBy() {
        return lastModifiedBy;
    }


    /**
     * Sets the lastModifiedBy value for this ContractLineItem__c.
     * 
     * @param lastModifiedBy
     */
    public void setLastModifiedBy(com.sforce.soap.enterprise.sobject.User lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }


    /**
     * Gets the lastModifiedById value for this ContractLineItem__c.
     * 
     * @return lastModifiedById
     */
    public java.lang.String getLastModifiedById() {
        return lastModifiedById;
    }


    /**
     * Sets the lastModifiedById value for this ContractLineItem__c.
     * 
     * @param lastModifiedById
     */
    public void setLastModifiedById(java.lang.String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }


    /**
     * Gets the lastModifiedDate value for this ContractLineItem__c.
     * 
     * @return lastModifiedDate
     */
    public java.util.Calendar getLastModifiedDate() {
        return lastModifiedDate;
    }


    /**
     * Sets the lastModifiedDate value for this ContractLineItem__c.
     * 
     * @param lastModifiedDate
     */
    public void setLastModifiedDate(java.util.Calendar lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }


    /**
     * Gets the listPrice__c value for this ContractLineItem__c.
     * 
     * @return listPrice__c
     */
    public java.lang.Double getListPrice__c() {
        return listPrice__c;
    }


    /**
     * Sets the listPrice__c value for this ContractLineItem__c.
     * 
     * @param listPrice__c
     */
    public void setListPrice__c(java.lang.Double listPrice__c) {
        this.listPrice__c = listPrice__c;
    }


    /**
     * Gets the name value for this ContractLineItem__c.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this ContractLineItem__c.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the needBookInventory__c value for this ContractLineItem__c.
     * 
     * @return needBookInventory__c
     */
    public java.lang.String getNeedBookInventory__c() {
        return needBookInventory__c;
    }


    /**
     * Sets the needBookInventory__c value for this ContractLineItem__c.
     * 
     * @param needBookInventory__c
     */
    public void setNeedBookInventory__c(java.lang.String needBookInventory__c) {
        this.needBookInventory__c = needBookInventory__c;
    }


    /**
     * Gets the notes value for this ContractLineItem__c.
     * 
     * @return notes
     */
    public com.sforce.soap.enterprise.QueryResult getNotes() {
        return notes;
    }


    /**
     * Sets the notes value for this ContractLineItem__c.
     * 
     * @param notes
     */
    public void setNotes(com.sforce.soap.enterprise.QueryResult notes) {
        this.notes = notes;
    }


    /**
     * Gets the notesAndAttachments value for this ContractLineItem__c.
     * 
     * @return notesAndAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getNotesAndAttachments() {
        return notesAndAttachments;
    }


    /**
     * Sets the notesAndAttachments value for this ContractLineItem__c.
     * 
     * @param notesAndAttachments
     */
    public void setNotesAndAttachments(com.sforce.soap.enterprise.QueryResult notesAndAttachments) {
        this.notesAndAttachments = notesAndAttachments;
    }


    /**
     * Gets the optyLineItemId__c value for this ContractLineItem__c.
     * 
     * @return optyLineItemId__c
     */
    public java.lang.String getOptyLineItemId__c() {
        return optyLineItemId__c;
    }


    /**
     * Sets the optyLineItemId__c value for this ContractLineItem__c.
     * 
     * @param optyLineItemId__c
     */
    public void setOptyLineItemId__c(java.lang.String optyLineItemId__c) {
        this.optyLineItemId__c = optyLineItemId__c;
    }


    /**
     * Gets the processInstances value for this ContractLineItem__c.
     * 
     * @return processInstances
     */
    public com.sforce.soap.enterprise.QueryResult getProcessInstances() {
        return processInstances;
    }


    /**
     * Sets the processInstances value for this ContractLineItem__c.
     * 
     * @param processInstances
     */
    public void setProcessInstances(com.sforce.soap.enterprise.QueryResult processInstances) {
        this.processInstances = processInstances;
    }


    /**
     * Gets the processSteps value for this ContractLineItem__c.
     * 
     * @return processSteps
     */
    public com.sforce.soap.enterprise.QueryResult getProcessSteps() {
        return processSteps;
    }


    /**
     * Sets the processSteps value for this ContractLineItem__c.
     * 
     * @param processSteps
     */
    public void setProcessSteps(com.sforce.soap.enterprise.QueryResult processSteps) {
        this.processSteps = processSteps;
    }


    /**
     * Gets the product2__c value for this ContractLineItem__c.
     * 
     * @return product2__c
     */
    public java.lang.String getProduct2__c() {
        return product2__c;
    }


    /**
     * Sets the product2__c value for this ContractLineItem__c.
     * 
     * @param product2__c
     */
    public void setProduct2__c(java.lang.String product2__c) {
        this.product2__c = product2__c;
    }


    /**
     * Gets the product2__r value for this ContractLineItem__c.
     * 
     * @return product2__r
     */
    public com.sforce.soap.enterprise.sobject.Product2 getProduct2__r() {
        return product2__r;
    }


    /**
     * Sets the product2__r value for this ContractLineItem__c.
     * 
     * @param product2__r
     */
    public void setProduct2__r(com.sforce.soap.enterprise.sobject.Product2 product2__r) {
        this.product2__r = product2__r;
    }


    /**
     * Gets the productADType__c value for this ContractLineItem__c.
     * 
     * @return productADType__c
     */
    public java.lang.String getProductADType__c() {
        return productADType__c;
    }


    /**
     * Sets the productADType__c value for this ContractLineItem__c.
     * 
     * @param productADType__c
     */
    public void setProductADType__c(java.lang.String productADType__c) {
        this.productADType__c = productADType__c;
    }


    /**
     * Gets the productDetail__c value for this ContractLineItem__c.
     * 
     * @return productDetail__c
     */
    public java.lang.String getProductDetail__c() {
        return productDetail__c;
    }


    /**
     * Sets the productDetail__c value for this ContractLineItem__c.
     * 
     * @param productDetail__c
     */
    public void setProductDetail__c(java.lang.String productDetail__c) {
        this.productDetail__c = productDetail__c;
    }


    /**
     * Gets the productType__c value for this ContractLineItem__c.
     * 
     * @return productType__c
     */
    public java.lang.String getProductType__c() {
        return productType__c;
    }


    /**
     * Sets the productType__c value for this ContractLineItem__c.
     * 
     * @param productType__c
     */
    public void setProductType__c(java.lang.String productType__c) {
        this.productType__c = productType__c;
    }


    /**
     * Gets the quantity__c value for this ContractLineItem__c.
     * 
     * @return quantity__c
     */
    public java.lang.Double getQuantity__c() {
        return quantity__c;
    }


    /**
     * Sets the quantity__c value for this ContractLineItem__c.
     * 
     * @param quantity__c
     */
    public void setQuantity__c(java.lang.Double quantity__c) {
        this.quantity__c = quantity__c;
    }


    /**
     * Gets the sharedAmount__c value for this ContractLineItem__c.
     * 
     * @return sharedAmount__c
     */
    public java.lang.Double getSharedAmount__c() {
        return sharedAmount__c;
    }


    /**
     * Sets the sharedAmount__c value for this ContractLineItem__c.
     * 
     * @param sharedAmount__c
     */
    public void setSharedAmount__c(java.lang.Double sharedAmount__c) {
        this.sharedAmount__c = sharedAmount__c;
    }


    /**
     * Gets the shopAccount__c value for this ContractLineItem__c.
     * 
     * @return shopAccount__c
     */
    public java.lang.String getShopAccount__c() {
        return shopAccount__c;
    }


    /**
     * Sets the shopAccount__c value for this ContractLineItem__c.
     * 
     * @param shopAccount__c
     */
    public void setShopAccount__c(java.lang.String shopAccount__c) {
        this.shopAccount__c = shopAccount__c;
    }


    /**
     * Gets the shopAccount__r value for this ContractLineItem__c.
     * 
     * @return shopAccount__r
     */
    public com.sforce.soap.enterprise.sobject.Account getShopAccount__r() {
        return shopAccount__r;
    }


    /**
     * Sets the shopAccount__r value for this ContractLineItem__c.
     * 
     * @param shopAccount__r
     */
    public void setShopAccount__r(com.sforce.soap.enterprise.sobject.Account shopAccount__r) {
        this.shopAccount__r = shopAccount__r;
    }


    /**
     * Gets the showChannel__c value for this ContractLineItem__c.
     * 
     * @return showChannel__c
     */
    public java.lang.String getShowChannel__c() {
        return showChannel__c;
    }


    /**
     * Sets the showChannel__c value for this ContractLineItem__c.
     * 
     * @param showChannel__c
     */
    public void setShowChannel__c(java.lang.String showChannel__c) {
        this.showChannel__c = showChannel__c;
    }


    /**
     * Gets the showKeyWord__c value for this ContractLineItem__c.
     * 
     * @return showKeyWord__c
     */
    public java.lang.String getShowKeyWord__c() {
        return showKeyWord__c;
    }


    /**
     * Sets the showKeyWord__c value for this ContractLineItem__c.
     * 
     * @param showKeyWord__c
     */
    public void setShowKeyWord__c(java.lang.String showKeyWord__c) {
        this.showKeyWord__c = showKeyWord__c;
    }


    /**
     * Gets the showShopAccount__c value for this ContractLineItem__c.
     * 
     * @return showShopAccount__c
     */
    public java.lang.String getShowShopAccount__c() {
        return showShopAccount__c;
    }


    /**
     * Sets the showShopAccount__c value for this ContractLineItem__c.
     * 
     * @param showShopAccount__c
     */
    public void setShowShopAccount__c(java.lang.String showShopAccount__c) {
        this.showShopAccount__c = showShopAccount__c;
    }


    /**
     * Gets the showSysCrossShopSearch__c value for this ContractLineItem__c.
     * 
     * @return showSysCrossShopSearch__c
     */
    public java.lang.String getShowSysCrossShopSearch__c() {
        return showSysCrossShopSearch__c;
    }


    /**
     * Sets the showSysCrossShopSearch__c value for this ContractLineItem__c.
     * 
     * @param showSysCrossShopSearch__c
     */
    public void setShowSysCrossShopSearch__c(java.lang.String showSysCrossShopSearch__c) {
        this.showSysCrossShopSearch__c = showSysCrossShopSearch__c;
    }


    /**
     * Gets the showSysInventory__c value for this ContractLineItem__c.
     * 
     * @return showSysInventory__c
     */
    public java.lang.String getShowSysInventory__c() {
        return showSysInventory__c;
    }


    /**
     * Sets the showSysInventory__c value for this ContractLineItem__c.
     * 
     * @param showSysInventory__c
     */
    public void setShowSysInventory__c(java.lang.String showSysInventory__c) {
        this.showSysInventory__c = showSysInventory__c;
    }


    /**
     * Gets the startDate__c value for this ContractLineItem__c.
     * 
     * @return startDate__c
     */
    public java.util.Date getStartDate__c() {
        return startDate__c;
    }


    /**
     * Sets the startDate__c value for this ContractLineItem__c.
     * 
     * @param startDate__c
     */
    public void setStartDate__c(java.util.Date startDate__c) {
        this.startDate__c = startDate__c;
    }


    /**
     * Gets the systemModstamp value for this ContractLineItem__c.
     * 
     * @return systemModstamp
     */
    public java.util.Calendar getSystemModstamp() {
        return systemModstamp;
    }


    /**
     * Sets the systemModstamp value for this ContractLineItem__c.
     * 
     * @param systemModstamp
     */
    public void setSystemModstamp(java.util.Calendar systemModstamp) {
        this.systemModstamp = systemModstamp;
    }


    /**
     * Gets the unitPrice__c value for this ContractLineItem__c.
     * 
     * @return unitPrice__c
     */
    public java.lang.Double getUnitPrice__c() {
        return unitPrice__c;
    }


    /**
     * Sets the unitPrice__c value for this ContractLineItem__c.
     * 
     * @param unitPrice__c
     */
    public void setUnitPrice__c(java.lang.Double unitPrice__c) {
        this.unitPrice__c = unitPrice__c;
    }


    /**
     * Gets the isProductRPAppCalc__c value for this ContractLineItem__c.
     * 
     * @return isProductRPAppCalc__c
     */
    public java.lang.String getIsProductRPAppCalc__c() {
        return isProductRPAppCalc__c;
    }


    /**
     * Sets the isProductRPAppCalc__c value for this ContractLineItem__c.
     * 
     * @param isProductRPAppCalc__c
     */
    public void setIsProductRPAppCalc__c(java.lang.String isProductRPAppCalc__c) {
        this.isProductRPAppCalc__c = isProductRPAppCalc__c;
    }


    /**
     * Gets the isProductRPApp__c value for this ContractLineItem__c.
     * 
     * @return isProductRPApp__c
     */
    public java.lang.Boolean getIsProductRPApp__c() {
        return isProductRPApp__c;
    }


    /**
     * Sets the isProductRPApp__c value for this ContractLineItem__c.
     * 
     * @param isProductRPApp__c
     */
    public void setIsProductRPApp__c(java.lang.Boolean isProductRPApp__c) {
        this.isProductRPApp__c = isProductRPApp__c;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ContractLineItem__c)) return false;
        ContractLineItem__c other = (ContractLineItem__c) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.AP_IsOtherProduct__c==null && other.getAP_IsOtherProduct__c()==null) || 
             (this.AP_IsOtherProduct__c!=null &&
              this.AP_IsOtherProduct__c.equals(other.getAP_IsOtherProduct__c()))) &&
            ((this.AP_OtherProduct__c==null && other.getAP_OtherProduct__c()==null) || 
             (this.AP_OtherProduct__c!=null &&
              this.AP_OtherProduct__c.equals(other.getAP_OtherProduct__c()))) &&
            ((this.attachments==null && other.getAttachments()==null) || 
             (this.attachments!=null &&
              this.attachments.equals(other.getAttachments()))) &&
            ((this.channel__c==null && other.getChannel__c()==null) || 
             (this.channel__c!=null &&
              this.channel__c.equals(other.getChannel__c()))) &&
            ((this.city__c==null && other.getCity__c()==null) || 
             (this.city__c!=null &&
              this.city__c.equals(other.getCity__c()))) &&
            ((this.city__r==null && other.getCity__r()==null) || 
             (this.city__r!=null &&
              this.city__r.equals(other.getCity__r()))) &&
            ((this.contract__c==null && other.getContract__c()==null) || 
             (this.contract__c!=null &&
              this.contract__c.equals(other.getContract__c()))) &&
            ((this.contract__r==null && other.getContract__r()==null) || 
             (this.contract__r!=null &&
              this.contract__r.equals(other.getContract__r()))) &&
            ((this.createdBy==null && other.getCreatedBy()==null) || 
             (this.createdBy!=null &&
              this.createdBy.equals(other.getCreatedBy()))) &&
            ((this.createdById==null && other.getCreatedById()==null) || 
             (this.createdById!=null &&
              this.createdById.equals(other.getCreatedById()))) &&
            ((this.createdDate==null && other.getCreatedDate()==null) || 
             (this.createdDate!=null &&
              this.createdDate.equals(other.getCreatedDate()))) &&
            ((this.editStatus__c==null && other.getEditStatus__c()==null) || 
             (this.editStatus__c!=null &&
              this.editStatus__c.equals(other.getEditStatus__c()))) &&
            ((this.endDate__c==null && other.getEndDate__c()==null) || 
             (this.endDate__c!=null &&
              this.endDate__c.equals(other.getEndDate__c()))) &&
            ((this.freeProduct__c==null && other.getFreeProduct__c()==null) || 
             (this.freeProduct__c!=null &&
              this.freeProduct__c.equals(other.getFreeProduct__c()))) &&
            ((this.histories==null && other.getHistories()==null) || 
             (this.histories!=null &&
              this.histories.equals(other.getHistories()))) &&
            ((this.infoGood__c==null && other.getInfoGood__c()==null) || 
             (this.infoGood__c!=null &&
              this.infoGood__c.equals(other.getInfoGood__c()))) &&
            ((this.inventoryOperationResult__c==null && other.getInventoryOperationResult__c()==null) || 
             (this.inventoryOperationResult__c!=null &&
              this.inventoryOperationResult__c.equals(other.getInventoryOperationResult__c()))) &&
            ((this.inventoryStatus__c==null && other.getInventoryStatus__c()==null) || 
             (this.inventoryStatus__c!=null &&
              this.inventoryStatus__c.equals(other.getInventoryStatus__c()))) &&
            ((this.isBrandAD__c==null && other.getIsBrandAD__c()==null) || 
             (this.isBrandAD__c!=null &&
              this.isBrandAD__c.equals(other.getIsBrandAD__c()))) &&
            ((this.isBrandAdProduct__c==null && other.getIsBrandAdProduct__c()==null) || 
             (this.isBrandAdProduct__c!=null &&
              this.isBrandAdProduct__c.equals(other.getIsBrandAdProduct__c()))) &&
            ((this.isDeleted==null && other.getIsDeleted()==null) || 
             (this.isDeleted!=null &&
              this.isDeleted.equals(other.getIsDeleted()))) &&
            ((this.isInfoGood__c==null && other.getIsInfoGood__c()==null) || 
             (this.isInfoGood__c!=null &&
              this.isInfoGood__c.equals(other.getIsInfoGood__c()))) &&
            ((this.keyWord__c==null && other.getKeyWord__c()==null) || 
             (this.keyWord__c!=null &&
              this.keyWord__c.equals(other.getKeyWord__c()))) &&
            ((this.LTTotalListPrice__c==null && other.getLTTotalListPrice__c()==null) || 
             (this.LTTotalListPrice__c!=null &&
              this.LTTotalListPrice__c.equals(other.getLTTotalListPrice__c()))) &&
            ((this.lastModifiedBy==null && other.getLastModifiedBy()==null) || 
             (this.lastModifiedBy!=null &&
              this.lastModifiedBy.equals(other.getLastModifiedBy()))) &&
            ((this.lastModifiedById==null && other.getLastModifiedById()==null) || 
             (this.lastModifiedById!=null &&
              this.lastModifiedById.equals(other.getLastModifiedById()))) &&
            ((this.lastModifiedDate==null && other.getLastModifiedDate()==null) || 
             (this.lastModifiedDate!=null &&
              this.lastModifiedDate.equals(other.getLastModifiedDate()))) &&
            ((this.listPrice__c==null && other.getListPrice__c()==null) || 
             (this.listPrice__c!=null &&
              this.listPrice__c.equals(other.getListPrice__c()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.needBookInventory__c==null && other.getNeedBookInventory__c()==null) || 
             (this.needBookInventory__c!=null &&
              this.needBookInventory__c.equals(other.getNeedBookInventory__c()))) &&
            ((this.notes==null && other.getNotes()==null) || 
             (this.notes!=null &&
              this.notes.equals(other.getNotes()))) &&
            ((this.notesAndAttachments==null && other.getNotesAndAttachments()==null) || 
             (this.notesAndAttachments!=null &&
              this.notesAndAttachments.equals(other.getNotesAndAttachments()))) &&
            ((this.optyLineItemId__c==null && other.getOptyLineItemId__c()==null) || 
             (this.optyLineItemId__c!=null &&
              this.optyLineItemId__c.equals(other.getOptyLineItemId__c()))) &&
            ((this.processInstances==null && other.getProcessInstances()==null) || 
             (this.processInstances!=null &&
              this.processInstances.equals(other.getProcessInstances()))) &&
            ((this.processSteps==null && other.getProcessSteps()==null) || 
             (this.processSteps!=null &&
              this.processSteps.equals(other.getProcessSteps()))) &&
            ((this.product2__c==null && other.getProduct2__c()==null) || 
             (this.product2__c!=null &&
              this.product2__c.equals(other.getProduct2__c()))) &&
            ((this.product2__r==null && other.getProduct2__r()==null) || 
             (this.product2__r!=null &&
              this.product2__r.equals(other.getProduct2__r()))) &&
            ((this.productADType__c==null && other.getProductADType__c()==null) || 
             (this.productADType__c!=null &&
              this.productADType__c.equals(other.getProductADType__c()))) &&
            ((this.productDetail__c==null && other.getProductDetail__c()==null) || 
             (this.productDetail__c!=null &&
              this.productDetail__c.equals(other.getProductDetail__c()))) &&
            ((this.productType__c==null && other.getProductType__c()==null) || 
             (this.productType__c!=null &&
              this.productType__c.equals(other.getProductType__c()))) &&
            ((this.quantity__c==null && other.getQuantity__c()==null) || 
             (this.quantity__c!=null &&
              this.quantity__c.equals(other.getQuantity__c()))) &&
            ((this.sharedAmount__c==null && other.getSharedAmount__c()==null) || 
             (this.sharedAmount__c!=null &&
              this.sharedAmount__c.equals(other.getSharedAmount__c()))) &&
            ((this.shopAccount__c==null && other.getShopAccount__c()==null) || 
             (this.shopAccount__c!=null &&
              this.shopAccount__c.equals(other.getShopAccount__c()))) &&
            ((this.shopAccount__r==null && other.getShopAccount__r()==null) || 
             (this.shopAccount__r!=null &&
              this.shopAccount__r.equals(other.getShopAccount__r()))) &&
            ((this.showChannel__c==null && other.getShowChannel__c()==null) || 
             (this.showChannel__c!=null &&
              this.showChannel__c.equals(other.getShowChannel__c()))) &&
            ((this.showKeyWord__c==null && other.getShowKeyWord__c()==null) || 
             (this.showKeyWord__c!=null &&
              this.showKeyWord__c.equals(other.getShowKeyWord__c()))) &&
            ((this.showShopAccount__c==null && other.getShowShopAccount__c()==null) || 
             (this.showShopAccount__c!=null &&
              this.showShopAccount__c.equals(other.getShowShopAccount__c()))) &&
            ((this.showSysCrossShopSearch__c==null && other.getShowSysCrossShopSearch__c()==null) || 
             (this.showSysCrossShopSearch__c!=null &&
              this.showSysCrossShopSearch__c.equals(other.getShowSysCrossShopSearch__c()))) &&
            ((this.showSysInventory__c==null && other.getShowSysInventory__c()==null) || 
             (this.showSysInventory__c!=null &&
              this.showSysInventory__c.equals(other.getShowSysInventory__c()))) &&
            ((this.startDate__c==null && other.getStartDate__c()==null) || 
             (this.startDate__c!=null &&
              this.startDate__c.equals(other.getStartDate__c()))) &&
            ((this.systemModstamp==null && other.getSystemModstamp()==null) || 
             (this.systemModstamp!=null &&
              this.systemModstamp.equals(other.getSystemModstamp()))) &&
            ((this.unitPrice__c==null && other.getUnitPrice__c()==null) || 
             (this.unitPrice__c!=null &&
              this.unitPrice__c.equals(other.getUnitPrice__c()))) &&
            ((this.isProductRPAppCalc__c==null && other.getIsProductRPAppCalc__c()==null) || 
             (this.isProductRPAppCalc__c!=null &&
              this.isProductRPAppCalc__c.equals(other.getIsProductRPAppCalc__c()))) &&
            ((this.isProductRPApp__c==null && other.getIsProductRPApp__c()==null) || 
             (this.isProductRPApp__c!=null &&
              this.isProductRPApp__c.equals(other.getIsProductRPApp__c())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAP_IsOtherProduct__c() != null) {
            _hashCode += getAP_IsOtherProduct__c().hashCode();
        }
        if (getAP_OtherProduct__c() != null) {
            _hashCode += getAP_OtherProduct__c().hashCode();
        }
        if (getAttachments() != null) {
            _hashCode += getAttachments().hashCode();
        }
        if (getChannel__c() != null) {
            _hashCode += getChannel__c().hashCode();
        }
        if (getCity__c() != null) {
            _hashCode += getCity__c().hashCode();
        }
        if (getCity__r() != null) {
            _hashCode += getCity__r().hashCode();
        }
        if (getContract__c() != null) {
            _hashCode += getContract__c().hashCode();
        }
        if (getContract__r() != null) {
            _hashCode += getContract__r().hashCode();
        }
        if (getCreatedBy() != null) {
            _hashCode += getCreatedBy().hashCode();
        }
        if (getCreatedById() != null) {
            _hashCode += getCreatedById().hashCode();
        }
        if (getCreatedDate() != null) {
            _hashCode += getCreatedDate().hashCode();
        }
        if (getEditStatus__c() != null) {
            _hashCode += getEditStatus__c().hashCode();
        }
        if (getEndDate__c() != null) {
            _hashCode += getEndDate__c().hashCode();
        }
        if (getFreeProduct__c() != null) {
            _hashCode += getFreeProduct__c().hashCode();
        }
        if (getHistories() != null) {
            _hashCode += getHistories().hashCode();
        }
        if (getInfoGood__c() != null) {
            _hashCode += getInfoGood__c().hashCode();
        }
        if (getInventoryOperationResult__c() != null) {
            _hashCode += getInventoryOperationResult__c().hashCode();
        }
        if (getInventoryStatus__c() != null) {
            _hashCode += getInventoryStatus__c().hashCode();
        }
        if (getIsBrandAD__c() != null) {
            _hashCode += getIsBrandAD__c().hashCode();
        }
        if (getIsBrandAdProduct__c() != null) {
            _hashCode += getIsBrandAdProduct__c().hashCode();
        }
        if (getIsDeleted() != null) {
            _hashCode += getIsDeleted().hashCode();
        }
        if (getIsInfoGood__c() != null) {
            _hashCode += getIsInfoGood__c().hashCode();
        }
        if (getKeyWord__c() != null) {
            _hashCode += getKeyWord__c().hashCode();
        }
        if (getLTTotalListPrice__c() != null) {
            _hashCode += getLTTotalListPrice__c().hashCode();
        }
        if (getLastModifiedBy() != null) {
            _hashCode += getLastModifiedBy().hashCode();
        }
        if (getLastModifiedById() != null) {
            _hashCode += getLastModifiedById().hashCode();
        }
        if (getLastModifiedDate() != null) {
            _hashCode += getLastModifiedDate().hashCode();
        }
        if (getListPrice__c() != null) {
            _hashCode += getListPrice__c().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getNeedBookInventory__c() != null) {
            _hashCode += getNeedBookInventory__c().hashCode();
        }
        if (getNotes() != null) {
            _hashCode += getNotes().hashCode();
        }
        if (getNotesAndAttachments() != null) {
            _hashCode += getNotesAndAttachments().hashCode();
        }
        if (getOptyLineItemId__c() != null) {
            _hashCode += getOptyLineItemId__c().hashCode();
        }
        if (getProcessInstances() != null) {
            _hashCode += getProcessInstances().hashCode();
        }
        if (getProcessSteps() != null) {
            _hashCode += getProcessSteps().hashCode();
        }
        if (getProduct2__c() != null) {
            _hashCode += getProduct2__c().hashCode();
        }
        if (getProduct2__r() != null) {
            _hashCode += getProduct2__r().hashCode();
        }
        if (getProductADType__c() != null) {
            _hashCode += getProductADType__c().hashCode();
        }
        if (getProductDetail__c() != null) {
            _hashCode += getProductDetail__c().hashCode();
        }
        if (getProductType__c() != null) {
            _hashCode += getProductType__c().hashCode();
        }
        if (getQuantity__c() != null) {
            _hashCode += getQuantity__c().hashCode();
        }
        if (getSharedAmount__c() != null) {
            _hashCode += getSharedAmount__c().hashCode();
        }
        if (getShopAccount__c() != null) {
            _hashCode += getShopAccount__c().hashCode();
        }
        if (getShopAccount__r() != null) {
            _hashCode += getShopAccount__r().hashCode();
        }
        if (getShowChannel__c() != null) {
            _hashCode += getShowChannel__c().hashCode();
        }
        if (getShowKeyWord__c() != null) {
            _hashCode += getShowKeyWord__c().hashCode();
        }
        if (getShowShopAccount__c() != null) {
            _hashCode += getShowShopAccount__c().hashCode();
        }
        if (getShowSysCrossShopSearch__c() != null) {
            _hashCode += getShowSysCrossShopSearch__c().hashCode();
        }
        if (getShowSysInventory__c() != null) {
            _hashCode += getShowSysInventory__c().hashCode();
        }
        if (getStartDate__c() != null) {
            _hashCode += getStartDate__c().hashCode();
        }
        if (getSystemModstamp() != null) {
            _hashCode += getSystemModstamp().hashCode();
        }
        if (getUnitPrice__c() != null) {
            _hashCode += getUnitPrice__c().hashCode();
        }
        if (getIsProductRPAppCalc__c() != null) {
            _hashCode += getIsProductRPAppCalc__c().hashCode();
        }
        if (getIsProductRPApp__c() != null) {
            _hashCode += getIsProductRPApp__c().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ContractLineItem__c.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ContractLineItem__c"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AP_IsOtherProduct__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AP_IsOtherProduct__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AP_OtherProduct__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AP_OtherProduct__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Attachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("channel__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Channel__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("city__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "City__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("city__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "City__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "City__c"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contract__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Contract__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contract__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Contract__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Contract"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("editStatus__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "EditStatus__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("endDate__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "EndDate__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("freeProduct__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "FreeProduct__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("histories");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Histories"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("infoGood__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "InfoGood__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inventoryOperationResult__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "InventoryOperationResult__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inventoryStatus__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "InventoryStatus__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isBrandAD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsBrandAD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isBrandAdProduct__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsBrandAdProduct__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isDeleted");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsDeleted"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isInfoGood__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsInfoGood__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("keyWord__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KeyWord__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("LTTotalListPrice__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LTTotalListPrice__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("listPrice__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ListPrice__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("needBookInventory__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NeedBookInventory__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notes");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Notes"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notesAndAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NotesAndAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("optyLineItemId__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OptyLineItemId__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processInstances");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessInstances"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processSteps");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessSteps"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("product2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Product2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("product2__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Product2__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Product2"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("productADType__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProductADType__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("productDetail__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProductDetail__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("productType__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProductType__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("quantity__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Quantity__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sharedAmount__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SharedAmount__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shopAccount__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ShopAccount__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shopAccount__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ShopAccount__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Account"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("showChannel__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ShowChannel__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("showKeyWord__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ShowKeyWord__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("showShopAccount__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ShowShopAccount__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("showSysCrossShopSearch__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ShowSysCrossShopSearch__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("showSysInventory__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ShowSysInventory__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("startDate__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "StartDate__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("systemModstamp");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SystemModstamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("unitPrice__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UnitPrice__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isProductRPAppCalc__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "isProductRPAppCalc__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isProductRPApp__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "isProductRPApp__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
