/**
 * Contract.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.sforce.soap.enterprise.sobject;

public class Contract  extends com.sforce.soap.enterprise.sobject.SObject  implements java.io.Serializable {
    private java.lang.Double AP_AD1StPayPercent__c;

    private java.util.Date AP_FirstPublishDay__c;

    private java.util.Date AP_LastPublishDay__c;

    private java.lang.Double AP_NormalKeyWordsCount__c;

    private java.lang.Double AP_OtherProductCount__c;

    private java.lang.Double AP_PayItemCount__c;

    private java.lang.Double AP_TopKeyWordsCount__c;

    private java.lang.Double AP_TotalDiscount__c;

    private com.sforce.soap.enterprise.sobject.Account account;

    private java.lang.String accountAdress__c;

    private java.lang.String accountId;

    private com.sforce.soap.enterprise.sobject.User activatedBy;

    private java.lang.String activatedById;

    private java.util.Calendar activatedDate;

    private com.sforce.soap.enterprise.QueryResult activityHistories;

    private java.lang.String approvalField__c;

    private java.lang.String approvalMgr1__c;

    private com.sforce.soap.enterprise.sobject.User approvalMgr1__r;

    private java.lang.String approvalMgr2__c;

    private com.sforce.soap.enterprise.sobject.User approvalMgr2__r;

    private java.lang.String approvalMgr3__c;

    private com.sforce.soap.enterprise.sobject.User approvalMgr3__r;

    private java.lang.String approvalMgr4__c;

    private com.sforce.soap.enterprise.sobject.User approvalMgr4__r;

    private com.sforce.soap.enterprise.QueryResult approvals;

    private com.sforce.soap.enterprise.QueryResult attachments;

    private java.lang.Double badContractPRDLT__c;

    private java.lang.String billingCity;

    private java.lang.String billingCountry;

    private java.lang.String billingInfo__c;

    private com.sforce.soap.enterprise.sobject.BillingInfo__c billingInfo__r;

    private java.lang.String billingPostalCode;

    private java.lang.String billingState;

    private java.lang.String billingStreet;

    private java.lang.String cityID__c;

    private java.lang.String city__c;

    private com.sforce.soap.enterprise.sobject.City__c city__r;

    private com.sforce.soap.enterprise.sobject.User companySigned;

    private java.util.Date companySignedDate;

    private java.lang.String companySignedId;

    private java.lang.Boolean confirmViaWeb__c;

    private java.lang.String contractAPStatus__c;

    private com.sforce.soap.enterprise.QueryResult contractBilling__r;

    private java.lang.String contractCalNumber__c;

    private com.sforce.soap.enterprise.QueryResult contractContactRoles;

    private com.sforce.soap.enterprise.QueryResult contractLineItemTemp__r;

    private com.sforce.soap.enterprise.QueryResult contractLineItem__r;

    private java.lang.String contractNumber;

    private java.lang.String contractSerialNO__c;

    private com.sforce.soap.enterprise.QueryResult contractShopAccount__r;

    private java.lang.String contractSource__c;

    private java.lang.String contractStage__c;

    private java.lang.String contractStatus__c;

    private java.lang.Integer contractTerm;

    private java.lang.String contractType__c;

    private java.lang.String contractUpdTrack__c;

    private com.sforce.soap.enterprise.QueryResult contract_BankAccount__r;

    private com.sforce.soap.enterprise.QueryResult contract_PayRule__r;

    private com.sforce.soap.enterprise.QueryResult contract__r;

    private com.sforce.soap.enterprise.sobject.User createdBy;

    private java.lang.String createdById;

    private java.util.Calendar createdDate;

    private com.sforce.soap.enterprise.sobject.Contact customerSigned;

    private java.util.Date customerSignedDate;

    private java.lang.String customerSignedId;

    private java.lang.String customerSignedTitle;

    private com.sforce.soap.enterprise.QueryResult dealGroup__r;

    private java.lang.Double deficitDealAPNumber__c;

    private java.lang.String department__c;

    private java.lang.String description;

    private java.util.Date endDate;

    private com.sforce.soap.enterprise.QueryResult events;

    private java.lang.String freeProductDescShow__c;

    private java.lang.String freeProductDesc__c;

    private java.lang.String globalID__c;

    private java.lang.Double hasFreePrd__c;

    private java.lang.Double hasRPPrd__c;

    private com.sforce.soap.enterprise.QueryResult histories;

    private java.lang.String historyContractURL__c;

    private com.sforce.soap.enterprise.QueryResult invoiceTitle__r;

    private java.lang.Boolean isDeleted;

    private java.lang.Boolean isPay__c;

    private java.lang.Boolean isPaying__c;

    private java.lang.String isPrePayment__c;

    private java.lang.Boolean isProduced__c;

    private java.util.Date lastActivityDate;

    private java.util.Calendar lastApprovedDate;

    private com.sforce.soap.enterprise.sobject.User lastModifiedBy;

    private java.lang.String lastModifiedById;

    private java.util.Calendar lastModifiedDate;

    private java.lang.Double lowestSalesPrice__c;

    private com.sforce.soap.enterprise.QueryResult notes;

    private com.sforce.soap.enterprise.QueryResult notesAndAttachments;

    private com.sforce.soap.enterprise.QueryResult openActivities;

    private java.lang.String opportunityName__c;

    private java.lang.String opportunity__c;

    private com.sforce.soap.enterprise.sobject.Opportunity opportunity__r;

    private com.sforce.soap.enterprise.sobject.User owner;

    private java.lang.String ownerExpirationNotice;

    private java.lang.String ownerId;

    private java.lang.String ownerRole__c;

    private java.lang.Double payRuleType__c;

    private java.lang.String payRule__c;

    private com.sforce.soap.enterprise.sobject.PayRule__c payRule__r;

    private java.lang.Double paymentRollUpPercent__c;

    private java.lang.String paymentTransactionType__c;

    private java.lang.String phone__c;

    private java.lang.Double prePaymentPercent__c;

    private java.lang.Double prePayment__c;

    private com.sforce.soap.enterprise.QueryResult processInstances;

    private com.sforce.soap.enterprise.QueryResult processSteps;

    private java.lang.String projectTeamAprStatus__c;

    private java.util.Date publishMidDay__c;

    private java.lang.String RPApplyDesc__c;

    private java.lang.String RPApplyFormNo__c;

    private java.lang.Boolean readyForApproval__c;

    private com.sforce.soap.enterprise.sobject.RecordType recordType;

    private java.lang.String recordTypeId;

    private java.lang.String registerName__c;

    private java.lang.String relatedContractNumber__c;

    private java.lang.Double remainFunds__c;

    private java.lang.String salesPriceStatus__c;

    private java.lang.String salesmanSighed__c;

    private java.lang.String sequence__c;

    private java.lang.String shippingCity;

    private java.lang.String shippingCountry;

    private java.lang.String shippingPostalCode;

    private java.lang.String shippingState;

    private java.lang.String shippingStreet;

    private java.lang.String showInventoryURL__c;

    private java.lang.String showSHInventoryURL__c;

    private java.lang.String specialTerms;

    private java.util.Date startDate;

    private java.lang.String status;

    private java.lang.String statusCode;

    private java.util.Calendar systemModstamp;

    private com.sforce.soap.enterprise.QueryResult tasks;

    private java.lang.String terminateReason__c;

    private java.lang.Double totalListPrice__c;

    private java.lang.Double totalSalesPrice__c;

    private java.lang.Double wholeDiscount__c;

    private java.lang.Double wholeListPrice__c;

    private com.sforce.soap.enterprise.QueryResult contractcontact__r;

    private com.sforce.soap.enterprise.QueryResult deal__r;

    private java.lang.Boolean isPublish__c;

    private java.lang.Boolean isQualified__c;

    public Contract() {
    }

    public Contract(
           java.lang.String[] fieldsToNull,
           java.lang.String id,
           java.lang.Double AP_AD1StPayPercent__c,
           java.util.Date AP_FirstPublishDay__c,
           java.util.Date AP_LastPublishDay__c,
           java.lang.Double AP_NormalKeyWordsCount__c,
           java.lang.Double AP_OtherProductCount__c,
           java.lang.Double AP_PayItemCount__c,
           java.lang.Double AP_TopKeyWordsCount__c,
           java.lang.Double AP_TotalDiscount__c,
           com.sforce.soap.enterprise.sobject.Account account,
           java.lang.String accountAdress__c,
           java.lang.String accountId,
           com.sforce.soap.enterprise.sobject.User activatedBy,
           java.lang.String activatedById,
           java.util.Calendar activatedDate,
           com.sforce.soap.enterprise.QueryResult activityHistories,
           java.lang.String approvalField__c,
           java.lang.String approvalMgr1__c,
           com.sforce.soap.enterprise.sobject.User approvalMgr1__r,
           java.lang.String approvalMgr2__c,
           com.sforce.soap.enterprise.sobject.User approvalMgr2__r,
           java.lang.String approvalMgr3__c,
           com.sforce.soap.enterprise.sobject.User approvalMgr3__r,
           java.lang.String approvalMgr4__c,
           com.sforce.soap.enterprise.sobject.User approvalMgr4__r,
           com.sforce.soap.enterprise.QueryResult approvals,
           com.sforce.soap.enterprise.QueryResult attachments,
           java.lang.Double badContractPRDLT__c,
           java.lang.String billingCity,
           java.lang.String billingCountry,
           java.lang.String billingInfo__c,
           com.sforce.soap.enterprise.sobject.BillingInfo__c billingInfo__r,
           java.lang.String billingPostalCode,
           java.lang.String billingState,
           java.lang.String billingStreet,
           java.lang.String cityID__c,
           java.lang.String city__c,
           com.sforce.soap.enterprise.sobject.City__c city__r,
           com.sforce.soap.enterprise.sobject.User companySigned,
           java.util.Date companySignedDate,
           java.lang.String companySignedId,
           java.lang.Boolean confirmViaWeb__c,
           java.lang.String contractAPStatus__c,
           com.sforce.soap.enterprise.QueryResult contractBilling__r,
           java.lang.String contractCalNumber__c,
           com.sforce.soap.enterprise.QueryResult contractContactRoles,
           com.sforce.soap.enterprise.QueryResult contractLineItemTemp__r,
           com.sforce.soap.enterprise.QueryResult contractLineItem__r,
           java.lang.String contractNumber,
           java.lang.String contractSerialNO__c,
           com.sforce.soap.enterprise.QueryResult contractShopAccount__r,
           java.lang.String contractSource__c,
           java.lang.String contractStage__c,
           java.lang.String contractStatus__c,
           java.lang.Integer contractTerm,
           java.lang.String contractType__c,
           java.lang.String contractUpdTrack__c,
           com.sforce.soap.enterprise.QueryResult contract_BankAccount__r,
           com.sforce.soap.enterprise.QueryResult contract_PayRule__r,
           com.sforce.soap.enterprise.QueryResult contract__r,
           com.sforce.soap.enterprise.sobject.User createdBy,
           java.lang.String createdById,
           java.util.Calendar createdDate,
           com.sforce.soap.enterprise.sobject.Contact customerSigned,
           java.util.Date customerSignedDate,
           java.lang.String customerSignedId,
           java.lang.String customerSignedTitle,
           com.sforce.soap.enterprise.QueryResult dealGroup__r,
           java.lang.Double deficitDealAPNumber__c,
           java.lang.String department__c,
           java.lang.String description,
           java.util.Date endDate,
           com.sforce.soap.enterprise.QueryResult events,
           java.lang.String freeProductDescShow__c,
           java.lang.String freeProductDesc__c,
           java.lang.String globalID__c,
           java.lang.Double hasFreePrd__c,
           java.lang.Double hasRPPrd__c,
           com.sforce.soap.enterprise.QueryResult histories,
           java.lang.String historyContractURL__c,
           com.sforce.soap.enterprise.QueryResult invoiceTitle__r,
           java.lang.Boolean isDeleted,
           java.lang.Boolean isPay__c,
           java.lang.Boolean isPaying__c,
           java.lang.String isPrePayment__c,
           java.lang.Boolean isProduced__c,
           java.util.Date lastActivityDate,
           java.util.Calendar lastApprovedDate,
           com.sforce.soap.enterprise.sobject.User lastModifiedBy,
           java.lang.String lastModifiedById,
           java.util.Calendar lastModifiedDate,
           java.lang.Double lowestSalesPrice__c,
           com.sforce.soap.enterprise.QueryResult notes,
           com.sforce.soap.enterprise.QueryResult notesAndAttachments,
           com.sforce.soap.enterprise.QueryResult openActivities,
           java.lang.String opportunityName__c,
           java.lang.String opportunity__c,
           com.sforce.soap.enterprise.sobject.Opportunity opportunity__r,
           com.sforce.soap.enterprise.sobject.User owner,
           java.lang.String ownerExpirationNotice,
           java.lang.String ownerId,
           java.lang.String ownerRole__c,
           java.lang.Double payRuleType__c,
           java.lang.String payRule__c,
           com.sforce.soap.enterprise.sobject.PayRule__c payRule__r,
           java.lang.Double paymentRollUpPercent__c,
           java.lang.String paymentTransactionType__c,
           java.lang.String phone__c,
           java.lang.Double prePaymentPercent__c,
           java.lang.Double prePayment__c,
           com.sforce.soap.enterprise.QueryResult processInstances,
           com.sforce.soap.enterprise.QueryResult processSteps,
           java.lang.String projectTeamAprStatus__c,
           java.util.Date publishMidDay__c,
           java.lang.String RPApplyDesc__c,
           java.lang.String RPApplyFormNo__c,
           java.lang.Boolean readyForApproval__c,
           com.sforce.soap.enterprise.sobject.RecordType recordType,
           java.lang.String recordTypeId,
           java.lang.String registerName__c,
           java.lang.String relatedContractNumber__c,
           java.lang.Double remainFunds__c,
           java.lang.String salesPriceStatus__c,
           java.lang.String salesmanSighed__c,
           java.lang.String sequence__c,
           java.lang.String shippingCity,
           java.lang.String shippingCountry,
           java.lang.String shippingPostalCode,
           java.lang.String shippingState,
           java.lang.String shippingStreet,
           java.lang.String showInventoryURL__c,
           java.lang.String showSHInventoryURL__c,
           java.lang.String specialTerms,
           java.util.Date startDate,
           java.lang.String status,
           java.lang.String statusCode,
           java.util.Calendar systemModstamp,
           com.sforce.soap.enterprise.QueryResult tasks,
           java.lang.String terminateReason__c,
           java.lang.Double totalListPrice__c,
           java.lang.Double totalSalesPrice__c,
           java.lang.Double wholeDiscount__c,
           java.lang.Double wholeListPrice__c,
           com.sforce.soap.enterprise.QueryResult contractcontact__r,
           com.sforce.soap.enterprise.QueryResult deal__r,
           java.lang.Boolean isPublish__c,
           java.lang.Boolean isQualified__c) {
        super(
            fieldsToNull,
            id);
        this.AP_AD1StPayPercent__c = AP_AD1StPayPercent__c;
        this.AP_FirstPublishDay__c = AP_FirstPublishDay__c;
        this.AP_LastPublishDay__c = AP_LastPublishDay__c;
        this.AP_NormalKeyWordsCount__c = AP_NormalKeyWordsCount__c;
        this.AP_OtherProductCount__c = AP_OtherProductCount__c;
        this.AP_PayItemCount__c = AP_PayItemCount__c;
        this.AP_TopKeyWordsCount__c = AP_TopKeyWordsCount__c;
        this.AP_TotalDiscount__c = AP_TotalDiscount__c;
        this.account = account;
        this.accountAdress__c = accountAdress__c;
        this.accountId = accountId;
        this.activatedBy = activatedBy;
        this.activatedById = activatedById;
        this.activatedDate = activatedDate;
        this.activityHistories = activityHistories;
        this.approvalField__c = approvalField__c;
        this.approvalMgr1__c = approvalMgr1__c;
        this.approvalMgr1__r = approvalMgr1__r;
        this.approvalMgr2__c = approvalMgr2__c;
        this.approvalMgr2__r = approvalMgr2__r;
        this.approvalMgr3__c = approvalMgr3__c;
        this.approvalMgr3__r = approvalMgr3__r;
        this.approvalMgr4__c = approvalMgr4__c;
        this.approvalMgr4__r = approvalMgr4__r;
        this.approvals = approvals;
        this.attachments = attachments;
        this.badContractPRDLT__c = badContractPRDLT__c;
        this.billingCity = billingCity;
        this.billingCountry = billingCountry;
        this.billingInfo__c = billingInfo__c;
        this.billingInfo__r = billingInfo__r;
        this.billingPostalCode = billingPostalCode;
        this.billingState = billingState;
        this.billingStreet = billingStreet;
        this.cityID__c = cityID__c;
        this.city__c = city__c;
        this.city__r = city__r;
        this.companySigned = companySigned;
        this.companySignedDate = companySignedDate;
        this.companySignedId = companySignedId;
        this.confirmViaWeb__c = confirmViaWeb__c;
        this.contractAPStatus__c = contractAPStatus__c;
        this.contractBilling__r = contractBilling__r;
        this.contractCalNumber__c = contractCalNumber__c;
        this.contractContactRoles = contractContactRoles;
        this.contractLineItemTemp__r = contractLineItemTemp__r;
        this.contractLineItem__r = contractLineItem__r;
        this.contractNumber = contractNumber;
        this.contractSerialNO__c = contractSerialNO__c;
        this.contractShopAccount__r = contractShopAccount__r;
        this.contractSource__c = contractSource__c;
        this.contractStage__c = contractStage__c;
        this.contractStatus__c = contractStatus__c;
        this.contractTerm = contractTerm;
        this.contractType__c = contractType__c;
        this.contractUpdTrack__c = contractUpdTrack__c;
        this.contract_BankAccount__r = contract_BankAccount__r;
        this.contract_PayRule__r = contract_PayRule__r;
        this.contract__r = contract__r;
        this.createdBy = createdBy;
        this.createdById = createdById;
        this.createdDate = createdDate;
        this.customerSigned = customerSigned;
        this.customerSignedDate = customerSignedDate;
        this.customerSignedId = customerSignedId;
        this.customerSignedTitle = customerSignedTitle;
        this.dealGroup__r = dealGroup__r;
        this.deficitDealAPNumber__c = deficitDealAPNumber__c;
        this.department__c = department__c;
        this.description = description;
        this.endDate = endDate;
        this.events = events;
        this.freeProductDescShow__c = freeProductDescShow__c;
        this.freeProductDesc__c = freeProductDesc__c;
        this.globalID__c = globalID__c;
        this.hasFreePrd__c = hasFreePrd__c;
        this.hasRPPrd__c = hasRPPrd__c;
        this.histories = histories;
        this.historyContractURL__c = historyContractURL__c;
        this.invoiceTitle__r = invoiceTitle__r;
        this.isDeleted = isDeleted;
        this.isPay__c = isPay__c;
        this.isPaying__c = isPaying__c;
        this.isPrePayment__c = isPrePayment__c;
        this.isProduced__c = isProduced__c;
        this.lastActivityDate = lastActivityDate;
        this.lastApprovedDate = lastApprovedDate;
        this.lastModifiedBy = lastModifiedBy;
        this.lastModifiedById = lastModifiedById;
        this.lastModifiedDate = lastModifiedDate;
        this.lowestSalesPrice__c = lowestSalesPrice__c;
        this.notes = notes;
        this.notesAndAttachments = notesAndAttachments;
        this.openActivities = openActivities;
        this.opportunityName__c = opportunityName__c;
        this.opportunity__c = opportunity__c;
        this.opportunity__r = opportunity__r;
        this.owner = owner;
        this.ownerExpirationNotice = ownerExpirationNotice;
        this.ownerId = ownerId;
        this.ownerRole__c = ownerRole__c;
        this.payRuleType__c = payRuleType__c;
        this.payRule__c = payRule__c;
        this.payRule__r = payRule__r;
        this.paymentRollUpPercent__c = paymentRollUpPercent__c;
        this.paymentTransactionType__c = paymentTransactionType__c;
        this.phone__c = phone__c;
        this.prePaymentPercent__c = prePaymentPercent__c;
        this.prePayment__c = prePayment__c;
        this.processInstances = processInstances;
        this.processSteps = processSteps;
        this.projectTeamAprStatus__c = projectTeamAprStatus__c;
        this.publishMidDay__c = publishMidDay__c;
        this.RPApplyDesc__c = RPApplyDesc__c;
        this.RPApplyFormNo__c = RPApplyFormNo__c;
        this.readyForApproval__c = readyForApproval__c;
        this.recordType = recordType;
        this.recordTypeId = recordTypeId;
        this.registerName__c = registerName__c;
        this.relatedContractNumber__c = relatedContractNumber__c;
        this.remainFunds__c = remainFunds__c;
        this.salesPriceStatus__c = salesPriceStatus__c;
        this.salesmanSighed__c = salesmanSighed__c;
        this.sequence__c = sequence__c;
        this.shippingCity = shippingCity;
        this.shippingCountry = shippingCountry;
        this.shippingPostalCode = shippingPostalCode;
        this.shippingState = shippingState;
        this.shippingStreet = shippingStreet;
        this.showInventoryURL__c = showInventoryURL__c;
        this.showSHInventoryURL__c = showSHInventoryURL__c;
        this.specialTerms = specialTerms;
        this.startDate = startDate;
        this.status = status;
        this.statusCode = statusCode;
        this.systemModstamp = systemModstamp;
        this.tasks = tasks;
        this.terminateReason__c = terminateReason__c;
        this.totalListPrice__c = totalListPrice__c;
        this.totalSalesPrice__c = totalSalesPrice__c;
        this.wholeDiscount__c = wholeDiscount__c;
        this.wholeListPrice__c = wholeListPrice__c;
        this.contractcontact__r = contractcontact__r;
        this.deal__r = deal__r;
        this.isPublish__c = isPublish__c;
        this.isQualified__c = isQualified__c;
    }


    /**
     * Gets the AP_AD1StPayPercent__c value for this Contract.
     * 
     * @return AP_AD1StPayPercent__c
     */
    public java.lang.Double getAP_AD1StPayPercent__c() {
        return AP_AD1StPayPercent__c;
    }


    /**
     * Sets the AP_AD1StPayPercent__c value for this Contract.
     * 
     * @param AP_AD1StPayPercent__c
     */
    public void setAP_AD1StPayPercent__c(java.lang.Double AP_AD1StPayPercent__c) {
        this.AP_AD1StPayPercent__c = AP_AD1StPayPercent__c;
    }


    /**
     * Gets the AP_FirstPublishDay__c value for this Contract.
     * 
     * @return AP_FirstPublishDay__c
     */
    public java.util.Date getAP_FirstPublishDay__c() {
        return AP_FirstPublishDay__c;
    }


    /**
     * Sets the AP_FirstPublishDay__c value for this Contract.
     * 
     * @param AP_FirstPublishDay__c
     */
    public void setAP_FirstPublishDay__c(java.util.Date AP_FirstPublishDay__c) {
        this.AP_FirstPublishDay__c = AP_FirstPublishDay__c;
    }


    /**
     * Gets the AP_LastPublishDay__c value for this Contract.
     * 
     * @return AP_LastPublishDay__c
     */
    public java.util.Date getAP_LastPublishDay__c() {
        return AP_LastPublishDay__c;
    }


    /**
     * Sets the AP_LastPublishDay__c value for this Contract.
     * 
     * @param AP_LastPublishDay__c
     */
    public void setAP_LastPublishDay__c(java.util.Date AP_LastPublishDay__c) {
        this.AP_LastPublishDay__c = AP_LastPublishDay__c;
    }


    /**
     * Gets the AP_NormalKeyWordsCount__c value for this Contract.
     * 
     * @return AP_NormalKeyWordsCount__c
     */
    public java.lang.Double getAP_NormalKeyWordsCount__c() {
        return AP_NormalKeyWordsCount__c;
    }


    /**
     * Sets the AP_NormalKeyWordsCount__c value for this Contract.
     * 
     * @param AP_NormalKeyWordsCount__c
     */
    public void setAP_NormalKeyWordsCount__c(java.lang.Double AP_NormalKeyWordsCount__c) {
        this.AP_NormalKeyWordsCount__c = AP_NormalKeyWordsCount__c;
    }


    /**
     * Gets the AP_OtherProductCount__c value for this Contract.
     * 
     * @return AP_OtherProductCount__c
     */
    public java.lang.Double getAP_OtherProductCount__c() {
        return AP_OtherProductCount__c;
    }


    /**
     * Sets the AP_OtherProductCount__c value for this Contract.
     * 
     * @param AP_OtherProductCount__c
     */
    public void setAP_OtherProductCount__c(java.lang.Double AP_OtherProductCount__c) {
        this.AP_OtherProductCount__c = AP_OtherProductCount__c;
    }


    /**
     * Gets the AP_PayItemCount__c value for this Contract.
     * 
     * @return AP_PayItemCount__c
     */
    public java.lang.Double getAP_PayItemCount__c() {
        return AP_PayItemCount__c;
    }


    /**
     * Sets the AP_PayItemCount__c value for this Contract.
     * 
     * @param AP_PayItemCount__c
     */
    public void setAP_PayItemCount__c(java.lang.Double AP_PayItemCount__c) {
        this.AP_PayItemCount__c = AP_PayItemCount__c;
    }


    /**
     * Gets the AP_TopKeyWordsCount__c value for this Contract.
     * 
     * @return AP_TopKeyWordsCount__c
     */
    public java.lang.Double getAP_TopKeyWordsCount__c() {
        return AP_TopKeyWordsCount__c;
    }


    /**
     * Sets the AP_TopKeyWordsCount__c value for this Contract.
     * 
     * @param AP_TopKeyWordsCount__c
     */
    public void setAP_TopKeyWordsCount__c(java.lang.Double AP_TopKeyWordsCount__c) {
        this.AP_TopKeyWordsCount__c = AP_TopKeyWordsCount__c;
    }


    /**
     * Gets the AP_TotalDiscount__c value for this Contract.
     * 
     * @return AP_TotalDiscount__c
     */
    public java.lang.Double getAP_TotalDiscount__c() {
        return AP_TotalDiscount__c;
    }


    /**
     * Sets the AP_TotalDiscount__c value for this Contract.
     * 
     * @param AP_TotalDiscount__c
     */
    public void setAP_TotalDiscount__c(java.lang.Double AP_TotalDiscount__c) {
        this.AP_TotalDiscount__c = AP_TotalDiscount__c;
    }


    /**
     * Gets the account value for this Contract.
     * 
     * @return account
     */
    public com.sforce.soap.enterprise.sobject.Account getAccount() {
        return account;
    }


    /**
     * Sets the account value for this Contract.
     * 
     * @param account
     */
    public void setAccount(com.sforce.soap.enterprise.sobject.Account account) {
        this.account = account;
    }


    /**
     * Gets the accountAdress__c value for this Contract.
     * 
     * @return accountAdress__c
     */
    public java.lang.String getAccountAdress__c() {
        return accountAdress__c;
    }


    /**
     * Sets the accountAdress__c value for this Contract.
     * 
     * @param accountAdress__c
     */
    public void setAccountAdress__c(java.lang.String accountAdress__c) {
        this.accountAdress__c = accountAdress__c;
    }


    /**
     * Gets the accountId value for this Contract.
     * 
     * @return accountId
     */
    public java.lang.String getAccountId() {
        return accountId;
    }


    /**
     * Sets the accountId value for this Contract.
     * 
     * @param accountId
     */
    public void setAccountId(java.lang.String accountId) {
        this.accountId = accountId;
    }


    /**
     * Gets the activatedBy value for this Contract.
     * 
     * @return activatedBy
     */
    public com.sforce.soap.enterprise.sobject.User getActivatedBy() {
        return activatedBy;
    }


    /**
     * Sets the activatedBy value for this Contract.
     * 
     * @param activatedBy
     */
    public void setActivatedBy(com.sforce.soap.enterprise.sobject.User activatedBy) {
        this.activatedBy = activatedBy;
    }


    /**
     * Gets the activatedById value for this Contract.
     * 
     * @return activatedById
     */
    public java.lang.String getActivatedById() {
        return activatedById;
    }


    /**
     * Sets the activatedById value for this Contract.
     * 
     * @param activatedById
     */
    public void setActivatedById(java.lang.String activatedById) {
        this.activatedById = activatedById;
    }


    /**
     * Gets the activatedDate value for this Contract.
     * 
     * @return activatedDate
     */
    public java.util.Calendar getActivatedDate() {
        return activatedDate;
    }


    /**
     * Sets the activatedDate value for this Contract.
     * 
     * @param activatedDate
     */
    public void setActivatedDate(java.util.Calendar activatedDate) {
        this.activatedDate = activatedDate;
    }


    /**
     * Gets the activityHistories value for this Contract.
     * 
     * @return activityHistories
     */
    public com.sforce.soap.enterprise.QueryResult getActivityHistories() {
        return activityHistories;
    }


    /**
     * Sets the activityHistories value for this Contract.
     * 
     * @param activityHistories
     */
    public void setActivityHistories(com.sforce.soap.enterprise.QueryResult activityHistories) {
        this.activityHistories = activityHistories;
    }


    /**
     * Gets the approvalField__c value for this Contract.
     * 
     * @return approvalField__c
     */
    public java.lang.String getApprovalField__c() {
        return approvalField__c;
    }


    /**
     * Sets the approvalField__c value for this Contract.
     * 
     * @param approvalField__c
     */
    public void setApprovalField__c(java.lang.String approvalField__c) {
        this.approvalField__c = approvalField__c;
    }


    /**
     * Gets the approvalMgr1__c value for this Contract.
     * 
     * @return approvalMgr1__c
     */
    public java.lang.String getApprovalMgr1__c() {
        return approvalMgr1__c;
    }


    /**
     * Sets the approvalMgr1__c value for this Contract.
     * 
     * @param approvalMgr1__c
     */
    public void setApprovalMgr1__c(java.lang.String approvalMgr1__c) {
        this.approvalMgr1__c = approvalMgr1__c;
    }


    /**
     * Gets the approvalMgr1__r value for this Contract.
     * 
     * @return approvalMgr1__r
     */
    public com.sforce.soap.enterprise.sobject.User getApprovalMgr1__r() {
        return approvalMgr1__r;
    }


    /**
     * Sets the approvalMgr1__r value for this Contract.
     * 
     * @param approvalMgr1__r
     */
    public void setApprovalMgr1__r(com.sforce.soap.enterprise.sobject.User approvalMgr1__r) {
        this.approvalMgr1__r = approvalMgr1__r;
    }


    /**
     * Gets the approvalMgr2__c value for this Contract.
     * 
     * @return approvalMgr2__c
     */
    public java.lang.String getApprovalMgr2__c() {
        return approvalMgr2__c;
    }


    /**
     * Sets the approvalMgr2__c value for this Contract.
     * 
     * @param approvalMgr2__c
     */
    public void setApprovalMgr2__c(java.lang.String approvalMgr2__c) {
        this.approvalMgr2__c = approvalMgr2__c;
    }


    /**
     * Gets the approvalMgr2__r value for this Contract.
     * 
     * @return approvalMgr2__r
     */
    public com.sforce.soap.enterprise.sobject.User getApprovalMgr2__r() {
        return approvalMgr2__r;
    }


    /**
     * Sets the approvalMgr2__r value for this Contract.
     * 
     * @param approvalMgr2__r
     */
    public void setApprovalMgr2__r(com.sforce.soap.enterprise.sobject.User approvalMgr2__r) {
        this.approvalMgr2__r = approvalMgr2__r;
    }


    /**
     * Gets the approvalMgr3__c value for this Contract.
     * 
     * @return approvalMgr3__c
     */
    public java.lang.String getApprovalMgr3__c() {
        return approvalMgr3__c;
    }


    /**
     * Sets the approvalMgr3__c value for this Contract.
     * 
     * @param approvalMgr3__c
     */
    public void setApprovalMgr3__c(java.lang.String approvalMgr3__c) {
        this.approvalMgr3__c = approvalMgr3__c;
    }


    /**
     * Gets the approvalMgr3__r value for this Contract.
     * 
     * @return approvalMgr3__r
     */
    public com.sforce.soap.enterprise.sobject.User getApprovalMgr3__r() {
        return approvalMgr3__r;
    }


    /**
     * Sets the approvalMgr3__r value for this Contract.
     * 
     * @param approvalMgr3__r
     */
    public void setApprovalMgr3__r(com.sforce.soap.enterprise.sobject.User approvalMgr3__r) {
        this.approvalMgr3__r = approvalMgr3__r;
    }


    /**
     * Gets the approvalMgr4__c value for this Contract.
     * 
     * @return approvalMgr4__c
     */
    public java.lang.String getApprovalMgr4__c() {
        return approvalMgr4__c;
    }


    /**
     * Sets the approvalMgr4__c value for this Contract.
     * 
     * @param approvalMgr4__c
     */
    public void setApprovalMgr4__c(java.lang.String approvalMgr4__c) {
        this.approvalMgr4__c = approvalMgr4__c;
    }


    /**
     * Gets the approvalMgr4__r value for this Contract.
     * 
     * @return approvalMgr4__r
     */
    public com.sforce.soap.enterprise.sobject.User getApprovalMgr4__r() {
        return approvalMgr4__r;
    }


    /**
     * Sets the approvalMgr4__r value for this Contract.
     * 
     * @param approvalMgr4__r
     */
    public void setApprovalMgr4__r(com.sforce.soap.enterprise.sobject.User approvalMgr4__r) {
        this.approvalMgr4__r = approvalMgr4__r;
    }


    /**
     * Gets the approvals value for this Contract.
     * 
     * @return approvals
     */
    public com.sforce.soap.enterprise.QueryResult getApprovals() {
        return approvals;
    }


    /**
     * Sets the approvals value for this Contract.
     * 
     * @param approvals
     */
    public void setApprovals(com.sforce.soap.enterprise.QueryResult approvals) {
        this.approvals = approvals;
    }


    /**
     * Gets the attachments value for this Contract.
     * 
     * @return attachments
     */
    public com.sforce.soap.enterprise.QueryResult getAttachments() {
        return attachments;
    }


    /**
     * Sets the attachments value for this Contract.
     * 
     * @param attachments
     */
    public void setAttachments(com.sforce.soap.enterprise.QueryResult attachments) {
        this.attachments = attachments;
    }


    /**
     * Gets the badContractPRDLT__c value for this Contract.
     * 
     * @return badContractPRDLT__c
     */
    public java.lang.Double getBadContractPRDLT__c() {
        return badContractPRDLT__c;
    }


    /**
     * Sets the badContractPRDLT__c value for this Contract.
     * 
     * @param badContractPRDLT__c
     */
    public void setBadContractPRDLT__c(java.lang.Double badContractPRDLT__c) {
        this.badContractPRDLT__c = badContractPRDLT__c;
    }


    /**
     * Gets the billingCity value for this Contract.
     * 
     * @return billingCity
     */
    public java.lang.String getBillingCity() {
        return billingCity;
    }


    /**
     * Sets the billingCity value for this Contract.
     * 
     * @param billingCity
     */
    public void setBillingCity(java.lang.String billingCity) {
        this.billingCity = billingCity;
    }


    /**
     * Gets the billingCountry value for this Contract.
     * 
     * @return billingCountry
     */
    public java.lang.String getBillingCountry() {
        return billingCountry;
    }


    /**
     * Sets the billingCountry value for this Contract.
     * 
     * @param billingCountry
     */
    public void setBillingCountry(java.lang.String billingCountry) {
        this.billingCountry = billingCountry;
    }


    /**
     * Gets the billingInfo__c value for this Contract.
     * 
     * @return billingInfo__c
     */
    public java.lang.String getBillingInfo__c() {
        return billingInfo__c;
    }


    /**
     * Sets the billingInfo__c value for this Contract.
     * 
     * @param billingInfo__c
     */
    public void setBillingInfo__c(java.lang.String billingInfo__c) {
        this.billingInfo__c = billingInfo__c;
    }


    /**
     * Gets the billingInfo__r value for this Contract.
     * 
     * @return billingInfo__r
     */
    public com.sforce.soap.enterprise.sobject.BillingInfo__c getBillingInfo__r() {
        return billingInfo__r;
    }


    /**
     * Sets the billingInfo__r value for this Contract.
     * 
     * @param billingInfo__r
     */
    public void setBillingInfo__r(com.sforce.soap.enterprise.sobject.BillingInfo__c billingInfo__r) {
        this.billingInfo__r = billingInfo__r;
    }


    /**
     * Gets the billingPostalCode value for this Contract.
     * 
     * @return billingPostalCode
     */
    public java.lang.String getBillingPostalCode() {
        return billingPostalCode;
    }


    /**
     * Sets the billingPostalCode value for this Contract.
     * 
     * @param billingPostalCode
     */
    public void setBillingPostalCode(java.lang.String billingPostalCode) {
        this.billingPostalCode = billingPostalCode;
    }


    /**
     * Gets the billingState value for this Contract.
     * 
     * @return billingState
     */
    public java.lang.String getBillingState() {
        return billingState;
    }


    /**
     * Sets the billingState value for this Contract.
     * 
     * @param billingState
     */
    public void setBillingState(java.lang.String billingState) {
        this.billingState = billingState;
    }


    /**
     * Gets the billingStreet value for this Contract.
     * 
     * @return billingStreet
     */
    public java.lang.String getBillingStreet() {
        return billingStreet;
    }


    /**
     * Sets the billingStreet value for this Contract.
     * 
     * @param billingStreet
     */
    public void setBillingStreet(java.lang.String billingStreet) {
        this.billingStreet = billingStreet;
    }


    /**
     * Gets the cityID__c value for this Contract.
     * 
     * @return cityID__c
     */
    public java.lang.String getCityID__c() {
        return cityID__c;
    }


    /**
     * Sets the cityID__c value for this Contract.
     * 
     * @param cityID__c
     */
    public void setCityID__c(java.lang.String cityID__c) {
        this.cityID__c = cityID__c;
    }


    /**
     * Gets the city__c value for this Contract.
     * 
     * @return city__c
     */
    public java.lang.String getCity__c() {
        return city__c;
    }


    /**
     * Sets the city__c value for this Contract.
     * 
     * @param city__c
     */
    public void setCity__c(java.lang.String city__c) {
        this.city__c = city__c;
    }


    /**
     * Gets the city__r value for this Contract.
     * 
     * @return city__r
     */
    public com.sforce.soap.enterprise.sobject.City__c getCity__r() {
        return city__r;
    }


    /**
     * Sets the city__r value for this Contract.
     * 
     * @param city__r
     */
    public void setCity__r(com.sforce.soap.enterprise.sobject.City__c city__r) {
        this.city__r = city__r;
    }


    /**
     * Gets the companySigned value for this Contract.
     * 
     * @return companySigned
     */
    public com.sforce.soap.enterprise.sobject.User getCompanySigned() {
        return companySigned;
    }


    /**
     * Sets the companySigned value for this Contract.
     * 
     * @param companySigned
     */
    public void setCompanySigned(com.sforce.soap.enterprise.sobject.User companySigned) {
        this.companySigned = companySigned;
    }


    /**
     * Gets the companySignedDate value for this Contract.
     * 
     * @return companySignedDate
     */
    public java.util.Date getCompanySignedDate() {
        return companySignedDate;
    }


    /**
     * Sets the companySignedDate value for this Contract.
     * 
     * @param companySignedDate
     */
    public void setCompanySignedDate(java.util.Date companySignedDate) {
        this.companySignedDate = companySignedDate;
    }


    /**
     * Gets the companySignedId value for this Contract.
     * 
     * @return companySignedId
     */
    public java.lang.String getCompanySignedId() {
        return companySignedId;
    }


    /**
     * Sets the companySignedId value for this Contract.
     * 
     * @param companySignedId
     */
    public void setCompanySignedId(java.lang.String companySignedId) {
        this.companySignedId = companySignedId;
    }


    /**
     * Gets the confirmViaWeb__c value for this Contract.
     * 
     * @return confirmViaWeb__c
     */
    public java.lang.Boolean getConfirmViaWeb__c() {
        return confirmViaWeb__c;
    }


    /**
     * Sets the confirmViaWeb__c value for this Contract.
     * 
     * @param confirmViaWeb__c
     */
    public void setConfirmViaWeb__c(java.lang.Boolean confirmViaWeb__c) {
        this.confirmViaWeb__c = confirmViaWeb__c;
    }


    /**
     * Gets the contractAPStatus__c value for this Contract.
     * 
     * @return contractAPStatus__c
     */
    public java.lang.String getContractAPStatus__c() {
        return contractAPStatus__c;
    }


    /**
     * Sets the contractAPStatus__c value for this Contract.
     * 
     * @param contractAPStatus__c
     */
    public void setContractAPStatus__c(java.lang.String contractAPStatus__c) {
        this.contractAPStatus__c = contractAPStatus__c;
    }


    /**
     * Gets the contractBilling__r value for this Contract.
     * 
     * @return contractBilling__r
     */
    public com.sforce.soap.enterprise.QueryResult getContractBilling__r() {
        return contractBilling__r;
    }


    /**
     * Sets the contractBilling__r value for this Contract.
     * 
     * @param contractBilling__r
     */
    public void setContractBilling__r(com.sforce.soap.enterprise.QueryResult contractBilling__r) {
        this.contractBilling__r = contractBilling__r;
    }


    /**
     * Gets the contractCalNumber__c value for this Contract.
     * 
     * @return contractCalNumber__c
     */
    public java.lang.String getContractCalNumber__c() {
        return contractCalNumber__c;
    }


    /**
     * Sets the contractCalNumber__c value for this Contract.
     * 
     * @param contractCalNumber__c
     */
    public void setContractCalNumber__c(java.lang.String contractCalNumber__c) {
        this.contractCalNumber__c = contractCalNumber__c;
    }


    /**
     * Gets the contractContactRoles value for this Contract.
     * 
     * @return contractContactRoles
     */
    public com.sforce.soap.enterprise.QueryResult getContractContactRoles() {
        return contractContactRoles;
    }


    /**
     * Sets the contractContactRoles value for this Contract.
     * 
     * @param contractContactRoles
     */
    public void setContractContactRoles(com.sforce.soap.enterprise.QueryResult contractContactRoles) {
        this.contractContactRoles = contractContactRoles;
    }


    /**
     * Gets the contractLineItemTemp__r value for this Contract.
     * 
     * @return contractLineItemTemp__r
     */
    public com.sforce.soap.enterprise.QueryResult getContractLineItemTemp__r() {
        return contractLineItemTemp__r;
    }


    /**
     * Sets the contractLineItemTemp__r value for this Contract.
     * 
     * @param contractLineItemTemp__r
     */
    public void setContractLineItemTemp__r(com.sforce.soap.enterprise.QueryResult contractLineItemTemp__r) {
        this.contractLineItemTemp__r = contractLineItemTemp__r;
    }


    /**
     * Gets the contractLineItem__r value for this Contract.
     * 
     * @return contractLineItem__r
     */
    public com.sforce.soap.enterprise.QueryResult getContractLineItem__r() {
        return contractLineItem__r;
    }


    /**
     * Sets the contractLineItem__r value for this Contract.
     * 
     * @param contractLineItem__r
     */
    public void setContractLineItem__r(com.sforce.soap.enterprise.QueryResult contractLineItem__r) {
        this.contractLineItem__r = contractLineItem__r;
    }


    /**
     * Gets the contractNumber value for this Contract.
     * 
     * @return contractNumber
     */
    public java.lang.String getContractNumber() {
        return contractNumber;
    }


    /**
     * Sets the contractNumber value for this Contract.
     * 
     * @param contractNumber
     */
    public void setContractNumber(java.lang.String contractNumber) {
        this.contractNumber = contractNumber;
    }


    /**
     * Gets the contractSerialNO__c value for this Contract.
     * 
     * @return contractSerialNO__c
     */
    public java.lang.String getContractSerialNO__c() {
        return contractSerialNO__c;
    }


    /**
     * Sets the contractSerialNO__c value for this Contract.
     * 
     * @param contractSerialNO__c
     */
    public void setContractSerialNO__c(java.lang.String contractSerialNO__c) {
        this.contractSerialNO__c = contractSerialNO__c;
    }


    /**
     * Gets the contractShopAccount__r value for this Contract.
     * 
     * @return contractShopAccount__r
     */
    public com.sforce.soap.enterprise.QueryResult getContractShopAccount__r() {
        return contractShopAccount__r;
    }


    /**
     * Sets the contractShopAccount__r value for this Contract.
     * 
     * @param contractShopAccount__r
     */
    public void setContractShopAccount__r(com.sforce.soap.enterprise.QueryResult contractShopAccount__r) {
        this.contractShopAccount__r = contractShopAccount__r;
    }


    /**
     * Gets the contractSource__c value for this Contract.
     * 
     * @return contractSource__c
     */
    public java.lang.String getContractSource__c() {
        return contractSource__c;
    }


    /**
     * Sets the contractSource__c value for this Contract.
     * 
     * @param contractSource__c
     */
    public void setContractSource__c(java.lang.String contractSource__c) {
        this.contractSource__c = contractSource__c;
    }


    /**
     * Gets the contractStage__c value for this Contract.
     * 
     * @return contractStage__c
     */
    public java.lang.String getContractStage__c() {
        return contractStage__c;
    }


    /**
     * Sets the contractStage__c value for this Contract.
     * 
     * @param contractStage__c
     */
    public void setContractStage__c(java.lang.String contractStage__c) {
        this.contractStage__c = contractStage__c;
    }


    /**
     * Gets the contractStatus__c value for this Contract.
     * 
     * @return contractStatus__c
     */
    public java.lang.String getContractStatus__c() {
        return contractStatus__c;
    }


    /**
     * Sets the contractStatus__c value for this Contract.
     * 
     * @param contractStatus__c
     */
    public void setContractStatus__c(java.lang.String contractStatus__c) {
        this.contractStatus__c = contractStatus__c;
    }


    /**
     * Gets the contractTerm value for this Contract.
     * 
     * @return contractTerm
     */
    public java.lang.Integer getContractTerm() {
        return contractTerm;
    }


    /**
     * Sets the contractTerm value for this Contract.
     * 
     * @param contractTerm
     */
    public void setContractTerm(java.lang.Integer contractTerm) {
        this.contractTerm = contractTerm;
    }


    /**
     * Gets the contractType__c value for this Contract.
     * 
     * @return contractType__c
     */
    public java.lang.String getContractType__c() {
        return contractType__c;
    }


    /**
     * Sets the contractType__c value for this Contract.
     * 
     * @param contractType__c
     */
    public void setContractType__c(java.lang.String contractType__c) {
        this.contractType__c = contractType__c;
    }


    /**
     * Gets the contractUpdTrack__c value for this Contract.
     * 
     * @return contractUpdTrack__c
     */
    public java.lang.String getContractUpdTrack__c() {
        return contractUpdTrack__c;
    }


    /**
     * Sets the contractUpdTrack__c value for this Contract.
     * 
     * @param contractUpdTrack__c
     */
    public void setContractUpdTrack__c(java.lang.String contractUpdTrack__c) {
        this.contractUpdTrack__c = contractUpdTrack__c;
    }


    /**
     * Gets the contract_BankAccount__r value for this Contract.
     * 
     * @return contract_BankAccount__r
     */
    public com.sforce.soap.enterprise.QueryResult getContract_BankAccount__r() {
        return contract_BankAccount__r;
    }


    /**
     * Sets the contract_BankAccount__r value for this Contract.
     * 
     * @param contract_BankAccount__r
     */
    public void setContract_BankAccount__r(com.sforce.soap.enterprise.QueryResult contract_BankAccount__r) {
        this.contract_BankAccount__r = contract_BankAccount__r;
    }


    /**
     * Gets the contract_PayRule__r value for this Contract.
     * 
     * @return contract_PayRule__r
     */
    public com.sforce.soap.enterprise.QueryResult getContract_PayRule__r() {
        return contract_PayRule__r;
    }


    /**
     * Sets the contract_PayRule__r value for this Contract.
     * 
     * @param contract_PayRule__r
     */
    public void setContract_PayRule__r(com.sforce.soap.enterprise.QueryResult contract_PayRule__r) {
        this.contract_PayRule__r = contract_PayRule__r;
    }


    /**
     * Gets the contract__r value for this Contract.
     * 
     * @return contract__r
     */
    public com.sforce.soap.enterprise.QueryResult getContract__r() {
        return contract__r;
    }


    /**
     * Sets the contract__r value for this Contract.
     * 
     * @param contract__r
     */
    public void setContract__r(com.sforce.soap.enterprise.QueryResult contract__r) {
        this.contract__r = contract__r;
    }


    /**
     * Gets the createdBy value for this Contract.
     * 
     * @return createdBy
     */
    public com.sforce.soap.enterprise.sobject.User getCreatedBy() {
        return createdBy;
    }


    /**
     * Sets the createdBy value for this Contract.
     * 
     * @param createdBy
     */
    public void setCreatedBy(com.sforce.soap.enterprise.sobject.User createdBy) {
        this.createdBy = createdBy;
    }


    /**
     * Gets the createdById value for this Contract.
     * 
     * @return createdById
     */
    public java.lang.String getCreatedById() {
        return createdById;
    }


    /**
     * Sets the createdById value for this Contract.
     * 
     * @param createdById
     */
    public void setCreatedById(java.lang.String createdById) {
        this.createdById = createdById;
    }


    /**
     * Gets the createdDate value for this Contract.
     * 
     * @return createdDate
     */
    public java.util.Calendar getCreatedDate() {
        return createdDate;
    }


    /**
     * Sets the createdDate value for this Contract.
     * 
     * @param createdDate
     */
    public void setCreatedDate(java.util.Calendar createdDate) {
        this.createdDate = createdDate;
    }


    /**
     * Gets the customerSigned value for this Contract.
     * 
     * @return customerSigned
     */
    public com.sforce.soap.enterprise.sobject.Contact getCustomerSigned() {
        return customerSigned;
    }


    /**
     * Sets the customerSigned value for this Contract.
     * 
     * @param customerSigned
     */
    public void setCustomerSigned(com.sforce.soap.enterprise.sobject.Contact customerSigned) {
        this.customerSigned = customerSigned;
    }


    /**
     * Gets the customerSignedDate value for this Contract.
     * 
     * @return customerSignedDate
     */
    public java.util.Date getCustomerSignedDate() {
        return customerSignedDate;
    }


    /**
     * Sets the customerSignedDate value for this Contract.
     * 
     * @param customerSignedDate
     */
    public void setCustomerSignedDate(java.util.Date customerSignedDate) {
        this.customerSignedDate = customerSignedDate;
    }


    /**
     * Gets the customerSignedId value for this Contract.
     * 
     * @return customerSignedId
     */
    public java.lang.String getCustomerSignedId() {
        return customerSignedId;
    }


    /**
     * Sets the customerSignedId value for this Contract.
     * 
     * @param customerSignedId
     */
    public void setCustomerSignedId(java.lang.String customerSignedId) {
        this.customerSignedId = customerSignedId;
    }


    /**
     * Gets the customerSignedTitle value for this Contract.
     * 
     * @return customerSignedTitle
     */
    public java.lang.String getCustomerSignedTitle() {
        return customerSignedTitle;
    }


    /**
     * Sets the customerSignedTitle value for this Contract.
     * 
     * @param customerSignedTitle
     */
    public void setCustomerSignedTitle(java.lang.String customerSignedTitle) {
        this.customerSignedTitle = customerSignedTitle;
    }


    /**
     * Gets the dealGroup__r value for this Contract.
     * 
     * @return dealGroup__r
     */
    public com.sforce.soap.enterprise.QueryResult getDealGroup__r() {
        return dealGroup__r;
    }


    /**
     * Sets the dealGroup__r value for this Contract.
     * 
     * @param dealGroup__r
     */
    public void setDealGroup__r(com.sforce.soap.enterprise.QueryResult dealGroup__r) {
        this.dealGroup__r = dealGroup__r;
    }


    /**
     * Gets the deficitDealAPNumber__c value for this Contract.
     * 
     * @return deficitDealAPNumber__c
     */
    public java.lang.Double getDeficitDealAPNumber__c() {
        return deficitDealAPNumber__c;
    }


    /**
     * Sets the deficitDealAPNumber__c value for this Contract.
     * 
     * @param deficitDealAPNumber__c
     */
    public void setDeficitDealAPNumber__c(java.lang.Double deficitDealAPNumber__c) {
        this.deficitDealAPNumber__c = deficitDealAPNumber__c;
    }


    /**
     * Gets the department__c value for this Contract.
     * 
     * @return department__c
     */
    public java.lang.String getDepartment__c() {
        return department__c;
    }


    /**
     * Sets the department__c value for this Contract.
     * 
     * @param department__c
     */
    public void setDepartment__c(java.lang.String department__c) {
        this.department__c = department__c;
    }


    /**
     * Gets the description value for this Contract.
     * 
     * @return description
     */
    public java.lang.String getDescription() {
        return description;
    }


    /**
     * Sets the description value for this Contract.
     * 
     * @param description
     */
    public void setDescription(java.lang.String description) {
        this.description = description;
    }


    /**
     * Gets the endDate value for this Contract.
     * 
     * @return endDate
     */
    public java.util.Date getEndDate() {
        return endDate;
    }


    /**
     * Sets the endDate value for this Contract.
     * 
     * @param endDate
     */
    public void setEndDate(java.util.Date endDate) {
        this.endDate = endDate;
    }


    /**
     * Gets the events value for this Contract.
     * 
     * @return events
     */
    public com.sforce.soap.enterprise.QueryResult getEvents() {
        return events;
    }


    /**
     * Sets the events value for this Contract.
     * 
     * @param events
     */
    public void setEvents(com.sforce.soap.enterprise.QueryResult events) {
        this.events = events;
    }


    /**
     * Gets the freeProductDescShow__c value for this Contract.
     * 
     * @return freeProductDescShow__c
     */
    public java.lang.String getFreeProductDescShow__c() {
        return freeProductDescShow__c;
    }


    /**
     * Sets the freeProductDescShow__c value for this Contract.
     * 
     * @param freeProductDescShow__c
     */
    public void setFreeProductDescShow__c(java.lang.String freeProductDescShow__c) {
        this.freeProductDescShow__c = freeProductDescShow__c;
    }


    /**
     * Gets the freeProductDesc__c value for this Contract.
     * 
     * @return freeProductDesc__c
     */
    public java.lang.String getFreeProductDesc__c() {
        return freeProductDesc__c;
    }


    /**
     * Sets the freeProductDesc__c value for this Contract.
     * 
     * @param freeProductDesc__c
     */
    public void setFreeProductDesc__c(java.lang.String freeProductDesc__c) {
        this.freeProductDesc__c = freeProductDesc__c;
    }


    /**
     * Gets the globalID__c value for this Contract.
     * 
     * @return globalID__c
     */
    public java.lang.String getGlobalID__c() {
        return globalID__c;
    }


    /**
     * Sets the globalID__c value for this Contract.
     * 
     * @param globalID__c
     */
    public void setGlobalID__c(java.lang.String globalID__c) {
        this.globalID__c = globalID__c;
    }


    /**
     * Gets the hasFreePrd__c value for this Contract.
     * 
     * @return hasFreePrd__c
     */
    public java.lang.Double getHasFreePrd__c() {
        return hasFreePrd__c;
    }


    /**
     * Sets the hasFreePrd__c value for this Contract.
     * 
     * @param hasFreePrd__c
     */
    public void setHasFreePrd__c(java.lang.Double hasFreePrd__c) {
        this.hasFreePrd__c = hasFreePrd__c;
    }


    /**
     * Gets the hasRPPrd__c value for this Contract.
     * 
     * @return hasRPPrd__c
     */
    public java.lang.Double getHasRPPrd__c() {
        return hasRPPrd__c;
    }


    /**
     * Sets the hasRPPrd__c value for this Contract.
     * 
     * @param hasRPPrd__c
     */
    public void setHasRPPrd__c(java.lang.Double hasRPPrd__c) {
        this.hasRPPrd__c = hasRPPrd__c;
    }


    /**
     * Gets the histories value for this Contract.
     * 
     * @return histories
     */
    public com.sforce.soap.enterprise.QueryResult getHistories() {
        return histories;
    }


    /**
     * Sets the histories value for this Contract.
     * 
     * @param histories
     */
    public void setHistories(com.sforce.soap.enterprise.QueryResult histories) {
        this.histories = histories;
    }


    /**
     * Gets the historyContractURL__c value for this Contract.
     * 
     * @return historyContractURL__c
     */
    public java.lang.String getHistoryContractURL__c() {
        return historyContractURL__c;
    }


    /**
     * Sets the historyContractURL__c value for this Contract.
     * 
     * @param historyContractURL__c
     */
    public void setHistoryContractURL__c(java.lang.String historyContractURL__c) {
        this.historyContractURL__c = historyContractURL__c;
    }


    /**
     * Gets the invoiceTitle__r value for this Contract.
     * 
     * @return invoiceTitle__r
     */
    public com.sforce.soap.enterprise.QueryResult getInvoiceTitle__r() {
        return invoiceTitle__r;
    }


    /**
     * Sets the invoiceTitle__r value for this Contract.
     * 
     * @param invoiceTitle__r
     */
    public void setInvoiceTitle__r(com.sforce.soap.enterprise.QueryResult invoiceTitle__r) {
        this.invoiceTitle__r = invoiceTitle__r;
    }


    /**
     * Gets the isDeleted value for this Contract.
     * 
     * @return isDeleted
     */
    public java.lang.Boolean getIsDeleted() {
        return isDeleted;
    }


    /**
     * Sets the isDeleted value for this Contract.
     * 
     * @param isDeleted
     */
    public void setIsDeleted(java.lang.Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }


    /**
     * Gets the isPay__c value for this Contract.
     * 
     * @return isPay__c
     */
    public java.lang.Boolean getIsPay__c() {
        return isPay__c;
    }


    /**
     * Sets the isPay__c value for this Contract.
     * 
     * @param isPay__c
     */
    public void setIsPay__c(java.lang.Boolean isPay__c) {
        this.isPay__c = isPay__c;
    }


    /**
     * Gets the isPaying__c value for this Contract.
     * 
     * @return isPaying__c
     */
    public java.lang.Boolean getIsPaying__c() {
        return isPaying__c;
    }


    /**
     * Sets the isPaying__c value for this Contract.
     * 
     * @param isPaying__c
     */
    public void setIsPaying__c(java.lang.Boolean isPaying__c) {
        this.isPaying__c = isPaying__c;
    }


    /**
     * Gets the isPrePayment__c value for this Contract.
     * 
     * @return isPrePayment__c
     */
    public java.lang.String getIsPrePayment__c() {
        return isPrePayment__c;
    }


    /**
     * Sets the isPrePayment__c value for this Contract.
     * 
     * @param isPrePayment__c
     */
    public void setIsPrePayment__c(java.lang.String isPrePayment__c) {
        this.isPrePayment__c = isPrePayment__c;
    }


    /**
     * Gets the isProduced__c value for this Contract.
     * 
     * @return isProduced__c
     */
    public java.lang.Boolean getIsProduced__c() {
        return isProduced__c;
    }


    /**
     * Sets the isProduced__c value for this Contract.
     * 
     * @param isProduced__c
     */
    public void setIsProduced__c(java.lang.Boolean isProduced__c) {
        this.isProduced__c = isProduced__c;
    }


    /**
     * Gets the lastActivityDate value for this Contract.
     * 
     * @return lastActivityDate
     */
    public java.util.Date getLastActivityDate() {
        return lastActivityDate;
    }


    /**
     * Sets the lastActivityDate value for this Contract.
     * 
     * @param lastActivityDate
     */
    public void setLastActivityDate(java.util.Date lastActivityDate) {
        this.lastActivityDate = lastActivityDate;
    }


    /**
     * Gets the lastApprovedDate value for this Contract.
     * 
     * @return lastApprovedDate
     */
    public java.util.Calendar getLastApprovedDate() {
        return lastApprovedDate;
    }


    /**
     * Sets the lastApprovedDate value for this Contract.
     * 
     * @param lastApprovedDate
     */
    public void setLastApprovedDate(java.util.Calendar lastApprovedDate) {
        this.lastApprovedDate = lastApprovedDate;
    }


    /**
     * Gets the lastModifiedBy value for this Contract.
     * 
     * @return lastModifiedBy
     */
    public com.sforce.soap.enterprise.sobject.User getLastModifiedBy() {
        return lastModifiedBy;
    }


    /**
     * Sets the lastModifiedBy value for this Contract.
     * 
     * @param lastModifiedBy
     */
    public void setLastModifiedBy(com.sforce.soap.enterprise.sobject.User lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }


    /**
     * Gets the lastModifiedById value for this Contract.
     * 
     * @return lastModifiedById
     */
    public java.lang.String getLastModifiedById() {
        return lastModifiedById;
    }


    /**
     * Sets the lastModifiedById value for this Contract.
     * 
     * @param lastModifiedById
     */
    public void setLastModifiedById(java.lang.String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }


    /**
     * Gets the lastModifiedDate value for this Contract.
     * 
     * @return lastModifiedDate
     */
    public java.util.Calendar getLastModifiedDate() {
        return lastModifiedDate;
    }


    /**
     * Sets the lastModifiedDate value for this Contract.
     * 
     * @param lastModifiedDate
     */
    public void setLastModifiedDate(java.util.Calendar lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }


    /**
     * Gets the lowestSalesPrice__c value for this Contract.
     * 
     * @return lowestSalesPrice__c
     */
    public java.lang.Double getLowestSalesPrice__c() {
        return lowestSalesPrice__c;
    }


    /**
     * Sets the lowestSalesPrice__c value for this Contract.
     * 
     * @param lowestSalesPrice__c
     */
    public void setLowestSalesPrice__c(java.lang.Double lowestSalesPrice__c) {
        this.lowestSalesPrice__c = lowestSalesPrice__c;
    }


    /**
     * Gets the notes value for this Contract.
     * 
     * @return notes
     */
    public com.sforce.soap.enterprise.QueryResult getNotes() {
        return notes;
    }


    /**
     * Sets the notes value for this Contract.
     * 
     * @param notes
     */
    public void setNotes(com.sforce.soap.enterprise.QueryResult notes) {
        this.notes = notes;
    }


    /**
     * Gets the notesAndAttachments value for this Contract.
     * 
     * @return notesAndAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getNotesAndAttachments() {
        return notesAndAttachments;
    }


    /**
     * Sets the notesAndAttachments value for this Contract.
     * 
     * @param notesAndAttachments
     */
    public void setNotesAndAttachments(com.sforce.soap.enterprise.QueryResult notesAndAttachments) {
        this.notesAndAttachments = notesAndAttachments;
    }


    /**
     * Gets the openActivities value for this Contract.
     * 
     * @return openActivities
     */
    public com.sforce.soap.enterprise.QueryResult getOpenActivities() {
        return openActivities;
    }


    /**
     * Sets the openActivities value for this Contract.
     * 
     * @param openActivities
     */
    public void setOpenActivities(com.sforce.soap.enterprise.QueryResult openActivities) {
        this.openActivities = openActivities;
    }


    /**
     * Gets the opportunityName__c value for this Contract.
     * 
     * @return opportunityName__c
     */
    public java.lang.String getOpportunityName__c() {
        return opportunityName__c;
    }


    /**
     * Sets the opportunityName__c value for this Contract.
     * 
     * @param opportunityName__c
     */
    public void setOpportunityName__c(java.lang.String opportunityName__c) {
        this.opportunityName__c = opportunityName__c;
    }


    /**
     * Gets the opportunity__c value for this Contract.
     * 
     * @return opportunity__c
     */
    public java.lang.String getOpportunity__c() {
        return opportunity__c;
    }


    /**
     * Sets the opportunity__c value for this Contract.
     * 
     * @param opportunity__c
     */
    public void setOpportunity__c(java.lang.String opportunity__c) {
        this.opportunity__c = opportunity__c;
    }


    /**
     * Gets the opportunity__r value for this Contract.
     * 
     * @return opportunity__r
     */
    public com.sforce.soap.enterprise.sobject.Opportunity getOpportunity__r() {
        return opportunity__r;
    }


    /**
     * Sets the opportunity__r value for this Contract.
     * 
     * @param opportunity__r
     */
    public void setOpportunity__r(com.sforce.soap.enterprise.sobject.Opportunity opportunity__r) {
        this.opportunity__r = opportunity__r;
    }


    /**
     * Gets the owner value for this Contract.
     * 
     * @return owner
     */
    public com.sforce.soap.enterprise.sobject.User getOwner() {
        return owner;
    }


    /**
     * Sets the owner value for this Contract.
     * 
     * @param owner
     */
    public void setOwner(com.sforce.soap.enterprise.sobject.User owner) {
        this.owner = owner;
    }


    /**
     * Gets the ownerExpirationNotice value for this Contract.
     * 
     * @return ownerExpirationNotice
     */
    public java.lang.String getOwnerExpirationNotice() {
        return ownerExpirationNotice;
    }


    /**
     * Sets the ownerExpirationNotice value for this Contract.
     * 
     * @param ownerExpirationNotice
     */
    public void setOwnerExpirationNotice(java.lang.String ownerExpirationNotice) {
        this.ownerExpirationNotice = ownerExpirationNotice;
    }


    /**
     * Gets the ownerId value for this Contract.
     * 
     * @return ownerId
     */
    public java.lang.String getOwnerId() {
        return ownerId;
    }


    /**
     * Sets the ownerId value for this Contract.
     * 
     * @param ownerId
     */
    public void setOwnerId(java.lang.String ownerId) {
        this.ownerId = ownerId;
    }


    /**
     * Gets the ownerRole__c value for this Contract.
     * 
     * @return ownerRole__c
     */
    public java.lang.String getOwnerRole__c() {
        return ownerRole__c;
    }


    /**
     * Sets the ownerRole__c value for this Contract.
     * 
     * @param ownerRole__c
     */
    public void setOwnerRole__c(java.lang.String ownerRole__c) {
        this.ownerRole__c = ownerRole__c;
    }


    /**
     * Gets the payRuleType__c value for this Contract.
     * 
     * @return payRuleType__c
     */
    public java.lang.Double getPayRuleType__c() {
        return payRuleType__c;
    }


    /**
     * Sets the payRuleType__c value for this Contract.
     * 
     * @param payRuleType__c
     */
    public void setPayRuleType__c(java.lang.Double payRuleType__c) {
        this.payRuleType__c = payRuleType__c;
    }


    /**
     * Gets the payRule__c value for this Contract.
     * 
     * @return payRule__c
     */
    public java.lang.String getPayRule__c() {
        return payRule__c;
    }


    /**
     * Sets the payRule__c value for this Contract.
     * 
     * @param payRule__c
     */
    public void setPayRule__c(java.lang.String payRule__c) {
        this.payRule__c = payRule__c;
    }


    /**
     * Gets the payRule__r value for this Contract.
     * 
     * @return payRule__r
     */
    public com.sforce.soap.enterprise.sobject.PayRule__c getPayRule__r() {
        return payRule__r;
    }


    /**
     * Sets the payRule__r value for this Contract.
     * 
     * @param payRule__r
     */
    public void setPayRule__r(com.sforce.soap.enterprise.sobject.PayRule__c payRule__r) {
        this.payRule__r = payRule__r;
    }


    /**
     * Gets the paymentRollUpPercent__c value for this Contract.
     * 
     * @return paymentRollUpPercent__c
     */
    public java.lang.Double getPaymentRollUpPercent__c() {
        return paymentRollUpPercent__c;
    }


    /**
     * Sets the paymentRollUpPercent__c value for this Contract.
     * 
     * @param paymentRollUpPercent__c
     */
    public void setPaymentRollUpPercent__c(java.lang.Double paymentRollUpPercent__c) {
        this.paymentRollUpPercent__c = paymentRollUpPercent__c;
    }


    /**
     * Gets the paymentTransactionType__c value for this Contract.
     * 
     * @return paymentTransactionType__c
     */
    public java.lang.String getPaymentTransactionType__c() {
        return paymentTransactionType__c;
    }


    /**
     * Sets the paymentTransactionType__c value for this Contract.
     * 
     * @param paymentTransactionType__c
     */
    public void setPaymentTransactionType__c(java.lang.String paymentTransactionType__c) {
        this.paymentTransactionType__c = paymentTransactionType__c;
    }


    /**
     * Gets the phone__c value for this Contract.
     * 
     * @return phone__c
     */
    public java.lang.String getPhone__c() {
        return phone__c;
    }


    /**
     * Sets the phone__c value for this Contract.
     * 
     * @param phone__c
     */
    public void setPhone__c(java.lang.String phone__c) {
        this.phone__c = phone__c;
    }


    /**
     * Gets the prePaymentPercent__c value for this Contract.
     * 
     * @return prePaymentPercent__c
     */
    public java.lang.Double getPrePaymentPercent__c() {
        return prePaymentPercent__c;
    }


    /**
     * Sets the prePaymentPercent__c value for this Contract.
     * 
     * @param prePaymentPercent__c
     */
    public void setPrePaymentPercent__c(java.lang.Double prePaymentPercent__c) {
        this.prePaymentPercent__c = prePaymentPercent__c;
    }


    /**
     * Gets the prePayment__c value for this Contract.
     * 
     * @return prePayment__c
     */
    public java.lang.Double getPrePayment__c() {
        return prePayment__c;
    }


    /**
     * Sets the prePayment__c value for this Contract.
     * 
     * @param prePayment__c
     */
    public void setPrePayment__c(java.lang.Double prePayment__c) {
        this.prePayment__c = prePayment__c;
    }


    /**
     * Gets the processInstances value for this Contract.
     * 
     * @return processInstances
     */
    public com.sforce.soap.enterprise.QueryResult getProcessInstances() {
        return processInstances;
    }


    /**
     * Sets the processInstances value for this Contract.
     * 
     * @param processInstances
     */
    public void setProcessInstances(com.sforce.soap.enterprise.QueryResult processInstances) {
        this.processInstances = processInstances;
    }


    /**
     * Gets the processSteps value for this Contract.
     * 
     * @return processSteps
     */
    public com.sforce.soap.enterprise.QueryResult getProcessSteps() {
        return processSteps;
    }


    /**
     * Sets the processSteps value for this Contract.
     * 
     * @param processSteps
     */
    public void setProcessSteps(com.sforce.soap.enterprise.QueryResult processSteps) {
        this.processSteps = processSteps;
    }


    /**
     * Gets the projectTeamAprStatus__c value for this Contract.
     * 
     * @return projectTeamAprStatus__c
     */
    public java.lang.String getProjectTeamAprStatus__c() {
        return projectTeamAprStatus__c;
    }


    /**
     * Sets the projectTeamAprStatus__c value for this Contract.
     * 
     * @param projectTeamAprStatus__c
     */
    public void setProjectTeamAprStatus__c(java.lang.String projectTeamAprStatus__c) {
        this.projectTeamAprStatus__c = projectTeamAprStatus__c;
    }


    /**
     * Gets the publishMidDay__c value for this Contract.
     * 
     * @return publishMidDay__c
     */
    public java.util.Date getPublishMidDay__c() {
        return publishMidDay__c;
    }


    /**
     * Sets the publishMidDay__c value for this Contract.
     * 
     * @param publishMidDay__c
     */
    public void setPublishMidDay__c(java.util.Date publishMidDay__c) {
        this.publishMidDay__c = publishMidDay__c;
    }


    /**
     * Gets the RPApplyDesc__c value for this Contract.
     * 
     * @return RPApplyDesc__c
     */
    public java.lang.String getRPApplyDesc__c() {
        return RPApplyDesc__c;
    }


    /**
     * Sets the RPApplyDesc__c value for this Contract.
     * 
     * @param RPApplyDesc__c
     */
    public void setRPApplyDesc__c(java.lang.String RPApplyDesc__c) {
        this.RPApplyDesc__c = RPApplyDesc__c;
    }


    /**
     * Gets the RPApplyFormNo__c value for this Contract.
     * 
     * @return RPApplyFormNo__c
     */
    public java.lang.String getRPApplyFormNo__c() {
        return RPApplyFormNo__c;
    }


    /**
     * Sets the RPApplyFormNo__c value for this Contract.
     * 
     * @param RPApplyFormNo__c
     */
    public void setRPApplyFormNo__c(java.lang.String RPApplyFormNo__c) {
        this.RPApplyFormNo__c = RPApplyFormNo__c;
    }


    /**
     * Gets the readyForApproval__c value for this Contract.
     * 
     * @return readyForApproval__c
     */
    public java.lang.Boolean getReadyForApproval__c() {
        return readyForApproval__c;
    }


    /**
     * Sets the readyForApproval__c value for this Contract.
     * 
     * @param readyForApproval__c
     */
    public void setReadyForApproval__c(java.lang.Boolean readyForApproval__c) {
        this.readyForApproval__c = readyForApproval__c;
    }


    /**
     * Gets the recordType value for this Contract.
     * 
     * @return recordType
     */
    public com.sforce.soap.enterprise.sobject.RecordType getRecordType() {
        return recordType;
    }


    /**
     * Sets the recordType value for this Contract.
     * 
     * @param recordType
     */
    public void setRecordType(com.sforce.soap.enterprise.sobject.RecordType recordType) {
        this.recordType = recordType;
    }


    /**
     * Gets the recordTypeId value for this Contract.
     * 
     * @return recordTypeId
     */
    public java.lang.String getRecordTypeId() {
        return recordTypeId;
    }


    /**
     * Sets the recordTypeId value for this Contract.
     * 
     * @param recordTypeId
     */
    public void setRecordTypeId(java.lang.String recordTypeId) {
        this.recordTypeId = recordTypeId;
    }


    /**
     * Gets the registerName__c value for this Contract.
     * 
     * @return registerName__c
     */
    public java.lang.String getRegisterName__c() {
        return registerName__c;
    }


    /**
     * Sets the registerName__c value for this Contract.
     * 
     * @param registerName__c
     */
    public void setRegisterName__c(java.lang.String registerName__c) {
        this.registerName__c = registerName__c;
    }


    /**
     * Gets the relatedContractNumber__c value for this Contract.
     * 
     * @return relatedContractNumber__c
     */
    public java.lang.String getRelatedContractNumber__c() {
        return relatedContractNumber__c;
    }


    /**
     * Sets the relatedContractNumber__c value for this Contract.
     * 
     * @param relatedContractNumber__c
     */
    public void setRelatedContractNumber__c(java.lang.String relatedContractNumber__c) {
        this.relatedContractNumber__c = relatedContractNumber__c;
    }


    /**
     * Gets the remainFunds__c value for this Contract.
     * 
     * @return remainFunds__c
     */
    public java.lang.Double getRemainFunds__c() {
        return remainFunds__c;
    }


    /**
     * Sets the remainFunds__c value for this Contract.
     * 
     * @param remainFunds__c
     */
    public void setRemainFunds__c(java.lang.Double remainFunds__c) {
        this.remainFunds__c = remainFunds__c;
    }


    /**
     * Gets the salesPriceStatus__c value for this Contract.
     * 
     * @return salesPriceStatus__c
     */
    public java.lang.String getSalesPriceStatus__c() {
        return salesPriceStatus__c;
    }


    /**
     * Sets the salesPriceStatus__c value for this Contract.
     * 
     * @param salesPriceStatus__c
     */
    public void setSalesPriceStatus__c(java.lang.String salesPriceStatus__c) {
        this.salesPriceStatus__c = salesPriceStatus__c;
    }


    /**
     * Gets the salesmanSighed__c value for this Contract.
     * 
     * @return salesmanSighed__c
     */
    public java.lang.String getSalesmanSighed__c() {
        return salesmanSighed__c;
    }


    /**
     * Sets the salesmanSighed__c value for this Contract.
     * 
     * @param salesmanSighed__c
     */
    public void setSalesmanSighed__c(java.lang.String salesmanSighed__c) {
        this.salesmanSighed__c = salesmanSighed__c;
    }


    /**
     * Gets the sequence__c value for this Contract.
     * 
     * @return sequence__c
     */
    public java.lang.String getSequence__c() {
        return sequence__c;
    }


    /**
     * Sets the sequence__c value for this Contract.
     * 
     * @param sequence__c
     */
    public void setSequence__c(java.lang.String sequence__c) {
        this.sequence__c = sequence__c;
    }


    /**
     * Gets the shippingCity value for this Contract.
     * 
     * @return shippingCity
     */
    public java.lang.String getShippingCity() {
        return shippingCity;
    }


    /**
     * Sets the shippingCity value for this Contract.
     * 
     * @param shippingCity
     */
    public void setShippingCity(java.lang.String shippingCity) {
        this.shippingCity = shippingCity;
    }


    /**
     * Gets the shippingCountry value for this Contract.
     * 
     * @return shippingCountry
     */
    public java.lang.String getShippingCountry() {
        return shippingCountry;
    }


    /**
     * Sets the shippingCountry value for this Contract.
     * 
     * @param shippingCountry
     */
    public void setShippingCountry(java.lang.String shippingCountry) {
        this.shippingCountry = shippingCountry;
    }


    /**
     * Gets the shippingPostalCode value for this Contract.
     * 
     * @return shippingPostalCode
     */
    public java.lang.String getShippingPostalCode() {
        return shippingPostalCode;
    }


    /**
     * Sets the shippingPostalCode value for this Contract.
     * 
     * @param shippingPostalCode
     */
    public void setShippingPostalCode(java.lang.String shippingPostalCode) {
        this.shippingPostalCode = shippingPostalCode;
    }


    /**
     * Gets the shippingState value for this Contract.
     * 
     * @return shippingState
     */
    public java.lang.String getShippingState() {
        return shippingState;
    }


    /**
     * Sets the shippingState value for this Contract.
     * 
     * @param shippingState
     */
    public void setShippingState(java.lang.String shippingState) {
        this.shippingState = shippingState;
    }


    /**
     * Gets the shippingStreet value for this Contract.
     * 
     * @return shippingStreet
     */
    public java.lang.String getShippingStreet() {
        return shippingStreet;
    }


    /**
     * Sets the shippingStreet value for this Contract.
     * 
     * @param shippingStreet
     */
    public void setShippingStreet(java.lang.String shippingStreet) {
        this.shippingStreet = shippingStreet;
    }


    /**
     * Gets the showInventoryURL__c value for this Contract.
     * 
     * @return showInventoryURL__c
     */
    public java.lang.String getShowInventoryURL__c() {
        return showInventoryURL__c;
    }


    /**
     * Sets the showInventoryURL__c value for this Contract.
     * 
     * @param showInventoryURL__c
     */
    public void setShowInventoryURL__c(java.lang.String showInventoryURL__c) {
        this.showInventoryURL__c = showInventoryURL__c;
    }


    /**
     * Gets the showSHInventoryURL__c value for this Contract.
     * 
     * @return showSHInventoryURL__c
     */
    public java.lang.String getShowSHInventoryURL__c() {
        return showSHInventoryURL__c;
    }


    /**
     * Sets the showSHInventoryURL__c value for this Contract.
     * 
     * @param showSHInventoryURL__c
     */
    public void setShowSHInventoryURL__c(java.lang.String showSHInventoryURL__c) {
        this.showSHInventoryURL__c = showSHInventoryURL__c;
    }


    /**
     * Gets the specialTerms value for this Contract.
     * 
     * @return specialTerms
     */
    public java.lang.String getSpecialTerms() {
        return specialTerms;
    }


    /**
     * Sets the specialTerms value for this Contract.
     * 
     * @param specialTerms
     */
    public void setSpecialTerms(java.lang.String specialTerms) {
        this.specialTerms = specialTerms;
    }


    /**
     * Gets the startDate value for this Contract.
     * 
     * @return startDate
     */
    public java.util.Date getStartDate() {
        return startDate;
    }


    /**
     * Sets the startDate value for this Contract.
     * 
     * @param startDate
     */
    public void setStartDate(java.util.Date startDate) {
        this.startDate = startDate;
    }


    /**
     * Gets the status value for this Contract.
     * 
     * @return status
     */
    public java.lang.String getStatus() {
        return status;
    }


    /**
     * Sets the status value for this Contract.
     * 
     * @param status
     */
    public void setStatus(java.lang.String status) {
        this.status = status;
    }


    /**
     * Gets the statusCode value for this Contract.
     * 
     * @return statusCode
     */
    public java.lang.String getStatusCode() {
        return statusCode;
    }


    /**
     * Sets the statusCode value for this Contract.
     * 
     * @param statusCode
     */
    public void setStatusCode(java.lang.String statusCode) {
        this.statusCode = statusCode;
    }


    /**
     * Gets the systemModstamp value for this Contract.
     * 
     * @return systemModstamp
     */
    public java.util.Calendar getSystemModstamp() {
        return systemModstamp;
    }


    /**
     * Sets the systemModstamp value for this Contract.
     * 
     * @param systemModstamp
     */
    public void setSystemModstamp(java.util.Calendar systemModstamp) {
        this.systemModstamp = systemModstamp;
    }


    /**
     * Gets the tasks value for this Contract.
     * 
     * @return tasks
     */
    public com.sforce.soap.enterprise.QueryResult getTasks() {
        return tasks;
    }


    /**
     * Sets the tasks value for this Contract.
     * 
     * @param tasks
     */
    public void setTasks(com.sforce.soap.enterprise.QueryResult tasks) {
        this.tasks = tasks;
    }


    /**
     * Gets the terminateReason__c value for this Contract.
     * 
     * @return terminateReason__c
     */
    public java.lang.String getTerminateReason__c() {
        return terminateReason__c;
    }


    /**
     * Sets the terminateReason__c value for this Contract.
     * 
     * @param terminateReason__c
     */
    public void setTerminateReason__c(java.lang.String terminateReason__c) {
        this.terminateReason__c = terminateReason__c;
    }


    /**
     * Gets the totalListPrice__c value for this Contract.
     * 
     * @return totalListPrice__c
     */
    public java.lang.Double getTotalListPrice__c() {
        return totalListPrice__c;
    }


    /**
     * Sets the totalListPrice__c value for this Contract.
     * 
     * @param totalListPrice__c
     */
    public void setTotalListPrice__c(java.lang.Double totalListPrice__c) {
        this.totalListPrice__c = totalListPrice__c;
    }


    /**
     * Gets the totalSalesPrice__c value for this Contract.
     * 
     * @return totalSalesPrice__c
     */
    public java.lang.Double getTotalSalesPrice__c() {
        return totalSalesPrice__c;
    }


    /**
     * Sets the totalSalesPrice__c value for this Contract.
     * 
     * @param totalSalesPrice__c
     */
    public void setTotalSalesPrice__c(java.lang.Double totalSalesPrice__c) {
        this.totalSalesPrice__c = totalSalesPrice__c;
    }


    /**
     * Gets the wholeDiscount__c value for this Contract.
     * 
     * @return wholeDiscount__c
     */
    public java.lang.Double getWholeDiscount__c() {
        return wholeDiscount__c;
    }


    /**
     * Sets the wholeDiscount__c value for this Contract.
     * 
     * @param wholeDiscount__c
     */
    public void setWholeDiscount__c(java.lang.Double wholeDiscount__c) {
        this.wholeDiscount__c = wholeDiscount__c;
    }


    /**
     * Gets the wholeListPrice__c value for this Contract.
     * 
     * @return wholeListPrice__c
     */
    public java.lang.Double getWholeListPrice__c() {
        return wholeListPrice__c;
    }


    /**
     * Sets the wholeListPrice__c value for this Contract.
     * 
     * @param wholeListPrice__c
     */
    public void setWholeListPrice__c(java.lang.Double wholeListPrice__c) {
        this.wholeListPrice__c = wholeListPrice__c;
    }


    /**
     * Gets the contractcontact__r value for this Contract.
     * 
     * @return contractcontact__r
     */
    public com.sforce.soap.enterprise.QueryResult getContractcontact__r() {
        return contractcontact__r;
    }


    /**
     * Sets the contractcontact__r value for this Contract.
     * 
     * @param contractcontact__r
     */
    public void setContractcontact__r(com.sforce.soap.enterprise.QueryResult contractcontact__r) {
        this.contractcontact__r = contractcontact__r;
    }


    /**
     * Gets the deal__r value for this Contract.
     * 
     * @return deal__r
     */
    public com.sforce.soap.enterprise.QueryResult getDeal__r() {
        return deal__r;
    }


    /**
     * Sets the deal__r value for this Contract.
     * 
     * @param deal__r
     */
    public void setDeal__r(com.sforce.soap.enterprise.QueryResult deal__r) {
        this.deal__r = deal__r;
    }


    /**
     * Gets the isPublish__c value for this Contract.
     * 
     * @return isPublish__c
     */
    public java.lang.Boolean getIsPublish__c() {
        return isPublish__c;
    }


    /**
     * Sets the isPublish__c value for this Contract.
     * 
     * @param isPublish__c
     */
    public void setIsPublish__c(java.lang.Boolean isPublish__c) {
        this.isPublish__c = isPublish__c;
    }


    /**
     * Gets the isQualified__c value for this Contract.
     * 
     * @return isQualified__c
     */
    public java.lang.Boolean getIsQualified__c() {
        return isQualified__c;
    }


    /**
     * Sets the isQualified__c value for this Contract.
     * 
     * @param isQualified__c
     */
    public void setIsQualified__c(java.lang.Boolean isQualified__c) {
        this.isQualified__c = isQualified__c;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Contract)) return false;
        Contract other = (Contract) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.AP_AD1StPayPercent__c==null && other.getAP_AD1StPayPercent__c()==null) || 
             (this.AP_AD1StPayPercent__c!=null &&
              this.AP_AD1StPayPercent__c.equals(other.getAP_AD1StPayPercent__c()))) &&
            ((this.AP_FirstPublishDay__c==null && other.getAP_FirstPublishDay__c()==null) || 
             (this.AP_FirstPublishDay__c!=null &&
              this.AP_FirstPublishDay__c.equals(other.getAP_FirstPublishDay__c()))) &&
            ((this.AP_LastPublishDay__c==null && other.getAP_LastPublishDay__c()==null) || 
             (this.AP_LastPublishDay__c!=null &&
              this.AP_LastPublishDay__c.equals(other.getAP_LastPublishDay__c()))) &&
            ((this.AP_NormalKeyWordsCount__c==null && other.getAP_NormalKeyWordsCount__c()==null) || 
             (this.AP_NormalKeyWordsCount__c!=null &&
              this.AP_NormalKeyWordsCount__c.equals(other.getAP_NormalKeyWordsCount__c()))) &&
            ((this.AP_OtherProductCount__c==null && other.getAP_OtherProductCount__c()==null) || 
             (this.AP_OtherProductCount__c!=null &&
              this.AP_OtherProductCount__c.equals(other.getAP_OtherProductCount__c()))) &&
            ((this.AP_PayItemCount__c==null && other.getAP_PayItemCount__c()==null) || 
             (this.AP_PayItemCount__c!=null &&
              this.AP_PayItemCount__c.equals(other.getAP_PayItemCount__c()))) &&
            ((this.AP_TopKeyWordsCount__c==null && other.getAP_TopKeyWordsCount__c()==null) || 
             (this.AP_TopKeyWordsCount__c!=null &&
              this.AP_TopKeyWordsCount__c.equals(other.getAP_TopKeyWordsCount__c()))) &&
            ((this.AP_TotalDiscount__c==null && other.getAP_TotalDiscount__c()==null) || 
             (this.AP_TotalDiscount__c!=null &&
              this.AP_TotalDiscount__c.equals(other.getAP_TotalDiscount__c()))) &&
            ((this.account==null && other.getAccount()==null) || 
             (this.account!=null &&
              this.account.equals(other.getAccount()))) &&
            ((this.accountAdress__c==null && other.getAccountAdress__c()==null) || 
             (this.accountAdress__c!=null &&
              this.accountAdress__c.equals(other.getAccountAdress__c()))) &&
            ((this.accountId==null && other.getAccountId()==null) || 
             (this.accountId!=null &&
              this.accountId.equals(other.getAccountId()))) &&
            ((this.activatedBy==null && other.getActivatedBy()==null) || 
             (this.activatedBy!=null &&
              this.activatedBy.equals(other.getActivatedBy()))) &&
            ((this.activatedById==null && other.getActivatedById()==null) || 
             (this.activatedById!=null &&
              this.activatedById.equals(other.getActivatedById()))) &&
            ((this.activatedDate==null && other.getActivatedDate()==null) || 
             (this.activatedDate!=null &&
              this.activatedDate.equals(other.getActivatedDate()))) &&
            ((this.activityHistories==null && other.getActivityHistories()==null) || 
             (this.activityHistories!=null &&
              this.activityHistories.equals(other.getActivityHistories()))) &&
            ((this.approvalField__c==null && other.getApprovalField__c()==null) || 
             (this.approvalField__c!=null &&
              this.approvalField__c.equals(other.getApprovalField__c()))) &&
            ((this.approvalMgr1__c==null && other.getApprovalMgr1__c()==null) || 
             (this.approvalMgr1__c!=null &&
              this.approvalMgr1__c.equals(other.getApprovalMgr1__c()))) &&
            ((this.approvalMgr1__r==null && other.getApprovalMgr1__r()==null) || 
             (this.approvalMgr1__r!=null &&
              this.approvalMgr1__r.equals(other.getApprovalMgr1__r()))) &&
            ((this.approvalMgr2__c==null && other.getApprovalMgr2__c()==null) || 
             (this.approvalMgr2__c!=null &&
              this.approvalMgr2__c.equals(other.getApprovalMgr2__c()))) &&
            ((this.approvalMgr2__r==null && other.getApprovalMgr2__r()==null) || 
             (this.approvalMgr2__r!=null &&
              this.approvalMgr2__r.equals(other.getApprovalMgr2__r()))) &&
            ((this.approvalMgr3__c==null && other.getApprovalMgr3__c()==null) || 
             (this.approvalMgr3__c!=null &&
              this.approvalMgr3__c.equals(other.getApprovalMgr3__c()))) &&
            ((this.approvalMgr3__r==null && other.getApprovalMgr3__r()==null) || 
             (this.approvalMgr3__r!=null &&
              this.approvalMgr3__r.equals(other.getApprovalMgr3__r()))) &&
            ((this.approvalMgr4__c==null && other.getApprovalMgr4__c()==null) || 
             (this.approvalMgr4__c!=null &&
              this.approvalMgr4__c.equals(other.getApprovalMgr4__c()))) &&
            ((this.approvalMgr4__r==null && other.getApprovalMgr4__r()==null) || 
             (this.approvalMgr4__r!=null &&
              this.approvalMgr4__r.equals(other.getApprovalMgr4__r()))) &&
            ((this.approvals==null && other.getApprovals()==null) || 
             (this.approvals!=null &&
              this.approvals.equals(other.getApprovals()))) &&
            ((this.attachments==null && other.getAttachments()==null) || 
             (this.attachments!=null &&
              this.attachments.equals(other.getAttachments()))) &&
            ((this.badContractPRDLT__c==null && other.getBadContractPRDLT__c()==null) || 
             (this.badContractPRDLT__c!=null &&
              this.badContractPRDLT__c.equals(other.getBadContractPRDLT__c()))) &&
            ((this.billingCity==null && other.getBillingCity()==null) || 
             (this.billingCity!=null &&
              this.billingCity.equals(other.getBillingCity()))) &&
            ((this.billingCountry==null && other.getBillingCountry()==null) || 
             (this.billingCountry!=null &&
              this.billingCountry.equals(other.getBillingCountry()))) &&
            ((this.billingInfo__c==null && other.getBillingInfo__c()==null) || 
             (this.billingInfo__c!=null &&
              this.billingInfo__c.equals(other.getBillingInfo__c()))) &&
            ((this.billingInfo__r==null && other.getBillingInfo__r()==null) || 
             (this.billingInfo__r!=null &&
              this.billingInfo__r.equals(other.getBillingInfo__r()))) &&
            ((this.billingPostalCode==null && other.getBillingPostalCode()==null) || 
             (this.billingPostalCode!=null &&
              this.billingPostalCode.equals(other.getBillingPostalCode()))) &&
            ((this.billingState==null && other.getBillingState()==null) || 
             (this.billingState!=null &&
              this.billingState.equals(other.getBillingState()))) &&
            ((this.billingStreet==null && other.getBillingStreet()==null) || 
             (this.billingStreet!=null &&
              this.billingStreet.equals(other.getBillingStreet()))) &&
            ((this.cityID__c==null && other.getCityID__c()==null) || 
             (this.cityID__c!=null &&
              this.cityID__c.equals(other.getCityID__c()))) &&
            ((this.city__c==null && other.getCity__c()==null) || 
             (this.city__c!=null &&
              this.city__c.equals(other.getCity__c()))) &&
            ((this.city__r==null && other.getCity__r()==null) || 
             (this.city__r!=null &&
              this.city__r.equals(other.getCity__r()))) &&
            ((this.companySigned==null && other.getCompanySigned()==null) || 
             (this.companySigned!=null &&
              this.companySigned.equals(other.getCompanySigned()))) &&
            ((this.companySignedDate==null && other.getCompanySignedDate()==null) || 
             (this.companySignedDate!=null &&
              this.companySignedDate.equals(other.getCompanySignedDate()))) &&
            ((this.companySignedId==null && other.getCompanySignedId()==null) || 
             (this.companySignedId!=null &&
              this.companySignedId.equals(other.getCompanySignedId()))) &&
            ((this.confirmViaWeb__c==null && other.getConfirmViaWeb__c()==null) || 
             (this.confirmViaWeb__c!=null &&
              this.confirmViaWeb__c.equals(other.getConfirmViaWeb__c()))) &&
            ((this.contractAPStatus__c==null && other.getContractAPStatus__c()==null) || 
             (this.contractAPStatus__c!=null &&
              this.contractAPStatus__c.equals(other.getContractAPStatus__c()))) &&
            ((this.contractBilling__r==null && other.getContractBilling__r()==null) || 
             (this.contractBilling__r!=null &&
              this.contractBilling__r.equals(other.getContractBilling__r()))) &&
            ((this.contractCalNumber__c==null && other.getContractCalNumber__c()==null) || 
             (this.contractCalNumber__c!=null &&
              this.contractCalNumber__c.equals(other.getContractCalNumber__c()))) &&
            ((this.contractContactRoles==null && other.getContractContactRoles()==null) || 
             (this.contractContactRoles!=null &&
              this.contractContactRoles.equals(other.getContractContactRoles()))) &&
            ((this.contractLineItemTemp__r==null && other.getContractLineItemTemp__r()==null) || 
             (this.contractLineItemTemp__r!=null &&
              this.contractLineItemTemp__r.equals(other.getContractLineItemTemp__r()))) &&
            ((this.contractLineItem__r==null && other.getContractLineItem__r()==null) || 
             (this.contractLineItem__r!=null &&
              this.contractLineItem__r.equals(other.getContractLineItem__r()))) &&
            ((this.contractNumber==null && other.getContractNumber()==null) || 
             (this.contractNumber!=null &&
              this.contractNumber.equals(other.getContractNumber()))) &&
            ((this.contractSerialNO__c==null && other.getContractSerialNO__c()==null) || 
             (this.contractSerialNO__c!=null &&
              this.contractSerialNO__c.equals(other.getContractSerialNO__c()))) &&
            ((this.contractShopAccount__r==null && other.getContractShopAccount__r()==null) || 
             (this.contractShopAccount__r!=null &&
              this.contractShopAccount__r.equals(other.getContractShopAccount__r()))) &&
            ((this.contractSource__c==null && other.getContractSource__c()==null) || 
             (this.contractSource__c!=null &&
              this.contractSource__c.equals(other.getContractSource__c()))) &&
            ((this.contractStage__c==null && other.getContractStage__c()==null) || 
             (this.contractStage__c!=null &&
              this.contractStage__c.equals(other.getContractStage__c()))) &&
            ((this.contractStatus__c==null && other.getContractStatus__c()==null) || 
             (this.contractStatus__c!=null &&
              this.contractStatus__c.equals(other.getContractStatus__c()))) &&
            ((this.contractTerm==null && other.getContractTerm()==null) || 
             (this.contractTerm!=null &&
              this.contractTerm.equals(other.getContractTerm()))) &&
            ((this.contractType__c==null && other.getContractType__c()==null) || 
             (this.contractType__c!=null &&
              this.contractType__c.equals(other.getContractType__c()))) &&
            ((this.contractUpdTrack__c==null && other.getContractUpdTrack__c()==null) || 
             (this.contractUpdTrack__c!=null &&
              this.contractUpdTrack__c.equals(other.getContractUpdTrack__c()))) &&
            ((this.contract_BankAccount__r==null && other.getContract_BankAccount__r()==null) || 
             (this.contract_BankAccount__r!=null &&
              this.contract_BankAccount__r.equals(other.getContract_BankAccount__r()))) &&
            ((this.contract_PayRule__r==null && other.getContract_PayRule__r()==null) || 
             (this.contract_PayRule__r!=null &&
              this.contract_PayRule__r.equals(other.getContract_PayRule__r()))) &&
            ((this.contract__r==null && other.getContract__r()==null) || 
             (this.contract__r!=null &&
              this.contract__r.equals(other.getContract__r()))) &&
            ((this.createdBy==null && other.getCreatedBy()==null) || 
             (this.createdBy!=null &&
              this.createdBy.equals(other.getCreatedBy()))) &&
            ((this.createdById==null && other.getCreatedById()==null) || 
             (this.createdById!=null &&
              this.createdById.equals(other.getCreatedById()))) &&
            ((this.createdDate==null && other.getCreatedDate()==null) || 
             (this.createdDate!=null &&
              this.createdDate.equals(other.getCreatedDate()))) &&
            ((this.customerSigned==null && other.getCustomerSigned()==null) || 
             (this.customerSigned!=null &&
              this.customerSigned.equals(other.getCustomerSigned()))) &&
            ((this.customerSignedDate==null && other.getCustomerSignedDate()==null) || 
             (this.customerSignedDate!=null &&
              this.customerSignedDate.equals(other.getCustomerSignedDate()))) &&
            ((this.customerSignedId==null && other.getCustomerSignedId()==null) || 
             (this.customerSignedId!=null &&
              this.customerSignedId.equals(other.getCustomerSignedId()))) &&
            ((this.customerSignedTitle==null && other.getCustomerSignedTitle()==null) || 
             (this.customerSignedTitle!=null &&
              this.customerSignedTitle.equals(other.getCustomerSignedTitle()))) &&
            ((this.dealGroup__r==null && other.getDealGroup__r()==null) || 
             (this.dealGroup__r!=null &&
              this.dealGroup__r.equals(other.getDealGroup__r()))) &&
            ((this.deficitDealAPNumber__c==null && other.getDeficitDealAPNumber__c()==null) || 
             (this.deficitDealAPNumber__c!=null &&
              this.deficitDealAPNumber__c.equals(other.getDeficitDealAPNumber__c()))) &&
            ((this.department__c==null && other.getDepartment__c()==null) || 
             (this.department__c!=null &&
              this.department__c.equals(other.getDepartment__c()))) &&
            ((this.description==null && other.getDescription()==null) || 
             (this.description!=null &&
              this.description.equals(other.getDescription()))) &&
            ((this.endDate==null && other.getEndDate()==null) || 
             (this.endDate!=null &&
              this.endDate.equals(other.getEndDate()))) &&
            ((this.events==null && other.getEvents()==null) || 
             (this.events!=null &&
              this.events.equals(other.getEvents()))) &&
            ((this.freeProductDescShow__c==null && other.getFreeProductDescShow__c()==null) || 
             (this.freeProductDescShow__c!=null &&
              this.freeProductDescShow__c.equals(other.getFreeProductDescShow__c()))) &&
            ((this.freeProductDesc__c==null && other.getFreeProductDesc__c()==null) || 
             (this.freeProductDesc__c!=null &&
              this.freeProductDesc__c.equals(other.getFreeProductDesc__c()))) &&
            ((this.globalID__c==null && other.getGlobalID__c()==null) || 
             (this.globalID__c!=null &&
              this.globalID__c.equals(other.getGlobalID__c()))) &&
            ((this.hasFreePrd__c==null && other.getHasFreePrd__c()==null) || 
             (this.hasFreePrd__c!=null &&
              this.hasFreePrd__c.equals(other.getHasFreePrd__c()))) &&
            ((this.hasRPPrd__c==null && other.getHasRPPrd__c()==null) || 
             (this.hasRPPrd__c!=null &&
              this.hasRPPrd__c.equals(other.getHasRPPrd__c()))) &&
            ((this.histories==null && other.getHistories()==null) || 
             (this.histories!=null &&
              this.histories.equals(other.getHistories()))) &&
            ((this.historyContractURL__c==null && other.getHistoryContractURL__c()==null) || 
             (this.historyContractURL__c!=null &&
              this.historyContractURL__c.equals(other.getHistoryContractURL__c()))) &&
            ((this.invoiceTitle__r==null && other.getInvoiceTitle__r()==null) || 
             (this.invoiceTitle__r!=null &&
              this.invoiceTitle__r.equals(other.getInvoiceTitle__r()))) &&
            ((this.isDeleted==null && other.getIsDeleted()==null) || 
             (this.isDeleted!=null &&
              this.isDeleted.equals(other.getIsDeleted()))) &&
            ((this.isPay__c==null && other.getIsPay__c()==null) || 
             (this.isPay__c!=null &&
              this.isPay__c.equals(other.getIsPay__c()))) &&
            ((this.isPaying__c==null && other.getIsPaying__c()==null) || 
             (this.isPaying__c!=null &&
              this.isPaying__c.equals(other.getIsPaying__c()))) &&
            ((this.isPrePayment__c==null && other.getIsPrePayment__c()==null) || 
             (this.isPrePayment__c!=null &&
              this.isPrePayment__c.equals(other.getIsPrePayment__c()))) &&
            ((this.isProduced__c==null && other.getIsProduced__c()==null) || 
             (this.isProduced__c!=null &&
              this.isProduced__c.equals(other.getIsProduced__c()))) &&
            ((this.lastActivityDate==null && other.getLastActivityDate()==null) || 
             (this.lastActivityDate!=null &&
              this.lastActivityDate.equals(other.getLastActivityDate()))) &&
            ((this.lastApprovedDate==null && other.getLastApprovedDate()==null) || 
             (this.lastApprovedDate!=null &&
              this.lastApprovedDate.equals(other.getLastApprovedDate()))) &&
            ((this.lastModifiedBy==null && other.getLastModifiedBy()==null) || 
             (this.lastModifiedBy!=null &&
              this.lastModifiedBy.equals(other.getLastModifiedBy()))) &&
            ((this.lastModifiedById==null && other.getLastModifiedById()==null) || 
             (this.lastModifiedById!=null &&
              this.lastModifiedById.equals(other.getLastModifiedById()))) &&
            ((this.lastModifiedDate==null && other.getLastModifiedDate()==null) || 
             (this.lastModifiedDate!=null &&
              this.lastModifiedDate.equals(other.getLastModifiedDate()))) &&
            ((this.lowestSalesPrice__c==null && other.getLowestSalesPrice__c()==null) || 
             (this.lowestSalesPrice__c!=null &&
              this.lowestSalesPrice__c.equals(other.getLowestSalesPrice__c()))) &&
            ((this.notes==null && other.getNotes()==null) || 
             (this.notes!=null &&
              this.notes.equals(other.getNotes()))) &&
            ((this.notesAndAttachments==null && other.getNotesAndAttachments()==null) || 
             (this.notesAndAttachments!=null &&
              this.notesAndAttachments.equals(other.getNotesAndAttachments()))) &&
            ((this.openActivities==null && other.getOpenActivities()==null) || 
             (this.openActivities!=null &&
              this.openActivities.equals(other.getOpenActivities()))) &&
            ((this.opportunityName__c==null && other.getOpportunityName__c()==null) || 
             (this.opportunityName__c!=null &&
              this.opportunityName__c.equals(other.getOpportunityName__c()))) &&
            ((this.opportunity__c==null && other.getOpportunity__c()==null) || 
             (this.opportunity__c!=null &&
              this.opportunity__c.equals(other.getOpportunity__c()))) &&
            ((this.opportunity__r==null && other.getOpportunity__r()==null) || 
             (this.opportunity__r!=null &&
              this.opportunity__r.equals(other.getOpportunity__r()))) &&
            ((this.owner==null && other.getOwner()==null) || 
             (this.owner!=null &&
              this.owner.equals(other.getOwner()))) &&
            ((this.ownerExpirationNotice==null && other.getOwnerExpirationNotice()==null) || 
             (this.ownerExpirationNotice!=null &&
              this.ownerExpirationNotice.equals(other.getOwnerExpirationNotice()))) &&
            ((this.ownerId==null && other.getOwnerId()==null) || 
             (this.ownerId!=null &&
              this.ownerId.equals(other.getOwnerId()))) &&
            ((this.ownerRole__c==null && other.getOwnerRole__c()==null) || 
             (this.ownerRole__c!=null &&
              this.ownerRole__c.equals(other.getOwnerRole__c()))) &&
            ((this.payRuleType__c==null && other.getPayRuleType__c()==null) || 
             (this.payRuleType__c!=null &&
              this.payRuleType__c.equals(other.getPayRuleType__c()))) &&
            ((this.payRule__c==null && other.getPayRule__c()==null) || 
             (this.payRule__c!=null &&
              this.payRule__c.equals(other.getPayRule__c()))) &&
            ((this.payRule__r==null && other.getPayRule__r()==null) || 
             (this.payRule__r!=null &&
              this.payRule__r.equals(other.getPayRule__r()))) &&
            ((this.paymentRollUpPercent__c==null && other.getPaymentRollUpPercent__c()==null) || 
             (this.paymentRollUpPercent__c!=null &&
              this.paymentRollUpPercent__c.equals(other.getPaymentRollUpPercent__c()))) &&
            ((this.paymentTransactionType__c==null && other.getPaymentTransactionType__c()==null) || 
             (this.paymentTransactionType__c!=null &&
              this.paymentTransactionType__c.equals(other.getPaymentTransactionType__c()))) &&
            ((this.phone__c==null && other.getPhone__c()==null) || 
             (this.phone__c!=null &&
              this.phone__c.equals(other.getPhone__c()))) &&
            ((this.prePaymentPercent__c==null && other.getPrePaymentPercent__c()==null) || 
             (this.prePaymentPercent__c!=null &&
              this.prePaymentPercent__c.equals(other.getPrePaymentPercent__c()))) &&
            ((this.prePayment__c==null && other.getPrePayment__c()==null) || 
             (this.prePayment__c!=null &&
              this.prePayment__c.equals(other.getPrePayment__c()))) &&
            ((this.processInstances==null && other.getProcessInstances()==null) || 
             (this.processInstances!=null &&
              this.processInstances.equals(other.getProcessInstances()))) &&
            ((this.processSteps==null && other.getProcessSteps()==null) || 
             (this.processSteps!=null &&
              this.processSteps.equals(other.getProcessSteps()))) &&
            ((this.projectTeamAprStatus__c==null && other.getProjectTeamAprStatus__c()==null) || 
             (this.projectTeamAprStatus__c!=null &&
              this.projectTeamAprStatus__c.equals(other.getProjectTeamAprStatus__c()))) &&
            ((this.publishMidDay__c==null && other.getPublishMidDay__c()==null) || 
             (this.publishMidDay__c!=null &&
              this.publishMidDay__c.equals(other.getPublishMidDay__c()))) &&
            ((this.RPApplyDesc__c==null && other.getRPApplyDesc__c()==null) || 
             (this.RPApplyDesc__c!=null &&
              this.RPApplyDesc__c.equals(other.getRPApplyDesc__c()))) &&
            ((this.RPApplyFormNo__c==null && other.getRPApplyFormNo__c()==null) || 
             (this.RPApplyFormNo__c!=null &&
              this.RPApplyFormNo__c.equals(other.getRPApplyFormNo__c()))) &&
            ((this.readyForApproval__c==null && other.getReadyForApproval__c()==null) || 
             (this.readyForApproval__c!=null &&
              this.readyForApproval__c.equals(other.getReadyForApproval__c()))) &&
            ((this.recordType==null && other.getRecordType()==null) || 
             (this.recordType!=null &&
              this.recordType.equals(other.getRecordType()))) &&
            ((this.recordTypeId==null && other.getRecordTypeId()==null) || 
             (this.recordTypeId!=null &&
              this.recordTypeId.equals(other.getRecordTypeId()))) &&
            ((this.registerName__c==null && other.getRegisterName__c()==null) || 
             (this.registerName__c!=null &&
              this.registerName__c.equals(other.getRegisterName__c()))) &&
            ((this.relatedContractNumber__c==null && other.getRelatedContractNumber__c()==null) || 
             (this.relatedContractNumber__c!=null &&
              this.relatedContractNumber__c.equals(other.getRelatedContractNumber__c()))) &&
            ((this.remainFunds__c==null && other.getRemainFunds__c()==null) || 
             (this.remainFunds__c!=null &&
              this.remainFunds__c.equals(other.getRemainFunds__c()))) &&
            ((this.salesPriceStatus__c==null && other.getSalesPriceStatus__c()==null) || 
             (this.salesPriceStatus__c!=null &&
              this.salesPriceStatus__c.equals(other.getSalesPriceStatus__c()))) &&
            ((this.salesmanSighed__c==null && other.getSalesmanSighed__c()==null) || 
             (this.salesmanSighed__c!=null &&
              this.salesmanSighed__c.equals(other.getSalesmanSighed__c()))) &&
            ((this.sequence__c==null && other.getSequence__c()==null) || 
             (this.sequence__c!=null &&
              this.sequence__c.equals(other.getSequence__c()))) &&
            ((this.shippingCity==null && other.getShippingCity()==null) || 
             (this.shippingCity!=null &&
              this.shippingCity.equals(other.getShippingCity()))) &&
            ((this.shippingCountry==null && other.getShippingCountry()==null) || 
             (this.shippingCountry!=null &&
              this.shippingCountry.equals(other.getShippingCountry()))) &&
            ((this.shippingPostalCode==null && other.getShippingPostalCode()==null) || 
             (this.shippingPostalCode!=null &&
              this.shippingPostalCode.equals(other.getShippingPostalCode()))) &&
            ((this.shippingState==null && other.getShippingState()==null) || 
             (this.shippingState!=null &&
              this.shippingState.equals(other.getShippingState()))) &&
            ((this.shippingStreet==null && other.getShippingStreet()==null) || 
             (this.shippingStreet!=null &&
              this.shippingStreet.equals(other.getShippingStreet()))) &&
            ((this.showInventoryURL__c==null && other.getShowInventoryURL__c()==null) || 
             (this.showInventoryURL__c!=null &&
              this.showInventoryURL__c.equals(other.getShowInventoryURL__c()))) &&
            ((this.showSHInventoryURL__c==null && other.getShowSHInventoryURL__c()==null) || 
             (this.showSHInventoryURL__c!=null &&
              this.showSHInventoryURL__c.equals(other.getShowSHInventoryURL__c()))) &&
            ((this.specialTerms==null && other.getSpecialTerms()==null) || 
             (this.specialTerms!=null &&
              this.specialTerms.equals(other.getSpecialTerms()))) &&
            ((this.startDate==null && other.getStartDate()==null) || 
             (this.startDate!=null &&
              this.startDate.equals(other.getStartDate()))) &&
            ((this.status==null && other.getStatus()==null) || 
             (this.status!=null &&
              this.status.equals(other.getStatus()))) &&
            ((this.statusCode==null && other.getStatusCode()==null) || 
             (this.statusCode!=null &&
              this.statusCode.equals(other.getStatusCode()))) &&
            ((this.systemModstamp==null && other.getSystemModstamp()==null) || 
             (this.systemModstamp!=null &&
              this.systemModstamp.equals(other.getSystemModstamp()))) &&
            ((this.tasks==null && other.getTasks()==null) || 
             (this.tasks!=null &&
              this.tasks.equals(other.getTasks()))) &&
            ((this.terminateReason__c==null && other.getTerminateReason__c()==null) || 
             (this.terminateReason__c!=null &&
              this.terminateReason__c.equals(other.getTerminateReason__c()))) &&
            ((this.totalListPrice__c==null && other.getTotalListPrice__c()==null) || 
             (this.totalListPrice__c!=null &&
              this.totalListPrice__c.equals(other.getTotalListPrice__c()))) &&
            ((this.totalSalesPrice__c==null && other.getTotalSalesPrice__c()==null) || 
             (this.totalSalesPrice__c!=null &&
              this.totalSalesPrice__c.equals(other.getTotalSalesPrice__c()))) &&
            ((this.wholeDiscount__c==null && other.getWholeDiscount__c()==null) || 
             (this.wholeDiscount__c!=null &&
              this.wholeDiscount__c.equals(other.getWholeDiscount__c()))) &&
            ((this.wholeListPrice__c==null && other.getWholeListPrice__c()==null) || 
             (this.wholeListPrice__c!=null &&
              this.wholeListPrice__c.equals(other.getWholeListPrice__c()))) &&
            ((this.contractcontact__r==null && other.getContractcontact__r()==null) || 
             (this.contractcontact__r!=null &&
              this.contractcontact__r.equals(other.getContractcontact__r()))) &&
            ((this.deal__r==null && other.getDeal__r()==null) || 
             (this.deal__r!=null &&
              this.deal__r.equals(other.getDeal__r()))) &&
            ((this.isPublish__c==null && other.getIsPublish__c()==null) || 
             (this.isPublish__c!=null &&
              this.isPublish__c.equals(other.getIsPublish__c()))) &&
            ((this.isQualified__c==null && other.getIsQualified__c()==null) || 
             (this.isQualified__c!=null &&
              this.isQualified__c.equals(other.getIsQualified__c())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAP_AD1StPayPercent__c() != null) {
            _hashCode += getAP_AD1StPayPercent__c().hashCode();
        }
        if (getAP_FirstPublishDay__c() != null) {
            _hashCode += getAP_FirstPublishDay__c().hashCode();
        }
        if (getAP_LastPublishDay__c() != null) {
            _hashCode += getAP_LastPublishDay__c().hashCode();
        }
        if (getAP_NormalKeyWordsCount__c() != null) {
            _hashCode += getAP_NormalKeyWordsCount__c().hashCode();
        }
        if (getAP_OtherProductCount__c() != null) {
            _hashCode += getAP_OtherProductCount__c().hashCode();
        }
        if (getAP_PayItemCount__c() != null) {
            _hashCode += getAP_PayItemCount__c().hashCode();
        }
        if (getAP_TopKeyWordsCount__c() != null) {
            _hashCode += getAP_TopKeyWordsCount__c().hashCode();
        }
        if (getAP_TotalDiscount__c() != null) {
            _hashCode += getAP_TotalDiscount__c().hashCode();
        }
        if (getAccount() != null) {
            _hashCode += getAccount().hashCode();
        }
        if (getAccountAdress__c() != null) {
            _hashCode += getAccountAdress__c().hashCode();
        }
        if (getAccountId() != null) {
            _hashCode += getAccountId().hashCode();
        }
        if (getActivatedBy() != null) {
            _hashCode += getActivatedBy().hashCode();
        }
        if (getActivatedById() != null) {
            _hashCode += getActivatedById().hashCode();
        }
        if (getActivatedDate() != null) {
            _hashCode += getActivatedDate().hashCode();
        }
        if (getActivityHistories() != null) {
            _hashCode += getActivityHistories().hashCode();
        }
        if (getApprovalField__c() != null) {
            _hashCode += getApprovalField__c().hashCode();
        }
        if (getApprovalMgr1__c() != null) {
            _hashCode += getApprovalMgr1__c().hashCode();
        }
        if (getApprovalMgr1__r() != null) {
            _hashCode += getApprovalMgr1__r().hashCode();
        }
        if (getApprovalMgr2__c() != null) {
            _hashCode += getApprovalMgr2__c().hashCode();
        }
        if (getApprovalMgr2__r() != null) {
            _hashCode += getApprovalMgr2__r().hashCode();
        }
        if (getApprovalMgr3__c() != null) {
            _hashCode += getApprovalMgr3__c().hashCode();
        }
        if (getApprovalMgr3__r() != null) {
            _hashCode += getApprovalMgr3__r().hashCode();
        }
        if (getApprovalMgr4__c() != null) {
            _hashCode += getApprovalMgr4__c().hashCode();
        }
        if (getApprovalMgr4__r() != null) {
            _hashCode += getApprovalMgr4__r().hashCode();
        }
        if (getApprovals() != null) {
            _hashCode += getApprovals().hashCode();
        }
        if (getAttachments() != null) {
            _hashCode += getAttachments().hashCode();
        }
        if (getBadContractPRDLT__c() != null) {
            _hashCode += getBadContractPRDLT__c().hashCode();
        }
        if (getBillingCity() != null) {
            _hashCode += getBillingCity().hashCode();
        }
        if (getBillingCountry() != null) {
            _hashCode += getBillingCountry().hashCode();
        }
        if (getBillingInfo__c() != null) {
            _hashCode += getBillingInfo__c().hashCode();
        }
        if (getBillingInfo__r() != null) {
            _hashCode += getBillingInfo__r().hashCode();
        }
        if (getBillingPostalCode() != null) {
            _hashCode += getBillingPostalCode().hashCode();
        }
        if (getBillingState() != null) {
            _hashCode += getBillingState().hashCode();
        }
        if (getBillingStreet() != null) {
            _hashCode += getBillingStreet().hashCode();
        }
        if (getCityID__c() != null) {
            _hashCode += getCityID__c().hashCode();
        }
        if (getCity__c() != null) {
            _hashCode += getCity__c().hashCode();
        }
        if (getCity__r() != null) {
            _hashCode += getCity__r().hashCode();
        }
        if (getCompanySigned() != null) {
            _hashCode += getCompanySigned().hashCode();
        }
        if (getCompanySignedDate() != null) {
            _hashCode += getCompanySignedDate().hashCode();
        }
        if (getCompanySignedId() != null) {
            _hashCode += getCompanySignedId().hashCode();
        }
        if (getConfirmViaWeb__c() != null) {
            _hashCode += getConfirmViaWeb__c().hashCode();
        }
        if (getContractAPStatus__c() != null) {
            _hashCode += getContractAPStatus__c().hashCode();
        }
        if (getContractBilling__r() != null) {
            _hashCode += getContractBilling__r().hashCode();
        }
        if (getContractCalNumber__c() != null) {
            _hashCode += getContractCalNumber__c().hashCode();
        }
        if (getContractContactRoles() != null) {
            _hashCode += getContractContactRoles().hashCode();
        }
        if (getContractLineItemTemp__r() != null) {
            _hashCode += getContractLineItemTemp__r().hashCode();
        }
        if (getContractLineItem__r() != null) {
            _hashCode += getContractLineItem__r().hashCode();
        }
        if (getContractNumber() != null) {
            _hashCode += getContractNumber().hashCode();
        }
        if (getContractSerialNO__c() != null) {
            _hashCode += getContractSerialNO__c().hashCode();
        }
        if (getContractShopAccount__r() != null) {
            _hashCode += getContractShopAccount__r().hashCode();
        }
        if (getContractSource__c() != null) {
            _hashCode += getContractSource__c().hashCode();
        }
        if (getContractStage__c() != null) {
            _hashCode += getContractStage__c().hashCode();
        }
        if (getContractStatus__c() != null) {
            _hashCode += getContractStatus__c().hashCode();
        }
        if (getContractTerm() != null) {
            _hashCode += getContractTerm().hashCode();
        }
        if (getContractType__c() != null) {
            _hashCode += getContractType__c().hashCode();
        }
        if (getContractUpdTrack__c() != null) {
            _hashCode += getContractUpdTrack__c().hashCode();
        }
        if (getContract_BankAccount__r() != null) {
            _hashCode += getContract_BankAccount__r().hashCode();
        }
        if (getContract_PayRule__r() != null) {
            _hashCode += getContract_PayRule__r().hashCode();
        }
        if (getContract__r() != null) {
            _hashCode += getContract__r().hashCode();
        }
        if (getCreatedBy() != null) {
            _hashCode += getCreatedBy().hashCode();
        }
        if (getCreatedById() != null) {
            _hashCode += getCreatedById().hashCode();
        }
        if (getCreatedDate() != null) {
            _hashCode += getCreatedDate().hashCode();
        }
        if (getCustomerSigned() != null) {
            _hashCode += getCustomerSigned().hashCode();
        }
        if (getCustomerSignedDate() != null) {
            _hashCode += getCustomerSignedDate().hashCode();
        }
        if (getCustomerSignedId() != null) {
            _hashCode += getCustomerSignedId().hashCode();
        }
        if (getCustomerSignedTitle() != null) {
            _hashCode += getCustomerSignedTitle().hashCode();
        }
        if (getDealGroup__r() != null) {
            _hashCode += getDealGroup__r().hashCode();
        }
        if (getDeficitDealAPNumber__c() != null) {
            _hashCode += getDeficitDealAPNumber__c().hashCode();
        }
        if (getDepartment__c() != null) {
            _hashCode += getDepartment__c().hashCode();
        }
        if (getDescription() != null) {
            _hashCode += getDescription().hashCode();
        }
        if (getEndDate() != null) {
            _hashCode += getEndDate().hashCode();
        }
        if (getEvents() != null) {
            _hashCode += getEvents().hashCode();
        }
        if (getFreeProductDescShow__c() != null) {
            _hashCode += getFreeProductDescShow__c().hashCode();
        }
        if (getFreeProductDesc__c() != null) {
            _hashCode += getFreeProductDesc__c().hashCode();
        }
        if (getGlobalID__c() != null) {
            _hashCode += getGlobalID__c().hashCode();
        }
        if (getHasFreePrd__c() != null) {
            _hashCode += getHasFreePrd__c().hashCode();
        }
        if (getHasRPPrd__c() != null) {
            _hashCode += getHasRPPrd__c().hashCode();
        }
        if (getHistories() != null) {
            _hashCode += getHistories().hashCode();
        }
        if (getHistoryContractURL__c() != null) {
            _hashCode += getHistoryContractURL__c().hashCode();
        }
        if (getInvoiceTitle__r() != null) {
            _hashCode += getInvoiceTitle__r().hashCode();
        }
        if (getIsDeleted() != null) {
            _hashCode += getIsDeleted().hashCode();
        }
        if (getIsPay__c() != null) {
            _hashCode += getIsPay__c().hashCode();
        }
        if (getIsPaying__c() != null) {
            _hashCode += getIsPaying__c().hashCode();
        }
        if (getIsPrePayment__c() != null) {
            _hashCode += getIsPrePayment__c().hashCode();
        }
        if (getIsProduced__c() != null) {
            _hashCode += getIsProduced__c().hashCode();
        }
        if (getLastActivityDate() != null) {
            _hashCode += getLastActivityDate().hashCode();
        }
        if (getLastApprovedDate() != null) {
            _hashCode += getLastApprovedDate().hashCode();
        }
        if (getLastModifiedBy() != null) {
            _hashCode += getLastModifiedBy().hashCode();
        }
        if (getLastModifiedById() != null) {
            _hashCode += getLastModifiedById().hashCode();
        }
        if (getLastModifiedDate() != null) {
            _hashCode += getLastModifiedDate().hashCode();
        }
        if (getLowestSalesPrice__c() != null) {
            _hashCode += getLowestSalesPrice__c().hashCode();
        }
        if (getNotes() != null) {
            _hashCode += getNotes().hashCode();
        }
        if (getNotesAndAttachments() != null) {
            _hashCode += getNotesAndAttachments().hashCode();
        }
        if (getOpenActivities() != null) {
            _hashCode += getOpenActivities().hashCode();
        }
        if (getOpportunityName__c() != null) {
            _hashCode += getOpportunityName__c().hashCode();
        }
        if (getOpportunity__c() != null) {
            _hashCode += getOpportunity__c().hashCode();
        }
        if (getOpportunity__r() != null) {
            _hashCode += getOpportunity__r().hashCode();
        }
        if (getOwner() != null) {
            _hashCode += getOwner().hashCode();
        }
        if (getOwnerExpirationNotice() != null) {
            _hashCode += getOwnerExpirationNotice().hashCode();
        }
        if (getOwnerId() != null) {
            _hashCode += getOwnerId().hashCode();
        }
        if (getOwnerRole__c() != null) {
            _hashCode += getOwnerRole__c().hashCode();
        }
        if (getPayRuleType__c() != null) {
            _hashCode += getPayRuleType__c().hashCode();
        }
        if (getPayRule__c() != null) {
            _hashCode += getPayRule__c().hashCode();
        }
        if (getPayRule__r() != null) {
            _hashCode += getPayRule__r().hashCode();
        }
        if (getPaymentRollUpPercent__c() != null) {
            _hashCode += getPaymentRollUpPercent__c().hashCode();
        }
        if (getPaymentTransactionType__c() != null) {
            _hashCode += getPaymentTransactionType__c().hashCode();
        }
        if (getPhone__c() != null) {
            _hashCode += getPhone__c().hashCode();
        }
        if (getPrePaymentPercent__c() != null) {
            _hashCode += getPrePaymentPercent__c().hashCode();
        }
        if (getPrePayment__c() != null) {
            _hashCode += getPrePayment__c().hashCode();
        }
        if (getProcessInstances() != null) {
            _hashCode += getProcessInstances().hashCode();
        }
        if (getProcessSteps() != null) {
            _hashCode += getProcessSteps().hashCode();
        }
        if (getProjectTeamAprStatus__c() != null) {
            _hashCode += getProjectTeamAprStatus__c().hashCode();
        }
        if (getPublishMidDay__c() != null) {
            _hashCode += getPublishMidDay__c().hashCode();
        }
        if (getRPApplyDesc__c() != null) {
            _hashCode += getRPApplyDesc__c().hashCode();
        }
        if (getRPApplyFormNo__c() != null) {
            _hashCode += getRPApplyFormNo__c().hashCode();
        }
        if (getReadyForApproval__c() != null) {
            _hashCode += getReadyForApproval__c().hashCode();
        }
        if (getRecordType() != null) {
            _hashCode += getRecordType().hashCode();
        }
        if (getRecordTypeId() != null) {
            _hashCode += getRecordTypeId().hashCode();
        }
        if (getRegisterName__c() != null) {
            _hashCode += getRegisterName__c().hashCode();
        }
        if (getRelatedContractNumber__c() != null) {
            _hashCode += getRelatedContractNumber__c().hashCode();
        }
        if (getRemainFunds__c() != null) {
            _hashCode += getRemainFunds__c().hashCode();
        }
        if (getSalesPriceStatus__c() != null) {
            _hashCode += getSalesPriceStatus__c().hashCode();
        }
        if (getSalesmanSighed__c() != null) {
            _hashCode += getSalesmanSighed__c().hashCode();
        }
        if (getSequence__c() != null) {
            _hashCode += getSequence__c().hashCode();
        }
        if (getShippingCity() != null) {
            _hashCode += getShippingCity().hashCode();
        }
        if (getShippingCountry() != null) {
            _hashCode += getShippingCountry().hashCode();
        }
        if (getShippingPostalCode() != null) {
            _hashCode += getShippingPostalCode().hashCode();
        }
        if (getShippingState() != null) {
            _hashCode += getShippingState().hashCode();
        }
        if (getShippingStreet() != null) {
            _hashCode += getShippingStreet().hashCode();
        }
        if (getShowInventoryURL__c() != null) {
            _hashCode += getShowInventoryURL__c().hashCode();
        }
        if (getShowSHInventoryURL__c() != null) {
            _hashCode += getShowSHInventoryURL__c().hashCode();
        }
        if (getSpecialTerms() != null) {
            _hashCode += getSpecialTerms().hashCode();
        }
        if (getStartDate() != null) {
            _hashCode += getStartDate().hashCode();
        }
        if (getStatus() != null) {
            _hashCode += getStatus().hashCode();
        }
        if (getStatusCode() != null) {
            _hashCode += getStatusCode().hashCode();
        }
        if (getSystemModstamp() != null) {
            _hashCode += getSystemModstamp().hashCode();
        }
        if (getTasks() != null) {
            _hashCode += getTasks().hashCode();
        }
        if (getTerminateReason__c() != null) {
            _hashCode += getTerminateReason__c().hashCode();
        }
        if (getTotalListPrice__c() != null) {
            _hashCode += getTotalListPrice__c().hashCode();
        }
        if (getTotalSalesPrice__c() != null) {
            _hashCode += getTotalSalesPrice__c().hashCode();
        }
        if (getWholeDiscount__c() != null) {
            _hashCode += getWholeDiscount__c().hashCode();
        }
        if (getWholeListPrice__c() != null) {
            _hashCode += getWholeListPrice__c().hashCode();
        }
        if (getContractcontact__r() != null) {
            _hashCode += getContractcontact__r().hashCode();
        }
        if (getDeal__r() != null) {
            _hashCode += getDeal__r().hashCode();
        }
        if (getIsPublish__c() != null) {
            _hashCode += getIsPublish__c().hashCode();
        }
        if (getIsQualified__c() != null) {
            _hashCode += getIsQualified__c().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Contract.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Contract"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AP_AD1StPayPercent__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AP_AD1stPayPercent__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AP_FirstPublishDay__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AP_FirstPublishDay__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AP_LastPublishDay__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AP_LastPublishDay__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AP_NormalKeyWordsCount__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AP_NormalKeyWordsCount__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AP_OtherProductCount__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AP_OtherProductCount__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AP_PayItemCount__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AP_PayItemCount__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AP_TopKeyWordsCount__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AP_TopKeyWordsCount__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AP_TotalDiscount__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AP_TotalDiscount__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("account");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Account"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Account"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accountAdress__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AccountAdress__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accountId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AccountId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("activatedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ActivatedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("activatedById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ActivatedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("activatedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ActivatedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("activityHistories");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ActivityHistories"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("approvalField__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ApprovalField__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("approvalMgr1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ApprovalMgr1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("approvalMgr1__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ApprovalMgr1__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("approvalMgr2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ApprovalMgr2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("approvalMgr2__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ApprovalMgr2__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("approvalMgr3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ApprovalMgr3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("approvalMgr3__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ApprovalMgr3__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("approvalMgr4__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ApprovalMgr4__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("approvalMgr4__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ApprovalMgr4__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("approvals");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Approvals"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Attachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("badContractPRDLT__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BadContractPRDLT__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("billingCity");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BillingCity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("billingCountry");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BillingCountry"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("billingInfo__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BillingInfo__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("billingInfo__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BillingInfo__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BillingInfo__c"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("billingPostalCode");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BillingPostalCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("billingState");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BillingState"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("billingStreet");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BillingStreet"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cityID__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CityID__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("city__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "City__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("city__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "City__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "City__c"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("companySigned");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CompanySigned"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("companySignedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CompanySignedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("companySignedId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CompanySignedId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("confirmViaWeb__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ConfirmViaWeb__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contractAPStatus__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ContractAPStatus__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contractBilling__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ContractBilling__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contractCalNumber__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ContractCalNumber__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contractContactRoles");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ContractContactRoles"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contractLineItemTemp__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ContractLineItemTemp__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contractLineItem__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ContractLineItem__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contractNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ContractNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contractSerialNO__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ContractSerialNO__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contractShopAccount__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ContractShopAccount__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contractSource__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ContractSource__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contractStage__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ContractStage__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contractStatus__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ContractStatus__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contractTerm");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ContractTerm"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contractType__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ContractType__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contractUpdTrack__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ContractUpdTrack__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contract_BankAccount__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Contract_BankAccount__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contract_PayRule__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Contract_PayRule__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contract__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Contract__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("customerSigned");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CustomerSigned"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Contact"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("customerSignedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CustomerSignedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("customerSignedId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CustomerSignedId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("customerSignedTitle");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CustomerSignedTitle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dealGroup__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DealGroup__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("deficitDealAPNumber__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DeficitDealAPNumber__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("department__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Department__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("endDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "EndDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("events");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Events"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("freeProductDescShow__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "FreeProductDescShow__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("freeProductDesc__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "FreeProductDesc__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("globalID__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "GlobalID__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hasFreePrd__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "HasFreePrd__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hasRPPrd__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "HasRPPrd__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("histories");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Histories"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("historyContractURL__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "HistoryContractURL__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("invoiceTitle__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "InvoiceTitle__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isDeleted");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsDeleted"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isPay__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsPay__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isPaying__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsPaying__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isPrePayment__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsPrePayment__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isProduced__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsProduced__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastActivityDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastActivityDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastApprovedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastApprovedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lowestSalesPrice__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LowestSalesPrice__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notes");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Notes"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notesAndAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NotesAndAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("openActivities");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OpenActivities"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("opportunityName__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OpportunityName__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("opportunity__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Opportunity__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("opportunity__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Opportunity__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Opportunity"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("owner");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Owner"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ownerExpirationNotice");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OwnerExpirationNotice"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ownerId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OwnerId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ownerRole__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OwnerRole__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("payRuleType__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PayRuleType__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("payRule__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PayRule__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("payRule__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PayRule__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PayRule__c"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paymentRollUpPercent__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PaymentRollUpPercent__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paymentTransactionType__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PaymentTransactionType__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("phone__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Phone__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("prePaymentPercent__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PrePaymentPercent__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("prePayment__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PrePayment__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processInstances");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessInstances"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processSteps");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessSteps"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("projectTeamAprStatus__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProjectTeamAprStatus__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("publishMidDay__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PublishMidDay__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RPApplyDesc__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RPApplyDesc__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RPApplyFormNo__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RPApplyFormNo__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("readyForApproval__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ReadyForApproval__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("recordType");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RecordType"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RecordType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("recordTypeId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RecordTypeId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("registerName__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RegisterName__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("relatedContractNumber__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RelatedContractNumber__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remainFunds__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RemainFunds__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("salesPriceStatus__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SalesPriceStatus__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("salesmanSighed__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SalesmanSighed__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sequence__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Sequence__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shippingCity");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ShippingCity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shippingCountry");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ShippingCountry"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shippingPostalCode");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ShippingPostalCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shippingState");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ShippingState"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shippingStreet");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ShippingStreet"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("showInventoryURL__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ShowInventoryURL__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("showSHInventoryURL__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ShowSHInventoryURL__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("specialTerms");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SpecialTerms"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("startDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "StartDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("status");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("statusCode");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "StatusCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("systemModstamp");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SystemModstamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tasks");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Tasks"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("terminateReason__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TerminateReason__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalListPrice__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TotalListPrice__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalSalesPrice__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TotalSalesPrice__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wholeDiscount__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "WholeDiscount__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wholeListPrice__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "WholeListPrice__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contractcontact__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "contractcontact__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("deal__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "deal__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isPublish__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "isPublish__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isQualified__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "isQualified__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
