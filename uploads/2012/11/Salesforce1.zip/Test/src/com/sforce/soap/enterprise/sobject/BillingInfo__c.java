/**
 * BillingInfo__c.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.sforce.soap.enterprise.sobject;

public class BillingInfo__c  extends com.sforce.soap.enterprise.sobject.SObject  implements java.io.Serializable {
    private java.util.Date AP_1ExpectedDay__c;

    private java.lang.Double AP_1StPayAmount__c;

    private java.util.Date AP_2ExpectedDay__c;

    private java.lang.Double AP_PayItemCount__c;

    private java.lang.String accountBank__c;

    private java.lang.String accountName__c;

    private java.lang.String accountNo__c;

    private java.lang.String address__c;

    private java.lang.Double amount__c;

    private com.sforce.soap.enterprise.QueryResult attachments;

    private java.lang.String billingCompany__c;

    private com.sforce.soap.enterprise.QueryResult billingInfoPay__r;

    private java.lang.String contactPhone__c;

    private java.lang.String contact__c;

    private com.sforce.soap.enterprise.QueryResult contractBilling__r;

    private java.lang.String contract__c;

    private com.sforce.soap.enterprise.sobject.Contract contract__r;

    private com.sforce.soap.enterprise.sobject.User createdBy;

    private java.lang.String createdById;

    private java.util.Calendar createdDate;

    private java.lang.Double firstPaymentRate__c;

    private java.lang.Double firstPayment__c;

    private java.lang.String invoiceCompany__c;

    private java.lang.String invoiceText__c;

    private java.lang.String invoiceType__c;

    private java.lang.Boolean isDeleted;

    private com.sforce.soap.enterprise.sobject.User lastModifiedBy;

    private java.lang.String lastModifiedById;

    private java.util.Calendar lastModifiedDate;

    private java.lang.String name;

    private com.sforce.soap.enterprise.QueryResult notes;

    private com.sforce.soap.enterprise.QueryResult notesAndAttachments;

    private java.lang.Double paymentAmount__c;

    private java.lang.String payment__c;

    private com.sforce.soap.enterprise.QueryResult processInstances;

    private com.sforce.soap.enterprise.QueryResult processSteps;

    private java.util.Calendar systemModstamp;

    private java.lang.String taxNumber__c;

    public BillingInfo__c() {
    }

    public BillingInfo__c(
           java.lang.String[] fieldsToNull,
           java.lang.String id,
           java.util.Date AP_1ExpectedDay__c,
           java.lang.Double AP_1StPayAmount__c,
           java.util.Date AP_2ExpectedDay__c,
           java.lang.Double AP_PayItemCount__c,
           java.lang.String accountBank__c,
           java.lang.String accountName__c,
           java.lang.String accountNo__c,
           java.lang.String address__c,
           java.lang.Double amount__c,
           com.sforce.soap.enterprise.QueryResult attachments,
           java.lang.String billingCompany__c,
           com.sforce.soap.enterprise.QueryResult billingInfoPay__r,
           java.lang.String contactPhone__c,
           java.lang.String contact__c,
           com.sforce.soap.enterprise.QueryResult contractBilling__r,
           java.lang.String contract__c,
           com.sforce.soap.enterprise.sobject.Contract contract__r,
           com.sforce.soap.enterprise.sobject.User createdBy,
           java.lang.String createdById,
           java.util.Calendar createdDate,
           java.lang.Double firstPaymentRate__c,
           java.lang.Double firstPayment__c,
           java.lang.String invoiceCompany__c,
           java.lang.String invoiceText__c,
           java.lang.String invoiceType__c,
           java.lang.Boolean isDeleted,
           com.sforce.soap.enterprise.sobject.User lastModifiedBy,
           java.lang.String lastModifiedById,
           java.util.Calendar lastModifiedDate,
           java.lang.String name,
           com.sforce.soap.enterprise.QueryResult notes,
           com.sforce.soap.enterprise.QueryResult notesAndAttachments,
           java.lang.Double paymentAmount__c,
           java.lang.String payment__c,
           com.sforce.soap.enterprise.QueryResult processInstances,
           com.sforce.soap.enterprise.QueryResult processSteps,
           java.util.Calendar systemModstamp,
           java.lang.String taxNumber__c) {
        super(
            fieldsToNull,
            id);
        this.AP_1ExpectedDay__c = AP_1ExpectedDay__c;
        this.AP_1StPayAmount__c = AP_1StPayAmount__c;
        this.AP_2ExpectedDay__c = AP_2ExpectedDay__c;
        this.AP_PayItemCount__c = AP_PayItemCount__c;
        this.accountBank__c = accountBank__c;
        this.accountName__c = accountName__c;
        this.accountNo__c = accountNo__c;
        this.address__c = address__c;
        this.amount__c = amount__c;
        this.attachments = attachments;
        this.billingCompany__c = billingCompany__c;
        this.billingInfoPay__r = billingInfoPay__r;
        this.contactPhone__c = contactPhone__c;
        this.contact__c = contact__c;
        this.contractBilling__r = contractBilling__r;
        this.contract__c = contract__c;
        this.contract__r = contract__r;
        this.createdBy = createdBy;
        this.createdById = createdById;
        this.createdDate = createdDate;
        this.firstPaymentRate__c = firstPaymentRate__c;
        this.firstPayment__c = firstPayment__c;
        this.invoiceCompany__c = invoiceCompany__c;
        this.invoiceText__c = invoiceText__c;
        this.invoiceType__c = invoiceType__c;
        this.isDeleted = isDeleted;
        this.lastModifiedBy = lastModifiedBy;
        this.lastModifiedById = lastModifiedById;
        this.lastModifiedDate = lastModifiedDate;
        this.name = name;
        this.notes = notes;
        this.notesAndAttachments = notesAndAttachments;
        this.paymentAmount__c = paymentAmount__c;
        this.payment__c = payment__c;
        this.processInstances = processInstances;
        this.processSteps = processSteps;
        this.systemModstamp = systemModstamp;
        this.taxNumber__c = taxNumber__c;
    }


    /**
     * Gets the AP_1ExpectedDay__c value for this BillingInfo__c.
     * 
     * @return AP_1ExpectedDay__c
     */
    public java.util.Date getAP_1ExpectedDay__c() {
        return AP_1ExpectedDay__c;
    }


    /**
     * Sets the AP_1ExpectedDay__c value for this BillingInfo__c.
     * 
     * @param AP_1ExpectedDay__c
     */
    public void setAP_1ExpectedDay__c(java.util.Date AP_1ExpectedDay__c) {
        this.AP_1ExpectedDay__c = AP_1ExpectedDay__c;
    }


    /**
     * Gets the AP_1StPayAmount__c value for this BillingInfo__c.
     * 
     * @return AP_1StPayAmount__c
     */
    public java.lang.Double getAP_1StPayAmount__c() {
        return AP_1StPayAmount__c;
    }


    /**
     * Sets the AP_1StPayAmount__c value for this BillingInfo__c.
     * 
     * @param AP_1StPayAmount__c
     */
    public void setAP_1StPayAmount__c(java.lang.Double AP_1StPayAmount__c) {
        this.AP_1StPayAmount__c = AP_1StPayAmount__c;
    }


    /**
     * Gets the AP_2ExpectedDay__c value for this BillingInfo__c.
     * 
     * @return AP_2ExpectedDay__c
     */
    public java.util.Date getAP_2ExpectedDay__c() {
        return AP_2ExpectedDay__c;
    }


    /**
     * Sets the AP_2ExpectedDay__c value for this BillingInfo__c.
     * 
     * @param AP_2ExpectedDay__c
     */
    public void setAP_2ExpectedDay__c(java.util.Date AP_2ExpectedDay__c) {
        this.AP_2ExpectedDay__c = AP_2ExpectedDay__c;
    }


    /**
     * Gets the AP_PayItemCount__c value for this BillingInfo__c.
     * 
     * @return AP_PayItemCount__c
     */
    public java.lang.Double getAP_PayItemCount__c() {
        return AP_PayItemCount__c;
    }


    /**
     * Sets the AP_PayItemCount__c value for this BillingInfo__c.
     * 
     * @param AP_PayItemCount__c
     */
    public void setAP_PayItemCount__c(java.lang.Double AP_PayItemCount__c) {
        this.AP_PayItemCount__c = AP_PayItemCount__c;
    }


    /**
     * Gets the accountBank__c value for this BillingInfo__c.
     * 
     * @return accountBank__c
     */
    public java.lang.String getAccountBank__c() {
        return accountBank__c;
    }


    /**
     * Sets the accountBank__c value for this BillingInfo__c.
     * 
     * @param accountBank__c
     */
    public void setAccountBank__c(java.lang.String accountBank__c) {
        this.accountBank__c = accountBank__c;
    }


    /**
     * Gets the accountName__c value for this BillingInfo__c.
     * 
     * @return accountName__c
     */
    public java.lang.String getAccountName__c() {
        return accountName__c;
    }


    /**
     * Sets the accountName__c value for this BillingInfo__c.
     * 
     * @param accountName__c
     */
    public void setAccountName__c(java.lang.String accountName__c) {
        this.accountName__c = accountName__c;
    }


    /**
     * Gets the accountNo__c value for this BillingInfo__c.
     * 
     * @return accountNo__c
     */
    public java.lang.String getAccountNo__c() {
        return accountNo__c;
    }


    /**
     * Sets the accountNo__c value for this BillingInfo__c.
     * 
     * @param accountNo__c
     */
    public void setAccountNo__c(java.lang.String accountNo__c) {
        this.accountNo__c = accountNo__c;
    }


    /**
     * Gets the address__c value for this BillingInfo__c.
     * 
     * @return address__c
     */
    public java.lang.String getAddress__c() {
        return address__c;
    }


    /**
     * Sets the address__c value for this BillingInfo__c.
     * 
     * @param address__c
     */
    public void setAddress__c(java.lang.String address__c) {
        this.address__c = address__c;
    }


    /**
     * Gets the amount__c value for this BillingInfo__c.
     * 
     * @return amount__c
     */
    public java.lang.Double getAmount__c() {
        return amount__c;
    }


    /**
     * Sets the amount__c value for this BillingInfo__c.
     * 
     * @param amount__c
     */
    public void setAmount__c(java.lang.Double amount__c) {
        this.amount__c = amount__c;
    }


    /**
     * Gets the attachments value for this BillingInfo__c.
     * 
     * @return attachments
     */
    public com.sforce.soap.enterprise.QueryResult getAttachments() {
        return attachments;
    }


    /**
     * Sets the attachments value for this BillingInfo__c.
     * 
     * @param attachments
     */
    public void setAttachments(com.sforce.soap.enterprise.QueryResult attachments) {
        this.attachments = attachments;
    }


    /**
     * Gets the billingCompany__c value for this BillingInfo__c.
     * 
     * @return billingCompany__c
     */
    public java.lang.String getBillingCompany__c() {
        return billingCompany__c;
    }


    /**
     * Sets the billingCompany__c value for this BillingInfo__c.
     * 
     * @param billingCompany__c
     */
    public void setBillingCompany__c(java.lang.String billingCompany__c) {
        this.billingCompany__c = billingCompany__c;
    }


    /**
     * Gets the billingInfoPay__r value for this BillingInfo__c.
     * 
     * @return billingInfoPay__r
     */
    public com.sforce.soap.enterprise.QueryResult getBillingInfoPay__r() {
        return billingInfoPay__r;
    }


    /**
     * Sets the billingInfoPay__r value for this BillingInfo__c.
     * 
     * @param billingInfoPay__r
     */
    public void setBillingInfoPay__r(com.sforce.soap.enterprise.QueryResult billingInfoPay__r) {
        this.billingInfoPay__r = billingInfoPay__r;
    }


    /**
     * Gets the contactPhone__c value for this BillingInfo__c.
     * 
     * @return contactPhone__c
     */
    public java.lang.String getContactPhone__c() {
        return contactPhone__c;
    }


    /**
     * Sets the contactPhone__c value for this BillingInfo__c.
     * 
     * @param contactPhone__c
     */
    public void setContactPhone__c(java.lang.String contactPhone__c) {
        this.contactPhone__c = contactPhone__c;
    }


    /**
     * Gets the contact__c value for this BillingInfo__c.
     * 
     * @return contact__c
     */
    public java.lang.String getContact__c() {
        return contact__c;
    }


    /**
     * Sets the contact__c value for this BillingInfo__c.
     * 
     * @param contact__c
     */
    public void setContact__c(java.lang.String contact__c) {
        this.contact__c = contact__c;
    }


    /**
     * Gets the contractBilling__r value for this BillingInfo__c.
     * 
     * @return contractBilling__r
     */
    public com.sforce.soap.enterprise.QueryResult getContractBilling__r() {
        return contractBilling__r;
    }


    /**
     * Sets the contractBilling__r value for this BillingInfo__c.
     * 
     * @param contractBilling__r
     */
    public void setContractBilling__r(com.sforce.soap.enterprise.QueryResult contractBilling__r) {
        this.contractBilling__r = contractBilling__r;
    }


    /**
     * Gets the contract__c value for this BillingInfo__c.
     * 
     * @return contract__c
     */
    public java.lang.String getContract__c() {
        return contract__c;
    }


    /**
     * Sets the contract__c value for this BillingInfo__c.
     * 
     * @param contract__c
     */
    public void setContract__c(java.lang.String contract__c) {
        this.contract__c = contract__c;
    }


    /**
     * Gets the contract__r value for this BillingInfo__c.
     * 
     * @return contract__r
     */
    public com.sforce.soap.enterprise.sobject.Contract getContract__r() {
        return contract__r;
    }


    /**
     * Sets the contract__r value for this BillingInfo__c.
     * 
     * @param contract__r
     */
    public void setContract__r(com.sforce.soap.enterprise.sobject.Contract contract__r) {
        this.contract__r = contract__r;
    }


    /**
     * Gets the createdBy value for this BillingInfo__c.
     * 
     * @return createdBy
     */
    public com.sforce.soap.enterprise.sobject.User getCreatedBy() {
        return createdBy;
    }


    /**
     * Sets the createdBy value for this BillingInfo__c.
     * 
     * @param createdBy
     */
    public void setCreatedBy(com.sforce.soap.enterprise.sobject.User createdBy) {
        this.createdBy = createdBy;
    }


    /**
     * Gets the createdById value for this BillingInfo__c.
     * 
     * @return createdById
     */
    public java.lang.String getCreatedById() {
        return createdById;
    }


    /**
     * Sets the createdById value for this BillingInfo__c.
     * 
     * @param createdById
     */
    public void setCreatedById(java.lang.String createdById) {
        this.createdById = createdById;
    }


    /**
     * Gets the createdDate value for this BillingInfo__c.
     * 
     * @return createdDate
     */
    public java.util.Calendar getCreatedDate() {
        return createdDate;
    }


    /**
     * Sets the createdDate value for this BillingInfo__c.
     * 
     * @param createdDate
     */
    public void setCreatedDate(java.util.Calendar createdDate) {
        this.createdDate = createdDate;
    }


    /**
     * Gets the firstPaymentRate__c value for this BillingInfo__c.
     * 
     * @return firstPaymentRate__c
     */
    public java.lang.Double getFirstPaymentRate__c() {
        return firstPaymentRate__c;
    }


    /**
     * Sets the firstPaymentRate__c value for this BillingInfo__c.
     * 
     * @param firstPaymentRate__c
     */
    public void setFirstPaymentRate__c(java.lang.Double firstPaymentRate__c) {
        this.firstPaymentRate__c = firstPaymentRate__c;
    }


    /**
     * Gets the firstPayment__c value for this BillingInfo__c.
     * 
     * @return firstPayment__c
     */
    public java.lang.Double getFirstPayment__c() {
        return firstPayment__c;
    }


    /**
     * Sets the firstPayment__c value for this BillingInfo__c.
     * 
     * @param firstPayment__c
     */
    public void setFirstPayment__c(java.lang.Double firstPayment__c) {
        this.firstPayment__c = firstPayment__c;
    }


    /**
     * Gets the invoiceCompany__c value for this BillingInfo__c.
     * 
     * @return invoiceCompany__c
     */
    public java.lang.String getInvoiceCompany__c() {
        return invoiceCompany__c;
    }


    /**
     * Sets the invoiceCompany__c value for this BillingInfo__c.
     * 
     * @param invoiceCompany__c
     */
    public void setInvoiceCompany__c(java.lang.String invoiceCompany__c) {
        this.invoiceCompany__c = invoiceCompany__c;
    }


    /**
     * Gets the invoiceText__c value for this BillingInfo__c.
     * 
     * @return invoiceText__c
     */
    public java.lang.String getInvoiceText__c() {
        return invoiceText__c;
    }


    /**
     * Sets the invoiceText__c value for this BillingInfo__c.
     * 
     * @param invoiceText__c
     */
    public void setInvoiceText__c(java.lang.String invoiceText__c) {
        this.invoiceText__c = invoiceText__c;
    }


    /**
     * Gets the invoiceType__c value for this BillingInfo__c.
     * 
     * @return invoiceType__c
     */
    public java.lang.String getInvoiceType__c() {
        return invoiceType__c;
    }


    /**
     * Sets the invoiceType__c value for this BillingInfo__c.
     * 
     * @param invoiceType__c
     */
    public void setInvoiceType__c(java.lang.String invoiceType__c) {
        this.invoiceType__c = invoiceType__c;
    }


    /**
     * Gets the isDeleted value for this BillingInfo__c.
     * 
     * @return isDeleted
     */
    public java.lang.Boolean getIsDeleted() {
        return isDeleted;
    }


    /**
     * Sets the isDeleted value for this BillingInfo__c.
     * 
     * @param isDeleted
     */
    public void setIsDeleted(java.lang.Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }


    /**
     * Gets the lastModifiedBy value for this BillingInfo__c.
     * 
     * @return lastModifiedBy
     */
    public com.sforce.soap.enterprise.sobject.User getLastModifiedBy() {
        return lastModifiedBy;
    }


    /**
     * Sets the lastModifiedBy value for this BillingInfo__c.
     * 
     * @param lastModifiedBy
     */
    public void setLastModifiedBy(com.sforce.soap.enterprise.sobject.User lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }


    /**
     * Gets the lastModifiedById value for this BillingInfo__c.
     * 
     * @return lastModifiedById
     */
    public java.lang.String getLastModifiedById() {
        return lastModifiedById;
    }


    /**
     * Sets the lastModifiedById value for this BillingInfo__c.
     * 
     * @param lastModifiedById
     */
    public void setLastModifiedById(java.lang.String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }


    /**
     * Gets the lastModifiedDate value for this BillingInfo__c.
     * 
     * @return lastModifiedDate
     */
    public java.util.Calendar getLastModifiedDate() {
        return lastModifiedDate;
    }


    /**
     * Sets the lastModifiedDate value for this BillingInfo__c.
     * 
     * @param lastModifiedDate
     */
    public void setLastModifiedDate(java.util.Calendar lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }


    /**
     * Gets the name value for this BillingInfo__c.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this BillingInfo__c.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the notes value for this BillingInfo__c.
     * 
     * @return notes
     */
    public com.sforce.soap.enterprise.QueryResult getNotes() {
        return notes;
    }


    /**
     * Sets the notes value for this BillingInfo__c.
     * 
     * @param notes
     */
    public void setNotes(com.sforce.soap.enterprise.QueryResult notes) {
        this.notes = notes;
    }


    /**
     * Gets the notesAndAttachments value for this BillingInfo__c.
     * 
     * @return notesAndAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getNotesAndAttachments() {
        return notesAndAttachments;
    }


    /**
     * Sets the notesAndAttachments value for this BillingInfo__c.
     * 
     * @param notesAndAttachments
     */
    public void setNotesAndAttachments(com.sforce.soap.enterprise.QueryResult notesAndAttachments) {
        this.notesAndAttachments = notesAndAttachments;
    }


    /**
     * Gets the paymentAmount__c value for this BillingInfo__c.
     * 
     * @return paymentAmount__c
     */
    public java.lang.Double getPaymentAmount__c() {
        return paymentAmount__c;
    }


    /**
     * Sets the paymentAmount__c value for this BillingInfo__c.
     * 
     * @param paymentAmount__c
     */
    public void setPaymentAmount__c(java.lang.Double paymentAmount__c) {
        this.paymentAmount__c = paymentAmount__c;
    }


    /**
     * Gets the payment__c value for this BillingInfo__c.
     * 
     * @return payment__c
     */
    public java.lang.String getPayment__c() {
        return payment__c;
    }


    /**
     * Sets the payment__c value for this BillingInfo__c.
     * 
     * @param payment__c
     */
    public void setPayment__c(java.lang.String payment__c) {
        this.payment__c = payment__c;
    }


    /**
     * Gets the processInstances value for this BillingInfo__c.
     * 
     * @return processInstances
     */
    public com.sforce.soap.enterprise.QueryResult getProcessInstances() {
        return processInstances;
    }


    /**
     * Sets the processInstances value for this BillingInfo__c.
     * 
     * @param processInstances
     */
    public void setProcessInstances(com.sforce.soap.enterprise.QueryResult processInstances) {
        this.processInstances = processInstances;
    }


    /**
     * Gets the processSteps value for this BillingInfo__c.
     * 
     * @return processSteps
     */
    public com.sforce.soap.enterprise.QueryResult getProcessSteps() {
        return processSteps;
    }


    /**
     * Sets the processSteps value for this BillingInfo__c.
     * 
     * @param processSteps
     */
    public void setProcessSteps(com.sforce.soap.enterprise.QueryResult processSteps) {
        this.processSteps = processSteps;
    }


    /**
     * Gets the systemModstamp value for this BillingInfo__c.
     * 
     * @return systemModstamp
     */
    public java.util.Calendar getSystemModstamp() {
        return systemModstamp;
    }


    /**
     * Sets the systemModstamp value for this BillingInfo__c.
     * 
     * @param systemModstamp
     */
    public void setSystemModstamp(java.util.Calendar systemModstamp) {
        this.systemModstamp = systemModstamp;
    }


    /**
     * Gets the taxNumber__c value for this BillingInfo__c.
     * 
     * @return taxNumber__c
     */
    public java.lang.String getTaxNumber__c() {
        return taxNumber__c;
    }


    /**
     * Sets the taxNumber__c value for this BillingInfo__c.
     * 
     * @param taxNumber__c
     */
    public void setTaxNumber__c(java.lang.String taxNumber__c) {
        this.taxNumber__c = taxNumber__c;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof BillingInfo__c)) return false;
        BillingInfo__c other = (BillingInfo__c) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.AP_1ExpectedDay__c==null && other.getAP_1ExpectedDay__c()==null) || 
             (this.AP_1ExpectedDay__c!=null &&
              this.AP_1ExpectedDay__c.equals(other.getAP_1ExpectedDay__c()))) &&
            ((this.AP_1StPayAmount__c==null && other.getAP_1StPayAmount__c()==null) || 
             (this.AP_1StPayAmount__c!=null &&
              this.AP_1StPayAmount__c.equals(other.getAP_1StPayAmount__c()))) &&
            ((this.AP_2ExpectedDay__c==null && other.getAP_2ExpectedDay__c()==null) || 
             (this.AP_2ExpectedDay__c!=null &&
              this.AP_2ExpectedDay__c.equals(other.getAP_2ExpectedDay__c()))) &&
            ((this.AP_PayItemCount__c==null && other.getAP_PayItemCount__c()==null) || 
             (this.AP_PayItemCount__c!=null &&
              this.AP_PayItemCount__c.equals(other.getAP_PayItemCount__c()))) &&
            ((this.accountBank__c==null && other.getAccountBank__c()==null) || 
             (this.accountBank__c!=null &&
              this.accountBank__c.equals(other.getAccountBank__c()))) &&
            ((this.accountName__c==null && other.getAccountName__c()==null) || 
             (this.accountName__c!=null &&
              this.accountName__c.equals(other.getAccountName__c()))) &&
            ((this.accountNo__c==null && other.getAccountNo__c()==null) || 
             (this.accountNo__c!=null &&
              this.accountNo__c.equals(other.getAccountNo__c()))) &&
            ((this.address__c==null && other.getAddress__c()==null) || 
             (this.address__c!=null &&
              this.address__c.equals(other.getAddress__c()))) &&
            ((this.amount__c==null && other.getAmount__c()==null) || 
             (this.amount__c!=null &&
              this.amount__c.equals(other.getAmount__c()))) &&
            ((this.attachments==null && other.getAttachments()==null) || 
             (this.attachments!=null &&
              this.attachments.equals(other.getAttachments()))) &&
            ((this.billingCompany__c==null && other.getBillingCompany__c()==null) || 
             (this.billingCompany__c!=null &&
              this.billingCompany__c.equals(other.getBillingCompany__c()))) &&
            ((this.billingInfoPay__r==null && other.getBillingInfoPay__r()==null) || 
             (this.billingInfoPay__r!=null &&
              this.billingInfoPay__r.equals(other.getBillingInfoPay__r()))) &&
            ((this.contactPhone__c==null && other.getContactPhone__c()==null) || 
             (this.contactPhone__c!=null &&
              this.contactPhone__c.equals(other.getContactPhone__c()))) &&
            ((this.contact__c==null && other.getContact__c()==null) || 
             (this.contact__c!=null &&
              this.contact__c.equals(other.getContact__c()))) &&
            ((this.contractBilling__r==null && other.getContractBilling__r()==null) || 
             (this.contractBilling__r!=null &&
              this.contractBilling__r.equals(other.getContractBilling__r()))) &&
            ((this.contract__c==null && other.getContract__c()==null) || 
             (this.contract__c!=null &&
              this.contract__c.equals(other.getContract__c()))) &&
            ((this.contract__r==null && other.getContract__r()==null) || 
             (this.contract__r!=null &&
              this.contract__r.equals(other.getContract__r()))) &&
            ((this.createdBy==null && other.getCreatedBy()==null) || 
             (this.createdBy!=null &&
              this.createdBy.equals(other.getCreatedBy()))) &&
            ((this.createdById==null && other.getCreatedById()==null) || 
             (this.createdById!=null &&
              this.createdById.equals(other.getCreatedById()))) &&
            ((this.createdDate==null && other.getCreatedDate()==null) || 
             (this.createdDate!=null &&
              this.createdDate.equals(other.getCreatedDate()))) &&
            ((this.firstPaymentRate__c==null && other.getFirstPaymentRate__c()==null) || 
             (this.firstPaymentRate__c!=null &&
              this.firstPaymentRate__c.equals(other.getFirstPaymentRate__c()))) &&
            ((this.firstPayment__c==null && other.getFirstPayment__c()==null) || 
             (this.firstPayment__c!=null &&
              this.firstPayment__c.equals(other.getFirstPayment__c()))) &&
            ((this.invoiceCompany__c==null && other.getInvoiceCompany__c()==null) || 
             (this.invoiceCompany__c!=null &&
              this.invoiceCompany__c.equals(other.getInvoiceCompany__c()))) &&
            ((this.invoiceText__c==null && other.getInvoiceText__c()==null) || 
             (this.invoiceText__c!=null &&
              this.invoiceText__c.equals(other.getInvoiceText__c()))) &&
            ((this.invoiceType__c==null && other.getInvoiceType__c()==null) || 
             (this.invoiceType__c!=null &&
              this.invoiceType__c.equals(other.getInvoiceType__c()))) &&
            ((this.isDeleted==null && other.getIsDeleted()==null) || 
             (this.isDeleted!=null &&
              this.isDeleted.equals(other.getIsDeleted()))) &&
            ((this.lastModifiedBy==null && other.getLastModifiedBy()==null) || 
             (this.lastModifiedBy!=null &&
              this.lastModifiedBy.equals(other.getLastModifiedBy()))) &&
            ((this.lastModifiedById==null && other.getLastModifiedById()==null) || 
             (this.lastModifiedById!=null &&
              this.lastModifiedById.equals(other.getLastModifiedById()))) &&
            ((this.lastModifiedDate==null && other.getLastModifiedDate()==null) || 
             (this.lastModifiedDate!=null &&
              this.lastModifiedDate.equals(other.getLastModifiedDate()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.notes==null && other.getNotes()==null) || 
             (this.notes!=null &&
              this.notes.equals(other.getNotes()))) &&
            ((this.notesAndAttachments==null && other.getNotesAndAttachments()==null) || 
             (this.notesAndAttachments!=null &&
              this.notesAndAttachments.equals(other.getNotesAndAttachments()))) &&
            ((this.paymentAmount__c==null && other.getPaymentAmount__c()==null) || 
             (this.paymentAmount__c!=null &&
              this.paymentAmount__c.equals(other.getPaymentAmount__c()))) &&
            ((this.payment__c==null && other.getPayment__c()==null) || 
             (this.payment__c!=null &&
              this.payment__c.equals(other.getPayment__c()))) &&
            ((this.processInstances==null && other.getProcessInstances()==null) || 
             (this.processInstances!=null &&
              this.processInstances.equals(other.getProcessInstances()))) &&
            ((this.processSteps==null && other.getProcessSteps()==null) || 
             (this.processSteps!=null &&
              this.processSteps.equals(other.getProcessSteps()))) &&
            ((this.systemModstamp==null && other.getSystemModstamp()==null) || 
             (this.systemModstamp!=null &&
              this.systemModstamp.equals(other.getSystemModstamp()))) &&
            ((this.taxNumber__c==null && other.getTaxNumber__c()==null) || 
             (this.taxNumber__c!=null &&
              this.taxNumber__c.equals(other.getTaxNumber__c())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAP_1ExpectedDay__c() != null) {
            _hashCode += getAP_1ExpectedDay__c().hashCode();
        }
        if (getAP_1StPayAmount__c() != null) {
            _hashCode += getAP_1StPayAmount__c().hashCode();
        }
        if (getAP_2ExpectedDay__c() != null) {
            _hashCode += getAP_2ExpectedDay__c().hashCode();
        }
        if (getAP_PayItemCount__c() != null) {
            _hashCode += getAP_PayItemCount__c().hashCode();
        }
        if (getAccountBank__c() != null) {
            _hashCode += getAccountBank__c().hashCode();
        }
        if (getAccountName__c() != null) {
            _hashCode += getAccountName__c().hashCode();
        }
        if (getAccountNo__c() != null) {
            _hashCode += getAccountNo__c().hashCode();
        }
        if (getAddress__c() != null) {
            _hashCode += getAddress__c().hashCode();
        }
        if (getAmount__c() != null) {
            _hashCode += getAmount__c().hashCode();
        }
        if (getAttachments() != null) {
            _hashCode += getAttachments().hashCode();
        }
        if (getBillingCompany__c() != null) {
            _hashCode += getBillingCompany__c().hashCode();
        }
        if (getBillingInfoPay__r() != null) {
            _hashCode += getBillingInfoPay__r().hashCode();
        }
        if (getContactPhone__c() != null) {
            _hashCode += getContactPhone__c().hashCode();
        }
        if (getContact__c() != null) {
            _hashCode += getContact__c().hashCode();
        }
        if (getContractBilling__r() != null) {
            _hashCode += getContractBilling__r().hashCode();
        }
        if (getContract__c() != null) {
            _hashCode += getContract__c().hashCode();
        }
        if (getContract__r() != null) {
            _hashCode += getContract__r().hashCode();
        }
        if (getCreatedBy() != null) {
            _hashCode += getCreatedBy().hashCode();
        }
        if (getCreatedById() != null) {
            _hashCode += getCreatedById().hashCode();
        }
        if (getCreatedDate() != null) {
            _hashCode += getCreatedDate().hashCode();
        }
        if (getFirstPaymentRate__c() != null) {
            _hashCode += getFirstPaymentRate__c().hashCode();
        }
        if (getFirstPayment__c() != null) {
            _hashCode += getFirstPayment__c().hashCode();
        }
        if (getInvoiceCompany__c() != null) {
            _hashCode += getInvoiceCompany__c().hashCode();
        }
        if (getInvoiceText__c() != null) {
            _hashCode += getInvoiceText__c().hashCode();
        }
        if (getInvoiceType__c() != null) {
            _hashCode += getInvoiceType__c().hashCode();
        }
        if (getIsDeleted() != null) {
            _hashCode += getIsDeleted().hashCode();
        }
        if (getLastModifiedBy() != null) {
            _hashCode += getLastModifiedBy().hashCode();
        }
        if (getLastModifiedById() != null) {
            _hashCode += getLastModifiedById().hashCode();
        }
        if (getLastModifiedDate() != null) {
            _hashCode += getLastModifiedDate().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getNotes() != null) {
            _hashCode += getNotes().hashCode();
        }
        if (getNotesAndAttachments() != null) {
            _hashCode += getNotesAndAttachments().hashCode();
        }
        if (getPaymentAmount__c() != null) {
            _hashCode += getPaymentAmount__c().hashCode();
        }
        if (getPayment__c() != null) {
            _hashCode += getPayment__c().hashCode();
        }
        if (getProcessInstances() != null) {
            _hashCode += getProcessInstances().hashCode();
        }
        if (getProcessSteps() != null) {
            _hashCode += getProcessSteps().hashCode();
        }
        if (getSystemModstamp() != null) {
            _hashCode += getSystemModstamp().hashCode();
        }
        if (getTaxNumber__c() != null) {
            _hashCode += getTaxNumber__c().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(BillingInfo__c.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BillingInfo__c"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AP_1ExpectedDay__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AP_1ExpectedDay__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AP_1StPayAmount__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AP_1stPayAmount__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AP_2ExpectedDay__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AP_2ExpectedDay__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AP_PayItemCount__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AP_PayItemCount__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accountBank__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AccountBank__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accountName__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AccountName__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("accountNo__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AccountNo__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("address__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Address__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("amount__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Amount__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Attachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("billingCompany__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BillingCompany__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("billingInfoPay__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BillingInfoPay__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contactPhone__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ContactPhone__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contact__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Contact__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contractBilling__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ContractBilling__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contract__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Contract__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contract__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Contract__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Contract"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("firstPaymentRate__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "FirstPaymentRate__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("firstPayment__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "FirstPayment__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("invoiceCompany__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "InvoiceCompany__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("invoiceText__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "InvoiceText__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("invoiceType__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "InvoiceType__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isDeleted");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsDeleted"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notes");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Notes"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notesAndAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NotesAndAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paymentAmount__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PaymentAmount__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("payment__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Payment__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processInstances");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessInstances"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processSteps");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessSteps"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("systemModstamp");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SystemModstamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("taxNumber__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TaxNumber__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
