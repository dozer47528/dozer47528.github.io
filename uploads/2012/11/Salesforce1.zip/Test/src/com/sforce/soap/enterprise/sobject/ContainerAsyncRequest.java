/**
 * ContainerAsyncRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.sforce.soap.enterprise.sobject;

public class ContainerAsyncRequest  extends com.sforce.soap.enterprise.sobject.SObject  implements java.io.Serializable {
    private java.lang.String compilerErrors;

    private com.sforce.soap.enterprise.sobject.User createdBy;

    private java.lang.String createdById;

    private java.util.Calendar createdDate;

    private java.lang.String errorMsg;

    private java.lang.Boolean isCheckOnly;

    private java.lang.Boolean isDeleted;

    private java.lang.Boolean isRunTests;

    private com.sforce.soap.enterprise.sobject.User lastModifiedBy;

    private java.lang.String lastModifiedById;

    private java.util.Calendar lastModifiedDate;

    private com.sforce.soap.enterprise.sobject.MetadataContainer metadataContainer;

    private java.lang.String metadataContainerId;

    private com.sforce.soap.enterprise.sobject.MetadataContainerMember metadataContainerMember;

    private java.lang.String metadataContainerMemberId;

    private java.lang.String state;

    private java.util.Calendar systemModstamp;

    public ContainerAsyncRequest() {
    }

    public ContainerAsyncRequest(
           java.lang.String[] fieldsToNull,
           java.lang.String id,
           java.lang.String compilerErrors,
           com.sforce.soap.enterprise.sobject.User createdBy,
           java.lang.String createdById,
           java.util.Calendar createdDate,
           java.lang.String errorMsg,
           java.lang.Boolean isCheckOnly,
           java.lang.Boolean isDeleted,
           java.lang.Boolean isRunTests,
           com.sforce.soap.enterprise.sobject.User lastModifiedBy,
           java.lang.String lastModifiedById,
           java.util.Calendar lastModifiedDate,
           com.sforce.soap.enterprise.sobject.MetadataContainer metadataContainer,
           java.lang.String metadataContainerId,
           com.sforce.soap.enterprise.sobject.MetadataContainerMember metadataContainerMember,
           java.lang.String metadataContainerMemberId,
           java.lang.String state,
           java.util.Calendar systemModstamp) {
        super(
            fieldsToNull,
            id);
        this.compilerErrors = compilerErrors;
        this.createdBy = createdBy;
        this.createdById = createdById;
        this.createdDate = createdDate;
        this.errorMsg = errorMsg;
        this.isCheckOnly = isCheckOnly;
        this.isDeleted = isDeleted;
        this.isRunTests = isRunTests;
        this.lastModifiedBy = lastModifiedBy;
        this.lastModifiedById = lastModifiedById;
        this.lastModifiedDate = lastModifiedDate;
        this.metadataContainer = metadataContainer;
        this.metadataContainerId = metadataContainerId;
        this.metadataContainerMember = metadataContainerMember;
        this.metadataContainerMemberId = metadataContainerMemberId;
        this.state = state;
        this.systemModstamp = systemModstamp;
    }


    /**
     * Gets the compilerErrors value for this ContainerAsyncRequest.
     * 
     * @return compilerErrors
     */
    public java.lang.String getCompilerErrors() {
        return compilerErrors;
    }


    /**
     * Sets the compilerErrors value for this ContainerAsyncRequest.
     * 
     * @param compilerErrors
     */
    public void setCompilerErrors(java.lang.String compilerErrors) {
        this.compilerErrors = compilerErrors;
    }


    /**
     * Gets the createdBy value for this ContainerAsyncRequest.
     * 
     * @return createdBy
     */
    public com.sforce.soap.enterprise.sobject.User getCreatedBy() {
        return createdBy;
    }


    /**
     * Sets the createdBy value for this ContainerAsyncRequest.
     * 
     * @param createdBy
     */
    public void setCreatedBy(com.sforce.soap.enterprise.sobject.User createdBy) {
        this.createdBy = createdBy;
    }


    /**
     * Gets the createdById value for this ContainerAsyncRequest.
     * 
     * @return createdById
     */
    public java.lang.String getCreatedById() {
        return createdById;
    }


    /**
     * Sets the createdById value for this ContainerAsyncRequest.
     * 
     * @param createdById
     */
    public void setCreatedById(java.lang.String createdById) {
        this.createdById = createdById;
    }


    /**
     * Gets the createdDate value for this ContainerAsyncRequest.
     * 
     * @return createdDate
     */
    public java.util.Calendar getCreatedDate() {
        return createdDate;
    }


    /**
     * Sets the createdDate value for this ContainerAsyncRequest.
     * 
     * @param createdDate
     */
    public void setCreatedDate(java.util.Calendar createdDate) {
        this.createdDate = createdDate;
    }


    /**
     * Gets the errorMsg value for this ContainerAsyncRequest.
     * 
     * @return errorMsg
     */
    public java.lang.String getErrorMsg() {
        return errorMsg;
    }


    /**
     * Sets the errorMsg value for this ContainerAsyncRequest.
     * 
     * @param errorMsg
     */
    public void setErrorMsg(java.lang.String errorMsg) {
        this.errorMsg = errorMsg;
    }


    /**
     * Gets the isCheckOnly value for this ContainerAsyncRequest.
     * 
     * @return isCheckOnly
     */
    public java.lang.Boolean getIsCheckOnly() {
        return isCheckOnly;
    }


    /**
     * Sets the isCheckOnly value for this ContainerAsyncRequest.
     * 
     * @param isCheckOnly
     */
    public void setIsCheckOnly(java.lang.Boolean isCheckOnly) {
        this.isCheckOnly = isCheckOnly;
    }


    /**
     * Gets the isDeleted value for this ContainerAsyncRequest.
     * 
     * @return isDeleted
     */
    public java.lang.Boolean getIsDeleted() {
        return isDeleted;
    }


    /**
     * Sets the isDeleted value for this ContainerAsyncRequest.
     * 
     * @param isDeleted
     */
    public void setIsDeleted(java.lang.Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }


    /**
     * Gets the isRunTests value for this ContainerAsyncRequest.
     * 
     * @return isRunTests
     */
    public java.lang.Boolean getIsRunTests() {
        return isRunTests;
    }


    /**
     * Sets the isRunTests value for this ContainerAsyncRequest.
     * 
     * @param isRunTests
     */
    public void setIsRunTests(java.lang.Boolean isRunTests) {
        this.isRunTests = isRunTests;
    }


    /**
     * Gets the lastModifiedBy value for this ContainerAsyncRequest.
     * 
     * @return lastModifiedBy
     */
    public com.sforce.soap.enterprise.sobject.User getLastModifiedBy() {
        return lastModifiedBy;
    }


    /**
     * Sets the lastModifiedBy value for this ContainerAsyncRequest.
     * 
     * @param lastModifiedBy
     */
    public void setLastModifiedBy(com.sforce.soap.enterprise.sobject.User lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }


    /**
     * Gets the lastModifiedById value for this ContainerAsyncRequest.
     * 
     * @return lastModifiedById
     */
    public java.lang.String getLastModifiedById() {
        return lastModifiedById;
    }


    /**
     * Sets the lastModifiedById value for this ContainerAsyncRequest.
     * 
     * @param lastModifiedById
     */
    public void setLastModifiedById(java.lang.String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }


    /**
     * Gets the lastModifiedDate value for this ContainerAsyncRequest.
     * 
     * @return lastModifiedDate
     */
    public java.util.Calendar getLastModifiedDate() {
        return lastModifiedDate;
    }


    /**
     * Sets the lastModifiedDate value for this ContainerAsyncRequest.
     * 
     * @param lastModifiedDate
     */
    public void setLastModifiedDate(java.util.Calendar lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }


    /**
     * Gets the metadataContainer value for this ContainerAsyncRequest.
     * 
     * @return metadataContainer
     */
    public com.sforce.soap.enterprise.sobject.MetadataContainer getMetadataContainer() {
        return metadataContainer;
    }


    /**
     * Sets the metadataContainer value for this ContainerAsyncRequest.
     * 
     * @param metadataContainer
     */
    public void setMetadataContainer(com.sforce.soap.enterprise.sobject.MetadataContainer metadataContainer) {
        this.metadataContainer = metadataContainer;
    }


    /**
     * Gets the metadataContainerId value for this ContainerAsyncRequest.
     * 
     * @return metadataContainerId
     */
    public java.lang.String getMetadataContainerId() {
        return metadataContainerId;
    }


    /**
     * Sets the metadataContainerId value for this ContainerAsyncRequest.
     * 
     * @param metadataContainerId
     */
    public void setMetadataContainerId(java.lang.String metadataContainerId) {
        this.metadataContainerId = metadataContainerId;
    }


    /**
     * Gets the metadataContainerMember value for this ContainerAsyncRequest.
     * 
     * @return metadataContainerMember
     */
    public com.sforce.soap.enterprise.sobject.MetadataContainerMember getMetadataContainerMember() {
        return metadataContainerMember;
    }


    /**
     * Sets the metadataContainerMember value for this ContainerAsyncRequest.
     * 
     * @param metadataContainerMember
     */
    public void setMetadataContainerMember(com.sforce.soap.enterprise.sobject.MetadataContainerMember metadataContainerMember) {
        this.metadataContainerMember = metadataContainerMember;
    }


    /**
     * Gets the metadataContainerMemberId value for this ContainerAsyncRequest.
     * 
     * @return metadataContainerMemberId
     */
    public java.lang.String getMetadataContainerMemberId() {
        return metadataContainerMemberId;
    }


    /**
     * Sets the metadataContainerMemberId value for this ContainerAsyncRequest.
     * 
     * @param metadataContainerMemberId
     */
    public void setMetadataContainerMemberId(java.lang.String metadataContainerMemberId) {
        this.metadataContainerMemberId = metadataContainerMemberId;
    }


    /**
     * Gets the state value for this ContainerAsyncRequest.
     * 
     * @return state
     */
    public java.lang.String getState() {
        return state;
    }


    /**
     * Sets the state value for this ContainerAsyncRequest.
     * 
     * @param state
     */
    public void setState(java.lang.String state) {
        this.state = state;
    }


    /**
     * Gets the systemModstamp value for this ContainerAsyncRequest.
     * 
     * @return systemModstamp
     */
    public java.util.Calendar getSystemModstamp() {
        return systemModstamp;
    }


    /**
     * Sets the systemModstamp value for this ContainerAsyncRequest.
     * 
     * @param systemModstamp
     */
    public void setSystemModstamp(java.util.Calendar systemModstamp) {
        this.systemModstamp = systemModstamp;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ContainerAsyncRequest)) return false;
        ContainerAsyncRequest other = (ContainerAsyncRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.compilerErrors==null && other.getCompilerErrors()==null) || 
             (this.compilerErrors!=null &&
              this.compilerErrors.equals(other.getCompilerErrors()))) &&
            ((this.createdBy==null && other.getCreatedBy()==null) || 
             (this.createdBy!=null &&
              this.createdBy.equals(other.getCreatedBy()))) &&
            ((this.createdById==null && other.getCreatedById()==null) || 
             (this.createdById!=null &&
              this.createdById.equals(other.getCreatedById()))) &&
            ((this.createdDate==null && other.getCreatedDate()==null) || 
             (this.createdDate!=null &&
              this.createdDate.equals(other.getCreatedDate()))) &&
            ((this.errorMsg==null && other.getErrorMsg()==null) || 
             (this.errorMsg!=null &&
              this.errorMsg.equals(other.getErrorMsg()))) &&
            ((this.isCheckOnly==null && other.getIsCheckOnly()==null) || 
             (this.isCheckOnly!=null &&
              this.isCheckOnly.equals(other.getIsCheckOnly()))) &&
            ((this.isDeleted==null && other.getIsDeleted()==null) || 
             (this.isDeleted!=null &&
              this.isDeleted.equals(other.getIsDeleted()))) &&
            ((this.isRunTests==null && other.getIsRunTests()==null) || 
             (this.isRunTests!=null &&
              this.isRunTests.equals(other.getIsRunTests()))) &&
            ((this.lastModifiedBy==null && other.getLastModifiedBy()==null) || 
             (this.lastModifiedBy!=null &&
              this.lastModifiedBy.equals(other.getLastModifiedBy()))) &&
            ((this.lastModifiedById==null && other.getLastModifiedById()==null) || 
             (this.lastModifiedById!=null &&
              this.lastModifiedById.equals(other.getLastModifiedById()))) &&
            ((this.lastModifiedDate==null && other.getLastModifiedDate()==null) || 
             (this.lastModifiedDate!=null &&
              this.lastModifiedDate.equals(other.getLastModifiedDate()))) &&
            ((this.metadataContainer==null && other.getMetadataContainer()==null) || 
             (this.metadataContainer!=null &&
              this.metadataContainer.equals(other.getMetadataContainer()))) &&
            ((this.metadataContainerId==null && other.getMetadataContainerId()==null) || 
             (this.metadataContainerId!=null &&
              this.metadataContainerId.equals(other.getMetadataContainerId()))) &&
            ((this.metadataContainerMember==null && other.getMetadataContainerMember()==null) || 
             (this.metadataContainerMember!=null &&
              this.metadataContainerMember.equals(other.getMetadataContainerMember()))) &&
            ((this.metadataContainerMemberId==null && other.getMetadataContainerMemberId()==null) || 
             (this.metadataContainerMemberId!=null &&
              this.metadataContainerMemberId.equals(other.getMetadataContainerMemberId()))) &&
            ((this.state==null && other.getState()==null) || 
             (this.state!=null &&
              this.state.equals(other.getState()))) &&
            ((this.systemModstamp==null && other.getSystemModstamp()==null) || 
             (this.systemModstamp!=null &&
              this.systemModstamp.equals(other.getSystemModstamp())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getCompilerErrors() != null) {
            _hashCode += getCompilerErrors().hashCode();
        }
        if (getCreatedBy() != null) {
            _hashCode += getCreatedBy().hashCode();
        }
        if (getCreatedById() != null) {
            _hashCode += getCreatedById().hashCode();
        }
        if (getCreatedDate() != null) {
            _hashCode += getCreatedDate().hashCode();
        }
        if (getErrorMsg() != null) {
            _hashCode += getErrorMsg().hashCode();
        }
        if (getIsCheckOnly() != null) {
            _hashCode += getIsCheckOnly().hashCode();
        }
        if (getIsDeleted() != null) {
            _hashCode += getIsDeleted().hashCode();
        }
        if (getIsRunTests() != null) {
            _hashCode += getIsRunTests().hashCode();
        }
        if (getLastModifiedBy() != null) {
            _hashCode += getLastModifiedBy().hashCode();
        }
        if (getLastModifiedById() != null) {
            _hashCode += getLastModifiedById().hashCode();
        }
        if (getLastModifiedDate() != null) {
            _hashCode += getLastModifiedDate().hashCode();
        }
        if (getMetadataContainer() != null) {
            _hashCode += getMetadataContainer().hashCode();
        }
        if (getMetadataContainerId() != null) {
            _hashCode += getMetadataContainerId().hashCode();
        }
        if (getMetadataContainerMember() != null) {
            _hashCode += getMetadataContainerMember().hashCode();
        }
        if (getMetadataContainerMemberId() != null) {
            _hashCode += getMetadataContainerMemberId().hashCode();
        }
        if (getState() != null) {
            _hashCode += getState().hashCode();
        }
        if (getSystemModstamp() != null) {
            _hashCode += getSystemModstamp().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ContainerAsyncRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ContainerAsyncRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("compilerErrors");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CompilerErrors"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("errorMsg");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ErrorMsg"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isCheckOnly");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsCheckOnly"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isDeleted");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsDeleted"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isRunTests");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsRunTests"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("metadataContainer");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "MetadataContainer"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "MetadataContainer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("metadataContainerId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "MetadataContainerId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("metadataContainerMember");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "MetadataContainerMember"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "MetadataContainerMember"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("metadataContainerMemberId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "MetadataContainerMemberId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("state");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "State"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("systemModstamp");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SystemModstamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
