﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebForm
{
    public partial class AsyncPage_CPU : System.Web.UI.Page
    {
        protected async void Page_Load(object sender, EventArgs e)
        {
            SetThreads(1, 2);

            await Task.Run(() => {
                Thread.Sleep(5000);
            });
        }

        void SetThreads(int min, int max)
        {
            int worker, io;
            ThreadPool.GetMaxThreads(out worker, out io);
            ThreadPool.SetMinThreads(min, io);
            ThreadPool.SetMaxThreads(max, io);
        }
    }
}