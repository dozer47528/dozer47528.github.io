﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebServiceAdapter.MyWebService;

namespace WebForm
{
    public partial class NoAsyncPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SetThreads(1, 2);

            using (WebService service = new WebService())
            {
                service.HelloWorld();
            }
        }

        void SetThreads(int min, int max)
        {
            int worker, io;
            ThreadPool.GetMaxThreads(out worker, out io);
            ThreadPool.SetMinThreads(min, io);
            ThreadPool.SetMaxThreads(max, io);
        }
    }
}