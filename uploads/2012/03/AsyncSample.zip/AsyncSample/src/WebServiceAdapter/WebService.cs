﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace WebServiceAdapter.MyWebService
{
    public partial class WebService
    {
        /// <summary>
        /// 无 CancellationToken 的调用
        /// </summary>
        /// <returns></returns>
        public Task<string> HelloWorldTaskSync()
        {
            return HelloWorldTaskSync(new CancellationToken());
        }

        /// <summary>
        /// 有 CancellationToken 的调用
        /// </summary>
        /// <param name="token"></param>
        /// <returns></returns>
        public Task<string> HelloWorldTaskSync(CancellationToken token)
        {
            TaskCompletionSource<string> tcs = new TaskCompletionSource<string>();

            token.Register(() =>
            {
                //注册 CancellationToken
                this.CancelAsync(null);
            });


            //注册完成事件
            this.HelloWorldCompleted += (object sender, HelloWorldCompletedEventArgs args) =>
            {
                if (args.Cancelled == true)
                {
                    tcs.TrySetCanceled();
                    return;
                }
                else if (args.Error != null)
                {
                    tcs.TrySetException(args.Error);
                    return;
                }
                else
                {
                    tcs.TrySetResult(args.Result);
                }
            };

            //异步调用
            this.HelloWorldAsync();

            //返回 Task
            return tcs.Task;
        }
    }
}
